import com.redline.core.*;
import java.nio.file.*;
import java.util.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
public class Smoke {
  public static void main(String[] a) throws Exception {
    EngineDB db = EngineDB.parse(new String(Files.readAllBytes(Paths.get("assets/engines.txt")), "UTF-8"));
    Random rnd=new Random(1); int fails=0; int cols=12, cw=180, ch=150;
    int rows=(db.all.size()+cols-1)/cols;
    BufferedImage sheet=new BufferedImage(cols*cw, rows*ch, BufferedImage.TYPE_INT_RGB);
    Graphics2D g=sheet.createGraphics(); g.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,10));
    long maxMs=0; String slow="";
    for (int i=0;i<db.all.size();i++) { Engine e=db.all.get(i);
      try {
        EngineModel m=new EngineModel(e);
        Raster r=new Raster(); r.resize(cw,ch);
        for (int mode=0; mode<7; mode++){ r.mode=mode; r.explodeT=1; r.fit(m); m.update(rnd.nextFloat()*720, e.redline*0.5f, 0.6f, 0.02f); long t0=System.nanoTime(); r.render(m); long ms=(System.nanoTime()-t0)/1000000; if(ms>maxMs){maxMs=ms;slow=e.title()+" mode "+mode;} 
          for (int k=0;k<10;k++) r.pick(rnd.nextInt(cw), rnd.nextInt(ch)); }
        for (Part p: m.parts) PartInfo.describe(m,p);
        for (int k=0;k<m.np;k++) if (Float.isNaN(m.px[k])) throw new RuntimeException("NaN particle");
        for (Part p: m.parts) for (int k=0;k<p.mesh.nv*3;k++) if (Float.isNaN(p.mesh.p[k])) throw new RuntimeException("NaN vert in "+p.key);
        r.mode=0; r.fit(m); m.update(100,e.idle,0.3f,0.02f); r.render(m);
        BufferedImage im=new BufferedImage(cw,ch,BufferedImage.TYPE_INT_RGB); im.setRGB(0,0,cw,ch,r.px,0,cw);
        g.drawImage(im,(i%cols)*cw,(i/cols)*ch,null); g.setColor(Color.WHITE); g.drawString((e.make+" "+e.name).substring(0,Math.min(34,(e.make+" "+e.name).length())),(i%cols)*cw+3,(i/cols)*ch+11);
        RevSim s=new RevSim(e, Curve.stock(e), e.redline); s.start();
        for (int k=0;k<600;k++){ s.throttleIn = (k/60)%2==0?1:0; s.limiter=(k/150)%4; s.step(1/60f); if(Float.isNaN(s.rpm)) throw new RuntimeException("NaN rpm"); }
        s.startDyno(); for (int k=0;k<3000 && s.dynoRunning;k++) s.step(1/60f);
        for (Vehicle v: e.vehicles) for (int k=0;k<4;k++){ Tune t=new Tune(); if(k>0){t.ecu=rnd.nextInt(4);t.boost=rnd.nextInt(15);t.kit=rnd.nextInt(3);t.nitrous=rnd.nextInt(5);t.bigBore=rnd.nextInt(4);t.revs=rnd.nextInt(5);t.weight=rnd.nextInt(5);t.tires=rnd.nextInt(5);t.gearing=rnd.nextInt(7)-3;t.limiterOff=rnd.nextInt(2);t.aero=rnd.nextInt(3);t.fuel=rnd.nextInt(4);}
          Curve st=Curve.stock(e), c=Curve.build(e,t); Perf p=Perf.run(v,t,st,c,true); if (Float.isNaN(p.top)||Float.isNaN(c.peakKw)) throw new RuntimeException("NaN perf "+v.name+" "+t.encode()); }
      } catch (Throwable ex) { fails++; System.out.println("FAIL "+e.title()+": "+ex); ex.printStackTrace(System.out); if (fails>5) break; }
    }
    System.out.println("engines="+db.all.size()+" fails="+fails+" slowest render "+maxMs+"ms ("+slow+")");
    ImageIO.write(sheet,"png",new File(a[0]));
    System.exit(0);
  }
}

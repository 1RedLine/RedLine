import com.redline.core.*;
import java.nio.file.*;
import java.awt.image.BufferedImage;
import java.awt.*;
import javax.imageio.ImageIO;
import java.io.File;
public class Big {
  public static void main(String[] a) throws Exception {
    EngineDB db = EngineDB.parse(new String(Files.readAllBytes(Paths.get("assets/engines.txt")), "UTF-8"));
    String[] names = a[1].split(",");
    int[] modes = new int[a[2].split(",").length]; for (int i=0;i<modes.length;i++) modes[i]=Integer.parseInt(a[2].split(",")[i]);
    float yaw = a.length>3?Float.parseFloat(a[3]):-38, pitch=a.length>4?Float.parseFloat(a[4]):20;
    int W=640,H=520;
    BufferedImage out = new BufferedImage(W*modes.length, H*names.length, BufferedImage.TYPE_INT_RGB);
    Graphics2D g = out.createGraphics();
    for (int r=0;r<names.length;r++) {
      Engine e=null; for (Engine x: db.all) if ((x.name+" "+x.code).contains(names[r])) { e=x; break; }
      EngineModel m = new EngineModel(e);
      for (int c=0;c<modes.length;c++) {
        Raster ras = new Raster(); ras.resize(W,H); ras.mode=modes[c]; ras.explodeT=1f; ras.yaw=yaw; ras.pitch=pitch; ras.fit(m);
        m.update(137f, e.redline*0.6f, 0.8f, 0.016f);
        ras.render(m);
        BufferedImage img = new BufferedImage(W,H,BufferedImage.TYPE_INT_RGB);
        img.setRGB(0,0,W,H,ras.px,0,W);
        g.drawImage(img, c*W, r*H, null);
        g.setColor(Color.WHITE); g.drawString(e.make+" "+e.name+" / "+Raster.MODES[modes[c]], c*W+5, r*H+14);
      }
    }
    ImageIO.write(out, "png", new File(a[0]));
  }
}

import com.redline.core.*;
import java.nio.file.*;
public class Bench {
  public static void main(String[] a) throws Exception {
    EngineDB db = EngineDB.parse(new String(Files.readAllBytes(Paths.get("assets/engines.txt")), "UTF-8"));
    for (String n: new String[]{"Veyron)","812 Superfast","R-4360","EA888"}) {
      Engine e=null; for (Engine x: db.all) if ((x.name+" "+x.code).contains(n)) { e=x; break; }
      EngineModel m=new EngineModel(e);
      for (int mode: new int[]{0,1,3}) {
        Raster r=new Raster(); r.resize(540,600); r.mode=mode; r.fit(m);
        for (int i=0;i<20;i++){ m.update(i*7,3000,0.5f,0.016f); r.render(m);} 
        long t0=System.nanoTime(); int N=60; long upd=0;
        for (int i=0;i<N;i++){ long u0=System.nanoTime(); m.update(i*7,3000,0.5f,0.016f); upd+=System.nanoTime()-u0; r.render(m);} 
        System.out.printf("%-28s %-8s %.1f ms/frame (update %.2f ms)%n", e.name.substring(0,Math.min(28,e.name.length())), Raster.MODES[mode], (System.nanoTime()-t0)/1e6/N, upd/1e6/N);
      }
    }
    System.exit(0);
  }
}

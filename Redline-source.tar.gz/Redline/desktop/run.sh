#!/bin/bash
# Runs a desktop harness against the shared core code. Needs only a JDK 11+.
#   desktop/run.sh Smoke sheet.png                    check every engine, write a contact sheet
#   desktop/run.sh Bench                              render timings per view mode
#   desktop/run.sh Big out.png "W16,R-4360" 0,1,3     render engines (rows) x view modes (columns)
# View modes: 0 Solid, 1 X-ray, 2 Cutaway, 3 Flow, 4 Thermal, 5 Exploded, 6 Scale
set -e
cd "$(dirname "$0")/.."
mkdir -p build/desktop
javac -nowarn -encoding UTF-8 -d build/desktop src/com/redline/core/*.java desktop/*.java
java -cp build/desktop "$@"

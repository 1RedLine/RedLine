# Redline

A native Android engine library (no WebView). It has 244 real engines, from tiny 2-strokes up to the Devel V16 and the DB 603 from the Mercedes-Benz T80. Each engine has a procedurally generated, animated 3D model, a rev lab, tuning, and top-speed and drag-race physics.

![Bugatti W16: Solid, X-ray and Flow views](screenshots/views.png)

## Features

- **Engine library:** 244 engines and 370 vehicles, covering mopeds, motorcycles, cars, race, marine, aero, heavy and tool engines. You can search, filter and sort, and there's an engine of the day.
- **3D engine view:** a model built from each engine's real layout, bore, stroke, firing order and hardware (turbos, superchargers, carbs, intakes, exhausts). The view modes are:
  - **Solid** and **X-ray**
  - **Cutaway**
  - **Flow:** air, fuel, exhaust, coolant and oil moving through the engine
  - **Thermal**, **Exploded** and **Scale**
- **Tap any part** to see what it is and what it does.
- **Photo mode:** a progressive, multi-threaded CPU ray tracer with soft shadows, ambient occlusion, reflections and glass.
- **Rev Lab:** throttle pedal, tach, shift lights, turbo spool and lag, rev limiters (hard, soft, launch and anti-lag), temperatures, flames, and live dyno pulls. Haptic feedback is optional.
- **Tuning:** ECU, intake, exhaust, cams, boost, turbo and supercharger kits, nitrous, fuel, big bore, forged internals, revs, weight, aero, tires and gearing, with stress warnings. Torque curves and dyno charts update as you tune.
- **Performance:** top speed, 0–100/200/300/400 km/h, quarter mile, top-speed runs and drag races. The physics are calibrated to each vehicle's documented top speed.
- **Garage, Ranks, Compare and Arcade.**
- **Settings:** units, frame rate (30/60/120 fps), 3D resolution (Minimum to Max), photo samples, FPS counter and vibrations.

![VR6, R-4360 and DB 603: Solid and Cutaway](screenshots/engines.png)

## Install

Download the APK from [Releases](../../releases), then open it on your phone. You'll need to allow installs from your browser or file manager. The app requires Android 8.0 or newer.

## Build

The build uses no Gradle and no libraries, only the Android SDK command-line tools:

- JDK 11 or newer
- Android SDK build-tools
- Android SDK platform `android-35`

```bash
# one-time: create your own signing key (keep it private, never commit it)
keytool -genkeypair -keystore release.jks -alias redline -keyalg RSA -keysize 2048 -validity 10000 -dname CN=Redline

export ANDROID_HOME=$HOME/Android/Sdk
export KS_PASS=your-keystore-password
./build.sh            # outputs Redline.apk
```

You can put these variables in a local `signing.env` file instead. That file is git-ignored. See the top of `build.sh` for all the options.

## Desktop tests

All the engine, physics and rendering code lives in `com.redline.core` and is plain Java, so it runs on a desktop JVM:

```bash
desktop/run.sh Smoke sheet.png                   # builds and renders every engine in every view, checks for errors
desktop/run.sh Bench                             # ms per frame for each view mode
desktop/run.sh Big out.png "W16,R-4360" 0,1,3    # render engines x view modes to a PNG
```

## Project layout

```
assets/engines.txt     engine and vehicle database (one line per entry)
src/com/redline/core/  data, physics, 3D model builder, rasterizer, ray tracer, views
src/com/redline/app/   Android activity, Canvas renderer, settings storage
desktop/               desktop test harnesses
```

## Adding engines

Each engine is one `E|` line in `assets/engines.txt`, followed by its vehicles as `>` lines:

```
E|Make|Name|Code|Years|Layout|cc|Aspiration|Power|Torque|rpm at peak power|redline|options|note
>Vehicle|Years|Type|Drive|kg|top speed|power override
```

## Notes

Specs are compiled from public sources and may contain mistakes; corrections are welcome. The 3D models are procedural approximations, not CAD data. Redline is not affiliated with any manufacturer, and brand names are used only to identify engines.

## License

[GPL-3.0](LICENSE)

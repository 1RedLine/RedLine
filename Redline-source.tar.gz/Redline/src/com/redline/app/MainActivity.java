package com.redline.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.redline.core.Curve;
import com.redline.core.DynoChart;
import com.redline.core.Engine;
import com.redline.core.EngineDB;
import com.redline.core.EngineViewer;
import com.redline.core.Gfx;
import com.redline.core.Painter;
import com.redline.core.Perf;
import com.redline.core.Raster;
import com.redline.core.RevLab;
import com.redline.core.RunScene;
import com.redline.core.Theme;
import com.redline.core.Tune;
import com.redline.core.Units;
import com.redline.core.Vehicle;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;
import java.util.Random;
import java.util.Set;

public class MainActivity extends Activity {
    EngineDB db;
    Store store;
    FrameLayout content;
    LinearLayout topBar, nav;
    TextView titleView, backView;
    final ArrayList<Screen> stack = new ArrayList<>();
    int tab;
    Vibrator vib;

    static final class Screen {
        String title;
        View view;
        Runnable onClose;
        boolean full;
    }

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Window w = getWindow();
        w.setStatusBarColor(Theme.BG);
        w.setNavigationBarColor(Theme.BG);
        store = new Store(this);
        GView.showFps = store.fps;
        applyRefreshRate();
        vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        try {
            InputStream in = getAssets().open("engines.txt");
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            in.close();
            db = EngineDB.parse(bo.toString("UTF-8"));
        } catch (Exception ex) {
            db = EngineDB.parse("");
        }
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Theme.BG);
        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(8), dp(6), dp(12), dp(6));
        backView = tv("‹", 30, Theme.TEXT, true);
        backView.setPadding(dp(10), 0, dp(14), dp(4));
        backView.setOnClickListener(v -> onBackPressed());
        titleView = tv("REDLINE", 19, Theme.TEXT, true);
        titleView.setLetterSpacing(0.06f);
        titleView.setSingleLine(true);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        topBar.addView(backView);
        topBar.addView(titleView, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(topBar);
        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));
        nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setBackgroundColor(Theme.PANEL);
        nav.setPadding(0, dp(4), 0, dp(6));
        root.addView(nav);
        setContentView(root);
        buildNav();
        showTab(0);
    }

    @Override
    public void onBackPressed() {
        if (stack.size() > 1) pop();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        for (Screen s : stack) if (s.onClose != null) s.onClose.run();
        super.onDestroy();
    }

    /** Pick the display mode that matches the frame-rate setting (30/60/120) and cap drawing to it. */
    void applyRefreshRate() {
        int cap = store.fpsCap;
        GView.fpsCap = cap;
        try {
            android.view.Display d = getWindowManager().getDefaultDisplay();
            android.view.Display.Mode cur = d.getMode(), best = null, max = cur;
            for (android.view.Display.Mode m : d.getSupportedModes()) {
                if (m.getPhysicalWidth() != cur.getPhysicalWidth() || m.getPhysicalHeight() != cur.getPhysicalHeight()) continue;
                if (m.getRefreshRate() > max.getRefreshRate()) max = m;
                if (m.getRefreshRate() >= cap - 1f && (best == null || m.getRefreshRate() < best.getRefreshRate())) best = m;
            }
            if (best == null) best = max;
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.preferredDisplayModeId = best.getModeId();
            lp.preferredRefreshRate = best.getRefreshRate();
            getWindow().setAttributes(lp);
            GView.displayHz = best.getRefreshRate();
            EngineViewer.targetHz = Math.min(cap, best.getRefreshRate());
        } catch (Exception ignored) { }
    }

    float maxRefresh() {
        float r = 60f;
        try {
            for (android.view.Display.Mode m : getWindowManager().getDefaultDisplay().getSupportedModes()) r = Math.max(r, m.getRefreshRate());
        } catch (Exception ignored) { }
        return r;
    }

    // ------------------------------------------------------------------ navigation

    static final String[] TABS = {"Engines", "Garage", "Ranks", "Arcade", "Settings"};
    static final String[] TAB_ICONS = {"⚙", "🏁", "🏆", "🎮", "☰"};

    void buildNav() {
        nav.removeAllViews();
        for (int i = 0; i < TABS.length; i++) {
            final int k = i;
            LinearLayout b = new LinearLayout(this);
            b.setOrientation(LinearLayout.VERTICAL);
            b.setGravity(Gravity.CENTER);
            TextView ic = tv(TAB_ICONS[i], 18, i == tab ? Theme.RED : Theme.DIM, false);
            ic.setGravity(Gravity.CENTER);
            TextView t = tv(TABS[i], 11, i == tab ? Theme.TEXT : Theme.DIM, i == tab);
            t.setGravity(Gravity.CENTER);
            b.addView(ic);
            b.addView(t);
            b.setOnClickListener(v -> showTab(k));
            nav.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
        }
    }

    void showTab(int t) {
        tab = t;
        buildNav();
        while (!stack.isEmpty()) {
            Screen s = stack.remove(stack.size() - 1);
            if (s.onClose != null) s.onClose.run();
        }
        content.removeAllViews();
        Screen s;
        switch (t) {
            case 1: s = garageScreen(); break;
            case 2: s = ranksScreen(); break;
            case 3: s = arcadeScreen(); break;
            case 4: s = settingsScreen(); break;
            default: s = libraryScreen();
        }
        push(s);
    }

    void push(Screen s) {
        if (!stack.isEmpty()) stack.get(stack.size() - 1).view.setVisibility(View.GONE);
        stack.add(s);
        content.addView(s.view, new FrameLayout.LayoutParams(-1, -1));
        refreshChrome();
    }

    void pop() {
        Screen s = stack.remove(stack.size() - 1);
        if (s.onClose != null) s.onClose.run();
        content.removeView(s.view);
        if (!stack.isEmpty()) stack.get(stack.size() - 1).view.setVisibility(View.VISIBLE);
        refreshChrome();
    }

    void refreshChrome() {
        Screen top = stack.get(stack.size() - 1);
        titleView.setText(top.title);
        backView.setVisibility(stack.size() > 1 ? View.VISIBLE : View.GONE);
        nav.setVisibility(top.full ? View.GONE : View.VISIBLE);
        if (top.full) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    Screen screen(String title, View v) {
        Screen s = new Screen();
        s.title = title;
        s.view = v;
        return s;
    }

    // ------------------------------------------------------------------ ui kit

    int dp(float v) { return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()); }

    TextView tv(String text, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    LinearLayout vbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    LinearLayout hbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    GradientDrawable round(int color, float r) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(r));
        return d;
    }

    LinearLayout card() {
        LinearLayout c = vbox();
        c.setBackground(round(Theme.PANEL, 14));
        c.setPadding(dp(14), dp(12), dp(14), dp(12));
        return c;
    }

    LinearLayout.LayoutParams mlp(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    TextView chip(String text, boolean on, View.OnClickListener l) {
        TextView t = tv(text, 13, on ? Theme.TEXT : Theme.DIM, on);
        t.setPadding(dp(12), dp(7), dp(12), dp(7));
        GradientDrawable d = round(on ? Theme.alpha(Theme.RED, 0.25f) : 0x22FFFFFF, 18);
        if (on) d.setStroke(dp(1), Theme.RED);
        t.setBackground(d);
        t.setOnClickListener(l);
        return t;
    }

    TextView button(String text, int fill, int fg, View.OnClickListener l) {
        TextView t = tv(text, 14, fg, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), dp(12), dp(14), dp(12));
        t.setBackground(round(fill, 12));
        t.setOnClickListener(l);
        return t;
    }

    HorizontalScrollView chipRow(View... chips) {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = hbox();
        row.setPadding(dp(12), dp(4), dp(12), dp(4));
        for (View c : chips) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
            p.setMargins(0, 0, dp(8), 0);
            row.addView(c, p);
        }
        hs.addView(row);
        return hs;
    }

    View specRow(String k, String v) {
        LinearLayout r = hbox();
        r.setPadding(0, dp(5), 0, dp(5));
        TextView a = tv(k, 13, Theme.DIM, false);
        TextView b = tv(v, 14, Theme.TEXT, true);
        b.setGravity(Gravity.END);
        r.addView(a, new LinearLayout.LayoutParams(0, -2, 1));
        r.addView(b, new LinearLayout.LayoutParams(0, -2, 1.4f));
        return r;
    }

    void haptic(long ms, int amp) {
        if (store.vibe == 0 || vib == null || !vib.hasVibrator()) return;
        if (store.vibe == 1) { amp = (int) (amp * 0.4f); ms = Math.max(8, ms * 2 / 3); }
        try {
            vib.vibrate(VibrationEffect.createOneShot(ms, Math.max(1, Math.min(255, amp))));
        } catch (Exception ignored) { }
    }

    static String pw(float kw) { return Units.pow(kw); }

    String engineLine(Engine e) {
        return e.make + " · " + e.shortLayout() + " · " + Units.disp(e.cc) + (e.turbos > 0 || e.sc ? " · " + (e.turbos > 0 ? (e.turbos > 1 ? e.turbos + "T" : "T") : "") + (e.sc ? "SC" : "") : "") + (e.twoStroke() ? " · 2T" : "");
    }

    String est(Engine e) { return e.est ? "≈ " : (e.claimed ? "claimed " : ""); }

    // ------------------------------------------------------------------ engine picker

    interface Pick<T> { void on(T t); }

    void pickEngine(String title, Pick<Engine> cb) {
        LinearLayout box = vbox();
        box.setPadding(dp(12), dp(8), dp(12), 0);
        EditText q = new EditText(this);
        q.setHint("Search engines");
        q.setTextColor(Theme.TEXT);
        q.setHintTextColor(Theme.FAINT);
        q.setSingleLine(true);
        box.addView(q);
        ListView lv = new ListView(this);
        final ArrayList<Engine> items = new ArrayList<>(db.all);
        items.sort((a, b) -> Float.compare(b.kw, a.kw));
        final ArrayList<Engine> shown = new ArrayList<>(items);
        BaseAdapter ad = new BaseAdapter() {
            public int getCount() { return shown.size(); }
            public Object getItem(int i) { return shown.get(i); }
            public long getItemId(int i) { return i; }
            public View getView(int i, View c, ViewGroup p) {
                TextView t = c instanceof TextView ? (TextView) c : tv("", 14, Theme.TEXT, false);
                Engine e = shown.get(i);
                t.setText(e.title() + "\n" + pw(e.kw) + " · " + engineLine(e));
                t.setPadding(dp(4), dp(8), dp(4), dp(8));
                return t;
            }
        };
        lv.setAdapter(ad);
        box.addView(lv, new LinearLayout.LayoutParams(-1, dp(420)));
        AlertDialog d = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle(title).setView(box).setNegativeButton("Cancel", null).create();
        q.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            public void onTextChanged(CharSequence s, int a, int b, int c) { }
            public void afterTextChanged(Editable s) {
                String k = s.toString().toLowerCase(Locale.US).trim();
                shown.clear();
                for (Engine e : items) if (k.isEmpty() || (e.title() + " " + e.code).toLowerCase(Locale.US).contains(k)) shown.add(e);
                ad.notifyDataSetChanged();
            }
        });
        lv.setOnItemClickListener((p, v, i, id) -> { d.dismiss(); cb.on(shown.get(i)); });
        d.show();
    }

    void pickVehicle(String title, Pick<Vehicle> cb) {
        final ArrayList<Vehicle> all = new ArrayList<>();
        for (Engine e : db.all) for (Vehicle v : e.vehicles) if (v.road()) all.add(v);
        all.sort((a, b) -> Float.compare(b.kw(), a.kw()));
        LinearLayout box = vbox();
        box.setPadding(dp(12), dp(8), dp(12), 0);
        EditText q = new EditText(this);
        q.setHint("Search vehicles");
        q.setTextColor(Theme.TEXT);
        q.setHintTextColor(Theme.FAINT);
        q.setSingleLine(true);
        box.addView(q);
        ListView lv = new ListView(this);
        final ArrayList<Vehicle> shown = new ArrayList<>(all);
        BaseAdapter ad = new BaseAdapter() {
            public int getCount() { return shown.size(); }
            public Object getItem(int i) { return shown.get(i); }
            public long getItemId(int i) { return i; }
            public View getView(int i, View c, ViewGroup p) {
                TextView t = c instanceof TextView ? (TextView) c : tv("", 14, Theme.TEXT, false);
                Vehicle v = shown.get(i);
                t.setText(v.name + "\n" + pw(v.kw() * v.count) + " · " + v.engine.make + " " + v.engine.name);
                t.setPadding(dp(4), dp(8), dp(4), dp(8));
                return t;
            }
        };
        lv.setAdapter(ad);
        box.addView(lv, new LinearLayout.LayoutParams(-1, dp(420)));
        AlertDialog d = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle(title).setView(box).setNegativeButton("Cancel", null).create();
        q.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            public void onTextChanged(CharSequence s, int a, int b, int c) { }
            public void afterTextChanged(Editable s) {
                String k = s.toString().toLowerCase(Locale.US).trim();
                shown.clear();
                for (Vehicle v : all) if (k.isEmpty() || (v.name + " " + v.engine.title()).toLowerCase(Locale.US).contains(k)) shown.add(v);
                ad.notifyDataSetChanged();
            }
        });
        lv.setOnItemClickListener((p, v, i, id) -> { d.dismiss(); cb.on(shown.get(i)); });
        d.show();
    }

    // ------------------------------------------------------------------ library

    String libQuery = "";
    String libFilter = "all";
    int libSort = 0;
    boolean libAsc;
    static final String[][] FILTERS = {{"all", "All"}, {"fav", "★ Favourites"}, {"car", "Cars"}, {"bike", "Bikes"}, {"2t", "2-Stroke"}, {"diesel", "Diesel"}, {"turbo", "Turbo"}, {"sc", "Supercharged"}, {"na", "Naturally aspirated"}, {"rotary", "Rotary"}, {"race", "Race"}, {"f1", "Formula 1"}, {"air", "Aircraft"}, {"heavy", "Trucks & trains"}, {"marine", "Ships"}, {"tiny", "Tiny"}, {"giant", "Giants"}};
    static final String[] SORTS = {"Power", "Torque", "Displacement", "hp / litre", "Redline", "Cylinders", "Year", "A–Z"};

    float sortKey(Engine e, int k) {
        switch (k) {
            case 1: return e.nm;
            case 2: return e.cc;
            case 3: return e.hpPerLiter();
            case 4: return e.redline;
            case 5: return e.cyl;
            case 6: return e.year;
        }
        return e.kw;
    }

    Screen libraryScreen() {
        LinearLayout root = vbox();
        EditText search = new EditText(this);
        search.setHint("Search " + db.all.size() + " engines, codes or vehicles");
        search.setHintTextColor(Theme.FAINT);
        search.setTextColor(Theme.TEXT);
        search.setSingleLine(true);
        search.setInputType(InputType.TYPE_CLASS_TEXT);
        search.setBackground(round(Theme.PANEL, 12));
        search.setPadding(dp(14), dp(10), dp(14), dp(10));
        search.setText(libQuery);
        root.addView(search, mlp(12, 4, 12, 4));
        LinearLayout filterHolder = vbox();
        root.addView(filterHolder);
        ListView list = new ListView(this);
        list.setDivider(null);
        list.setSelector(android.R.color.transparent);
        final ArrayList<Engine> shown = new ArrayList<>();
        final float[] maxLog = {1};
        BaseAdapter ad = new BaseAdapter() {
            public int getCount() { return shown.size(); }
            public Object getItem(int i) { return shown.get(i); }
            public long getItemId(int i) { return i; }
            public View getView(int i, View c, ViewGroup parent) {
                Engine e = shown.get(i);
                LinearLayout row = c instanceof LinearLayout ? (LinearLayout) c : engineRow();
                ((TextView) row.getChildAt(0)).setText(String.valueOf(i + 1));
                LinearLayout mid = (LinearLayout) row.getChildAt(1);
                ((TextView) mid.getChildAt(0)).setText((store.isFav(e.id) ? "★ " : "") + e.make + " " + e.name);
                ((TextView) mid.getChildAt(1)).setText(engineLine(e) + " · " + e.years);
                View bar = mid.getChildAt(2);
                float frac = (float) (Math.log10(Math.max(0.05, e.hp()) + 1) / maxLog[0]);
                LinearLayout.LayoutParams bp = (LinearLayout.LayoutParams) bar.getLayoutParams();
                bp.width = (int) (dp(180) * Math.max(0.03f, frac));
                bar.setLayoutParams(bp);
                LinearLayout right = (LinearLayout) row.getChildAt(2);
                String val;
                switch (libSort) {
                    case 1: val = Units.tq(e.nm); break;
                    case 2: val = Units.disp(e.cc); break;
                    case 3: val = Math.round(e.hpPerLiter()) + " hp/L"; break;
                    case 4: val = Units.rpm(e.redline); break;
                    case 5: val = e.cyl + (e.wankel() ? " rotors" : " cyl"); break;
                    case 6: val = e.years; break;
                    default: val = est(e) + pw(e.kw);
                }
                ((TextView) right.getChildAt(0)).setText(val);
                ((TextView) right.getChildAt(1)).setText(libSort == 0 ? Units.rpm(e.rpmP) : pw(e.kw));
                return row;
            }
        };
        list.setAdapter(ad);
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
        final Runnable[] refresh = new Runnable[1];
        refresh[0] = () -> {
            filterHolder.removeAllViews();
            View[] fc = new View[FILTERS.length];
            for (int i = 0; i < FILTERS.length; i++) {
                final String key = FILTERS[i][0];
                fc[i] = chip(FILTERS[i][1], key.equals(libFilter), v -> { libFilter = key; refresh[0].run(); });
            }
            filterHolder.addView(chipRow(fc));
            View[] sc = new View[SORTS.length];
            for (int i = 0; i < SORTS.length; i++) {
                final int k = i;
                String lbl = SORTS[i] + (k == libSort ? (libAsc ? " ↑" : " ↓") : "");
                sc[i] = chip(lbl, k == libSort, v -> { if (libSort == k) libAsc = !libAsc; else { libSort = k; libAsc = k == 7; } refresh[0].run(); });
            }
            filterHolder.addView(chipRow(sc));
            shown.clear();
            String q = libQuery.toLowerCase(Locale.US).trim();
            Set<String> favs = store.favs();
            for (Engine e : db.all) {
                if (libFilter.equals("fav")) { if (!favs.contains(e.id)) continue; }
                else if (!libFilter.equals("all") && !e.has(libFilter)) continue;
                if (!q.isEmpty()) {
                    StringBuilder hay = new StringBuilder(e.title() + " " + e.code + " " + e.layoutName() + " " + e.years);
                    for (Vehicle v : e.vehicles) hay.append(' ').append(v.name);
                    if (!hay.toString().toLowerCase(Locale.US).contains(q)) continue;
                }
                shown.add(e);
            }
            final int sk = libSort;
            if (sk == 7) shown.sort(Comparator.comparing(Engine::title));
            else shown.sort((a, b) -> Float.compare(sortKey(b, sk), sortKey(a, sk)));
            if (libAsc) Collections.reverse(shown);
            maxLog[0] = 1;
            for (Engine e : db.all) maxLog[0] = Math.max(maxLog[0], (float) Math.log10(e.hp() + 1));
            ad.notifyDataSetChanged();
            titleView.setText("REDLINE · " + shown.size() + " engines");
        };
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            public void onTextChanged(CharSequence s, int a, int b, int c) { }
            public void afterTextChanged(Editable s) { libQuery = s.toString(); refresh[0].run(); }
        });
        // engine of the day header
        Engine eod = db.all.isEmpty() ? null : db.all.get((int) ((System.currentTimeMillis() / 86400000L) % db.all.size()));
        if (eod != null) {
            LinearLayout c = card();
            c.addView(tv("ENGINE OF THE DAY", 11, Theme.RED, true));
            c.addView(tv(eod.title(), 17, Theme.TEXT, true));
            TextView n = tv(eod.note, 13, Theme.DIM, false);
            c.addView(n);
            c.setOnClickListener(v -> push(engineScreen(eod)));
            LinearLayout wrap = vbox();
            wrap.setPadding(dp(12), dp(6), dp(12), dp(6));
            wrap.addView(c);
            list.addHeaderView(wrap);
        }
        list.setOnItemClickListener((p, v, i, id) -> {
            int idx = i - list.getHeaderViewsCount();
            if (idx >= 0 && idx < shown.size()) push(engineScreen(shown.get(idx)));
        });
        list.setOnItemLongClickListener((p, v, i, id) -> {
            int idx = i - list.getHeaderViewsCount();
            if (idx < 0 || idx >= shown.size()) return false;
            store.toggleFav(shown.get(idx).id);
            ad.notifyDataSetChanged();
            Toast.makeText(this, store.isFav(shown.get(idx).id) ? "Added to favourites" : "Removed from favourites", Toast.LENGTH_SHORT).show();
            return true;
        });
        refresh[0].run();
        Screen s = screen("REDLINE · " + shown.size() + " engines", root);
        s.onClose = null;
        return s;
    }

    LinearLayout engineRow() {
        LinearLayout row = hbox();
        row.setPadding(dp(12), dp(9), dp(14), dp(9));
        TextView rank = tv("", 13, Theme.FAINT, true);
        rank.setGravity(Gravity.CENTER);
        row.addView(rank, new LinearLayout.LayoutParams(dp(34), -2));
        LinearLayout mid = vbox();
        TextView name = tv("", 15, Theme.TEXT, true);
        name.setSingleLine(true);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        TextView sub = tv("", 12, Theme.DIM, false);
        sub.setSingleLine(true);
        sub.setEllipsize(android.text.TextUtils.TruncateAt.END);
        View bar = new View(this);
        bar.setBackground(round(Theme.RED, 3));
        mid.addView(name);
        mid.addView(sub);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(60), dp(4));
        bp.topMargin = dp(5);
        mid.addView(bar, bp);
        row.addView(mid, new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout right = vbox();
        right.setGravity(Gravity.END);
        TextView v1 = tv("", 15, Theme.TEXT, true);
        v1.setGravity(Gravity.END);
        TextView v2 = tv("", 11, Theme.FAINT, false);
        v2.setGravity(Gravity.END);
        right.addView(v1);
        right.addView(v2);
        row.addView(right, new LinearLayout.LayoutParams(-2, -2));
        return row;
    }

    // ------------------------------------------------------------------ engine detail

    Screen engineScreen(Engine e) {
        ScrollView sv = new ScrollView(this);
        LinearLayout root = vbox();
        root.setPadding(0, 0, 0, dp(24));
        sv.addView(root);
        LinearLayout head = vbox();
        head.setPadding(dp(16), dp(4), dp(16), dp(6));
        head.addView(tv(e.make.toUpperCase(Locale.US) + (e.code.isEmpty() ? "" : " · " + e.code), 12, Theme.RED, true));
        head.addView(tv(e.name, 22, Theme.TEXT, true));
        head.addView(tv(est(e) + pw(e.kw) + " @ " + Units.rpm(e.rpmP) + "  ·  " + (e.nmEst ? "≈ " : "") + Units.tq(e.nm) + "  ·  " + e.years, 13, Theme.DIM, false));
        root.addView(head);
        final EngineViewer viewer = new EngineViewer(e);
        viewer.quality = store.quality;
        viewer.photoTarget = store.photoSamples;
        viewer.rpm = Math.max(e.idle * 1.5f, e.redline * 0.25f);
        GView gv = new GView(this, viewer);
        int vh = (int) (getResources().getDisplayMetrics().heightPixels * 0.5f);
        root.addView(gv, new LinearLayout.LayoutParams(-1, vh));
        // modes
        LinearLayout modeHolder = vbox();
        root.addView(modeHolder);
        final Runnable[] buildModes = new Runnable[1];
        buildModes[0] = () -> {
            modeHolder.removeAllViews();
            View[] m = new View[Raster.MODES.length + 1];
            for (int i = 0; i < Raster.MODES.length; i++) {
                final int k = i;
                m[i] = chip(Raster.MODES[i], !viewer.photo && viewer.mode == k, v -> { viewer.setPhoto(false); viewer.setMode(k); buildModes[0].run(); });
            }
            m[Raster.MODES.length] = chip("📷 Ray-traced photo", viewer.photo, v -> { viewer.setPhoto(!viewer.photo); buildModes[0].run(); });
            modeHolder.addView(chipRow(m));
            modeHolder.addView(chipRow(
                    chip("Labels", viewer.labels, v -> { viewer.labels = !viewer.labels; buildModes[0].run(); }),
                    chip("Auto-spin", viewer.autoRotate, v -> { viewer.autoRotate = !viewer.autoRotate; buildModes[0].run(); }),
                    chip(viewer.paused ? "▶ Play" : "❚❚ Pause", viewer.paused, v -> { viewer.paused = !viewer.paused; buildModes[0].run(); }),
                    chip("Reset view", false, v -> viewer.resetView()),
                    chip("Slow-mo " + Math.round(1f / viewer.slow) + "×", false, v -> {
                        float[] sl = {1f, 1f / 10f, 1f / 60f, 1f / 250f, 1f / 1000f};
                        int idx = 0;
                        for (int i = 0; i < sl.length; i++) if (Math.abs(sl[i] - viewer.slow) < 1e-6f) idx = i;
                        viewer.slow = sl[(idx + 1) % sl.length];
                        buildModes[0].run();
                    })));
        };
        buildModes[0].run();
        // rpm slider
        LinearLayout rpmRow = hbox();
        rpmRow.setPadding(dp(16), dp(2), dp(16), dp(2));
        TextView rpmLbl = tv("Engine speed", 13, Theme.DIM, false);
        SeekBar sb = new SeekBar(this);
        sb.setMax(1000);
        sb.setProgress((int) ((viewer.rpm - e.idle) / Math.max(1, e.redline - e.idle) * 1000));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) { viewer.rpm = e.idle + (e.redline - e.idle) * p / 1000f; viewer.load = 0.2f + 0.8f * p / 1000f; }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { }
        });
        rpmRow.addView(rpmLbl);
        rpmRow.addView(sb, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(rpmRow);
        // actions
        LinearLayout act = hbox();
        act.setPadding(dp(12), dp(6), dp(12), dp(6));
        TextView revBtn = button("Rev Lab", Theme.RED, Color.WHITE, v -> push(revLabScreen(e, null)));
        TextView tuneBtn = button("Tune & top speed", Theme.PANEL2, Theme.TEXT, v -> push(tuneScreen(e, 0, new Tune(), null)));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(0, -2, 1);
        ap.setMargins(dp(4), 0, dp(4), 0);
        act.addView(revBtn, ap);
        act.addView(tuneBtn, new LinearLayout.LayoutParams(ap));
        root.addView(act);
        LinearLayout act2 = hbox();
        act2.setPadding(dp(12), 0, dp(12), dp(6));
        TextView favBtn = button(store.isFav(e.id) ? "★ Favourite" : "☆ Favourite", Theme.PANEL2, Theme.AMBER, null);
        favBtn.setOnClickListener(v -> { store.toggleFav(e.id); favBtn.setText(store.isFav(e.id) ? "★ Favourite" : "☆ Favourite"); });
        TextView cmpBtn = button("Compare", Theme.PANEL2, Theme.TEXT, v -> pickEngine("Compare with…", other -> push(compareScreen(e, other))));
        act2.addView(favBtn, new LinearLayout.LayoutParams(ap));
        act2.addView(cmpBtn, new LinearLayout.LayoutParams(ap));
        root.addView(act2);
        // specs
        LinearLayout specs = card();
        specs.addView(tv("SPECIFICATIONS", 11, Theme.RED, true));
        specs.addView(specRow("Layout", e.layoutName()));
        specs.addView(specRow("Displacement", Units.disp(e.cc)));
        if (!e.wankel()) specs.addView(specRow("Bore × stroke", String.format(Locale.US, "%.1f × %.1f mm%s", e.bore, e.stroke, e.boreKnown ? "" : " (est.)")));
        specs.addView(specRow("Valvetrain", e.wankel() ? "Peripheral/side ports" : e.vtName() + (e.valves > 0 ? " · " + e.valves + " valves/cyl" : "")));
        specs.addView(specRow("Induction", e.aspName()));
        specs.addView(specRow("Fuel · cycle", e.fuelName() + " · " + (e.wankel() ? "Wankel" : (e.twoStroke() ? "Two-stroke" : "Four-stroke"))));
        specs.addView(specRow("Power", est(e) + pw(e.kw) + " @ " + Units.rpm(e.rpmP)));
        specs.addView(specRow("Torque", (e.nmEst ? "≈ " : "") + Units.tq(e.nm) + (e.rpmT > 0 ? " @ " + Units.rpm(e.rpmT) : "")));
        specs.addView(specRow("Redline", Units.rpm(e.redline)));
        specs.addView(specRow("Specific output", String.format(Locale.US, "%.0f hp per litre", e.hpPerLiter())));
        if (!e.wankel()) specs.addView(specRow("Mean piston speed", String.format(Locale.US, "%.1f m/s at redline", e.meanPistonSpeed())));
        specs.addView(specRow("Cooling", e.air ? "Air" : (e.oilCooled ? "Air/oil" : "Liquid")));
        if (e.engineKg > 0) specs.addView(specRow("Engine mass", Units.mass(e.engineKg)));
        specs.addView(specRow("Lubrication", e.drySump ? "Dry sump" : (e.twoStroke() && e.cc < 2000 ? "Oil in fuel mix" : "Wet sump")));
        String vis = visualProfile(e);
        if (!vis.isEmpty()) specs.addView(specRow("Modelled hardware", vis));
        if (e.est || e.claimed || e.nmEst) {
            TextView n = tv((e.claimed ? "Manufacturer claim, not independently verified. " : "") + (e.est || e.nmEst ? "Some figures are approximate (≈)." : ""), 12, Theme.AMBER, false);
            n.setPadding(0, dp(6), 0, 0);
            specs.addView(n);
        }
        root.addView(specs, mlp(12, 6, 12, 6));
        if (!e.note.isEmpty()) {
            LinearLayout nc = card();
            nc.addView(tv("DID YOU KNOW", 11, Theme.RED, true));
            nc.addView(tv(e.note, 14, Theme.TEXT, false));
            root.addView(nc, mlp(12, 6, 12, 6));
        }
        // dyno
        LinearLayout dc = card();
        dc.addView(tv("DYNO · power (solid) and torque (dashed)", 11, Theme.RED, true));
        final Curve stock = Curve.stock(e);
        GView dyno = new GView(this, new StaticPainter((g, w, h) -> DynoChart.draw(g, 0, 0, w, h, new Curve[]{stock}, new int[]{Theme.RED}, null, Math.max(14f, w / 30f), -1)));
        dyno.grabTouch = false;
        dc.addView(dyno, new LinearLayout.LayoutParams(-1, dp(220)));
        root.addView(dc, mlp(12, 6, 12, 6));
        // vehicles
        LinearLayout vc = card();
        vc.addView(tv("USED IN · tap to tune & run", 11, Theme.RED, true));
        for (int i = 0; i < e.vehicles.size(); i++) {
            final int vi = i;
            Vehicle v = e.vehicles.get(i);
            LinearLayout r = hbox();
            r.setPadding(0, dp(8), 0, dp(8));
            LinearLayout l = vbox();
            l.addView(tv(v.name, 15, Theme.TEXT, true));
            String sub = v.typeName() + " · " + v.years + (v.kg > 0 ? " · " + Units.mass(v.kg) : "") + (v.count > 1 ? " · " + v.count + " engines" : "") + (v.kwOverride > 0 ? " · " + pw(v.kwOverride) + " version" : "");
            l.addView(tv(sub, 12, Theme.DIM, false));
            r.addView(l, new LinearLayout.LayoutParams(0, -2, 1));
            TextView top = tv(v.topText(Units.mph), 13, Theme.TEXT, true);
            r.addView(top);
            r.setOnClickListener(x -> push(tuneScreen(e, vi, new Tune(), null)));
            vc.addView(r);
        }
        root.addView(vc, mlp(12, 6, 12, 6));
        Screen s = screen(e.make + " " + e.name, sv);
        s.onClose = viewer::dispose;
        return s;
    }

    String visualProfile(Engine e) {
        ArrayList<String> p = new ArrayList<>();
        switch (e.intake) {
            case "itb": p.add("individual throttle bodies"); break;
            case "box": p.add("induction box" + (e.nthr > 0 ? " with " + e.nthr + " throttles" : "")); break;
            case "webers": p.add("downdraft Weber carbs"); break;
            case "carb4": p.add("four-barrel carb"); break;
            case "carb2x4": p.add("2 × four-barrel carbs"); break;
            case "carb": p.add(e.ncarb > 0 ? e.ncarb + " carburettor" + (e.ncarb > 1 ? "s" : "") : "carb per cylinder"); break;
            case "long": p.add("long-runner intake over the head"); break;
            case "updraft": p.add("updraught carb + supercharger"); break;
            case "hat": p.add("injector hat on blower"); break;
            case "plen": p.add("plenum intake" + (e.nthr > 1 ? " (" + e.nthr + " throttles)" : "")); break;
        }
        if (e.turbos > 0) {
            String tp = e.tp.isEmpty() ? "side" : e.tp;
            p.add(e.turbos + " turbo" + (e.turbos > 1 ? "s" : "") + (tp.equals("hv") ? " in the hot vee" : tp.equals("rear") ? " at the rear" : tp.equals("top") ? " on top" : "") + (e.seqTurbo ? " (sequential)" : ""));
        }
        if (!e.scx.isEmpty() || e.sc) p.add((e.scx.isEmpty() ? "roots" : e.scx.equals("tvs") ? "TVS" : e.scx.equals("screw") ? "twin-screw" : e.scx.equals("cent") ? "centrifugal" : e.scx.equals("gear") ? "gear-driven" : "Roots") + " supercharger");
        if (e.ic.equals("top")) p.add("top-mounted intercooler");
        if (e.timingRear) p.add("timing drive at the gearbox end");
        if (e.ex.equals("stubs")) p.add("exhaust stubs");
        if (e.ex.equals("top")) p.add("top-exit exhausts");
        if (e.ex.equals("zoomie")) p.add("zoomie headers");
        if (e.fan.equals("shroud")) p.add("fan shroud");
        if (e.gbxSump) p.add("gearbox in sump");
        if (e.tilt != 0) p.add("cylinders inclined " + Math.round(Math.abs(e.tilt)) + "°");
        return String.join(", ", p);
    }

    /** A painter that only draws once per invalidate (charts). */
    static final class StaticPainter implements Painter {
        interface Draw { void draw(Gfx g, float w, float h); }
        final Draw d;
        StaticPainter(Draw d) { this.d = d; }
        public void paint(Gfx g, float w, float h, float dt) { d.draw(g, w, h); }
        public void touch(int a, int id, float x, float y) { }
        public boolean animating() { return false; }
    }

    // ------------------------------------------------------------------ rev lab

    Screen revLabScreen(Engine e, Tune t) {
        final RevLab lab = new RevLab(e, t);
        lab.viewer.quality = store.quality;
        GView gv = new GView(this, lab);
        final long[] lastVibe = {0};
        gv.afterFrame = () -> {
            long now = System.currentTimeMillis();
            if (lab.hapticPulse) { haptic(22, 255); lastVibe[0] = now; }
            else if (lab.hapticBang) { haptic(45, 220); lastVibe[0] = now; }
            else if (lab.haptic > 0.12f && now - lastVibe[0] > 70) { haptic(28, (int) (lab.haptic * 200)); lastVibe[0] = now; }
        };
        Screen s = screen("Rev Lab · " + e.name, gv);
        s.full = true;
        s.onClose = lab::dispose;
        return s;
    }

    // ------------------------------------------------------------------ tuning

    interface IntSet { void set(int v); }

    Screen tuneScreen(Engine e, int vehIdx, Tune initial, String buildName) {
        final Tune t = initial.copy();
        final int[] vi = {Math.max(0, Math.min(vehIdx, e.vehicles.size() - 1))};
        ScrollView sv = new ScrollView(this);
        LinearLayout root = vbox();
        root.setPadding(dp(12), dp(4), dp(12), dp(24));
        sv.addView(root);
        if (e.vehicles.isEmpty()) {
            root.addView(tv("No vehicles for this engine.", 14, Theme.DIM, false));
            return screen("Tune", sv);
        }
        // vehicle selector
        LinearLayout vc = card();
        vc.addView(tv("VEHICLE", 11, Theme.RED, true));
        TextView vName = tv("", 16, Theme.TEXT, true);
        TextView vSub = tv("", 12, Theme.DIM, false);
        vc.addView(vName);
        vc.addView(vSub);
        if (e.vehicles.size() > 1) vc.addView(tv("Tap to switch vehicle", 11, Theme.FAINT, false));
        root.addView(vc, mlp(0, 4, 0, 6));
        // results
        LinearLayout rc = card();
        root.addView(rc, mlp(0, 4, 0, 6));
        final Curve stock = Curve.stock(e);
        final Curve[] tuned = {stock};
        final Perf[] perf = {null};
        GView dyno = new GView(this, new StaticPainter((g, w, h) -> DynoChart.draw(g, 0, 0, w, h, new Curve[]{stock, tuned[0]}, new int[]{Theme.FAINT, Theme.RED}, new String[]{"Stock", "Tuned"}, Math.max(14f, w / 30f), -1)));
        dyno.grabTouch = false;
        final Runnable[] update = new Runnable[1];
        update[0] = () -> {
            Vehicle v = e.vehicles.get(vi[0]);
            vName.setText(v.name);
            vSub.setText(v.typeName() + " · " + v.years + (v.kg > 0 ? " · " + Units.mass(v.kg) : "") + " · documented top " + v.topText(Units.mph));
            tuned[0] = Curve.build(e, t);
            Perf p = Perf.run(v, t, stock, tuned[0], false);
            perf[0] = p;
            float scale = v.kw() / e.kw * v.count;
            rc.removeAllViews();
            rc.addView(tv("RESULT" + (t.isStock() ? " · stock" : " · tuned"), 11, Theme.RED, true));
            LinearLayout big = hbox();
            TextView pwr = tv(pw(tuned[0].peakKw * scale), 26, Theme.TEXT, true);
            big.addView(pwr, new LinearLayout.LayoutParams(0, -2, 1));
            TextView topv = tv(p.top > 0 ? Units.spd(p.top) : "—", 26, Theme.CYAN, true);
            topv.setGravity(Gravity.END);
            big.addView(topv, new LinearLayout.LayoutParams(0, -2, 1));
            rc.addView(big);
            float gain = tuned[0].peakKw / stock.peakKw - 1f;
            rc.addView(specRow("Peak torque", Units.tq(tuned[0].peakNm * scale) + " @ " + Units.rpm(tuned[0].rpmPeakNm)));
            rc.addView(specRow("Power gain", String.format(Locale.US, "%+.0f%%", gain * 100)));
            rc.addView(specRow("Top speed", (p.top > 0 ? Units.spd(p.top) : "—") + (p.limit.isEmpty() ? "" : " · " + p.limit)));
            if (!p.estimateOnly) {
                rc.addView(specRow("0–100 km/h", Units.secs(p.t100)));
                rc.addView(specRow("0–200 km/h", Units.secs(p.t200)));
                if (p.t300 > 0) rc.addView(specRow("0–300 km/h", Units.secs(p.t300)));
                if (p.t400 > 0) rc.addView(specRow("0–400 km/h", Units.secs(p.t400)));
                rc.addView(specRow("Quarter mile", p.quarter > 0 ? String.format(Locale.US, "%.2f s @ %s", p.quarter, Units.spd(p.trap)) : "—"));
                rc.addView(specRow("Power-to-weight", String.format(Locale.US, "%.1f kg per hp", p.massKg / Math.max(0.001f, p.powerKw / 0.7457f))));
            }
            float stress = t.stress(e, stock, tuned[0]);
            int sc = stress < 40 ? Theme.GREEN : (stress < 70 ? Theme.AMBER : Theme.RED);
            TextView st = tv("Engine stress: " + Tune.stressLabel(stress) + " (" + Math.round(stress) + "%)", 13, sc, true);
            st.setPadding(0, dp(6), 0, 0);
            rc.addView(st);
            dyno.invalidate();
        };
        vc.setOnClickListener(v -> {
            if (e.vehicles.size() < 2) return;
            String[] names = new String[e.vehicles.size()];
            for (int i = 0; i < names.length; i++) names[i] = e.vehicles.get(i).name;
            new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Vehicle").setItems(names, (d, w) -> { vi[0] = w; update[0].run(); }).show();
        });
        // buttons
        LinearLayout b1 = hbox();
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(0, -2, 1);
        ap.setMargins(dp(3), 0, dp(3), 0);
        b1.addView(button("▶ Top speed run", Theme.RED, Color.WHITE, v -> {
            Vehicle veh = e.vehicles.get(vi[0]);
            if (!veh.road()) { Toast.makeText(this, "Top-speed runs are for road vehicles; this one is estimated from its documented speed.", Toast.LENGTH_LONG).show(); return; }
            push(runScreen(new Object[][]{{veh, t.copy(), t.isStock() ? "Stock" : "Tuned"}}, false));
        }), ap);
        b1.addView(button("▶ Drag vs stock", Theme.PANEL2, Theme.TEXT, v -> {
            Vehicle veh = e.vehicles.get(vi[0]);
            if (!veh.road()) return;
            push(runScreen(new Object[][]{{veh, t.copy(), "Tuned"}, {veh, new Tune(), "Stock"}}, true));
        }), new LinearLayout.LayoutParams(ap));
        root.addView(b1, mlp(0, 2, 0, 6));
        LinearLayout b2 = hbox();
        b2.addView(button("Rev Lab (tuned)", Theme.PANEL2, Theme.TEXT, v -> push(revLabScreen(e, t.copy()))), new LinearLayout.LayoutParams(ap));
        b2.addView(button("Save to Garage", Theme.PANEL2, Theme.AMBER, v -> {
            EditText in = new EditText(this);
            in.setText(buildName != null ? buildName : e.vehicles.get(vi[0]).name + " build");
            in.setTextColor(Theme.TEXT);
            new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Name your build").setView(in).setPositiveButton("Save", (d, w) -> {
                Store.Build b = new Store.Build();
                b.name = in.getText().toString();
                b.engineId = e.id;
                b.vehicle = vi[0];
                b.tune = t.encode();
                Vehicle veh = e.vehicles.get(vi[0]);
                b.kw = tuned[0].peakKw * veh.kw() / e.kw * veh.count;
                b.top = perf[0] != null ? perf[0].top : 0;
                b.time = System.currentTimeMillis();
                store.addBuild(b);
                Toast.makeText(this, "Saved to Garage", Toast.LENGTH_SHORT).show();
            }).setNegativeButton("Cancel", null).show();
        }), new LinearLayout.LayoutParams(ap));
        root.addView(b2, mlp(0, 0, 0, 6));
        LinearLayout dc = card();
        dc.addView(tv("DYNO · stock vs tuned", 11, Theme.RED, true));
        dc.addView(dyno, new LinearLayout.LayoutParams(-1, dp(220)));
        root.addView(dc, mlp(0, 4, 0, 6));
        // controls
        LinearLayout cc = card();
        root.addView(cc, mlp(0, 4, 0, 6));
        final Runnable[] buildControls = new Runnable[1];
        buildControls[0] = () -> {
            cc.removeAllViews();
            boolean two = e.twoStroke();
            boolean boosted = e.turbos > 0 || e.sc;
            boolean carb = e.intake.startsWith("carb") || e.intake.equals("webers") || e.intake.equals("updraft");
            cc.addView(tv("ENGINE", 11, Theme.RED, true));
            stepRow(cc, carb ? "Jetting / ECU" : "ECU remap", Tune.ECU, t.ecu, v -> { t.ecu = v; update[0].run(); });
            stepRow(cc, two ? "Air filter / carb" : "Intake", Tune.LVL, t.intake, v -> { t.intake = v; update[0].run(); });
            stepRow(cc, two ? "Expansion chamber" : "Exhaust", Tune.LVL, t.exhaust, v -> { t.exhaust = v; update[0].run(); });
            stepRow(cc, two || e.wankel() ? "Porting" : "Camshafts", Tune.LVL, t.cams, v -> { t.cams = v; update[0].run(); });
            stepRow(cc, "Big-bore kit", new String[]{"Stock", "+10%", "+20%", "+40%"}, t.bigBore, v -> { t.bigBore = v; update[0].run(); });
            stepRow(cc, "Rev limit", new String[]{"Stock", "+5%", "+10%", "+15%", "+20%"}, t.revs, v -> { t.revs = v; update[0].run(); });
            stepRow(cc, "Forged internals", new String[]{"No", "Yes"}, t.forged, v -> { t.forged = v; update[0].run(); });
            cc.addView(tv("INDUCTION", 11, Theme.RED, true));
            if (boosted) {
                String[] bst = new String[21];
                for (int i = 0; i <= 20; i++) bst[i] = String.format(Locale.US, "+%.1f bar", i * 0.1f);
                slideRow(cc, "Extra boost", bst, t.boost, v -> { t.boost = v; update[0].run(); });
            } else {
                stepRow(cc, "Forced-induction kit", Tune.KIT, t.kit, v -> { t.kit = v; if (v > 0 && t.boost == 0) t.boost = 6; buildControls[0].run(); update[0].run(); });
                if (t.kit > 0) {
                    String[] bst = new String[16];
                    for (int i = 0; i <= 15; i++) bst[i] = String.format(Locale.US, "%.1f bar", Math.max(0.3f, i * 0.1f));
                    slideRow(cc, "Kit boost", bst, t.boost, v -> { t.boost = v; update[0].run(); });
                }
            }
            if (boosted || t.kit > 0) stepRow(cc, "Intercooler upgrade", new String[]{"No", "Yes"}, t.intercooler, v -> { t.intercooler = v; update[0].run(); });
            if (!e.diesel()) stepRow(cc, "Fuel", Tune.FUEL, t.fuel, v -> { t.fuel = v; update[0].run(); });
            stepRow(cc, "Nitrous", new String[]{"Off", "15%", "30%", "50%", "75%"}, t.nitrous, v -> { t.nitrous = v; update[0].run(); });
            cc.addView(tv("CHASSIS", 11, Theme.RED, true));
            stepRow(cc, "Weight reduction", new String[]{"0%", "5%", "10%", "15%", "20%"}, t.weight, v -> { t.weight = v; update[0].run(); });
            stepRow(cc, "Aero", Tune.AERO, t.aero, v -> { t.aero = v; update[0].run(); });
            stepRow(cc, "Tyres", Tune.TIRES, t.tires, v -> { t.tires = v; update[0].run(); });
            String[] fd = {"Taller −18%", "−12%", "−6%", "Stock", "+6%", "+12%", "Shorter +18%"};
            slideRow(cc, "Final drive", fd, t.gearing + 3, v -> { t.gearing = v - 3; update[0].run(); });
            stepRow(cc, "Speed limiter", new String[]{"On", "Removed"}, t.limiterOff, v -> { t.limiterOff = v; update[0].run(); });
            TextView reset = button("Reset to stock", Theme.PANEL2, Theme.DIM, v -> {
                Tune z = new Tune();
                t.ecu = z.ecu; t.intake = z.intake; t.exhaust = z.exhaust; t.cams = z.cams; t.boost = 0; t.kit = 0; t.intercooler = 0; t.fuel = 0; t.nitrous = 0;
                t.bigBore = 0; t.revs = 0; t.forged = 0; t.weight = 0; t.aero = 0; t.tires = 1; t.gearing = 0; t.limiterOff = 0;
                buildControls[0].run();
                update[0].run();
            });
            cc.addView(reset, mlp(0, 10, 0, 0));
        };
        buildControls[0].run();
        update[0].run();
        return screen(buildName != null ? buildName : "Tune · " + e.name, sv);
    }

    void stepRow(LinearLayout parent, String label, String[] opts, int value, IntSet set) {
        LinearLayout row = vbox();
        row.setPadding(0, dp(6), 0, dp(2));
        row.addView(tv(label, 13, Theme.DIM, false));
        View[] chips = new View[opts.length];
        final LinearLayout[] holder = {null};
        for (int i = 0; i < opts.length; i++) {
            final int k = i;
            chips[i] = chip(opts[i], k == value, v -> {
                set.set(k);
                LinearLayout r = (LinearLayout) ((HorizontalScrollView) holder[0].getChildAt(1)).getChildAt(0);
                for (int j = 0; j < r.getChildCount(); j++) {
                    TextView c = (TextView) r.getChildAt(j);
                    boolean on = j == k;
                    c.setTextColor(on ? Theme.TEXT : Theme.DIM);
                    c.setTypeface(on ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
                    GradientDrawable d = round(on ? Theme.alpha(Theme.RED, 0.25f) : 0x22FFFFFF, 18);
                    if (on) d.setStroke(dp(1), Theme.RED);
                    c.setBackground(d);
                }
            });
        }
        HorizontalScrollView hs = chipRow(chips);
        hs.setPadding(-dp(12), 0, 0, 0);
        row.addView(hs);
        holder[0] = row;
        parent.addView(row);
    }

    void slideRow(LinearLayout parent, String label, String[] opts, int value, IntSet set) {
        LinearLayout row = vbox();
        row.setPadding(0, dp(6), 0, dp(2));
        LinearLayout h = hbox();
        h.addView(tv(label, 13, Theme.DIM, false), new LinearLayout.LayoutParams(0, -2, 1));
        TextView val = tv(opts[Math.max(0, Math.min(value, opts.length - 1))], 13, Theme.TEXT, true);
        h.addView(val);
        row.addView(h);
        SeekBar sb = new SeekBar(this);
        sb.setMax(opts.length - 1);
        sb.setProgress(value);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) { val.setText(opts[p]); if (u) set.set(p); }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { }
        });
        row.addView(sb);
        parent.addView(row);
    }

    // ------------------------------------------------------------------ runs

    static final int[] LANE_COLORS = {Theme.RED, Theme.CYAN};

    /** each entry: {Vehicle, Tune, label} */
    Screen runScreen(Object[][] entries, boolean drag) {
        RunScene.Lane[] lanes = new RunScene.Lane[entries.length];
        for (int i = 0; i < entries.length; i++) {
            Vehicle v = (Vehicle) entries[i][0];
            Tune t = (Tune) entries[i][1];
            Curve s = Curve.stock(v.engine), c = Curve.build(v.engine, t);
            RunScene.Lane l = new RunScene.Lane();
            l.name = entries[i].length > 2 ? (String) entries[i][2] : v.name;
            l.sub = v.name;
            l.perf = Perf.run(v, t, s, c, true);
            l.color = LANE_COLORS[i % 2];
            l.redline = t.redline(v.engine);
            lanes[i] = l;
        }
        RunScene rs = new RunScene(lanes, drag);
        GView gv = new GView(this, rs);
        Screen s = screen(drag ? "Drag race · quarter mile" : "Top speed run", gv);
        s.full = true;
        return s;
    }

    // ------------------------------------------------------------------ compare

    Screen compareScreen(Engine a, Engine b) {
        ScrollView sv = new ScrollView(this);
        LinearLayout root = vbox();
        root.setPadding(dp(12), dp(4), dp(12), dp(24));
        sv.addView(root);
        LinearLayout hc = card();
        hc.addView(tv("●  " + a.title(), 15, Theme.RED, true));
        hc.addView(tv("●  " + b.title(), 15, Theme.CYAN, true));
        root.addView(hc, mlp(0, 4, 0, 6));
        final Curve ca = Curve.stock(a), cb = Curve.stock(b);
        LinearLayout dc = card();
        GView dyno = new GView(this, new StaticPainter((g, w, h) -> DynoChart.draw(g, 0, 0, w, h, new Curve[]{ca, cb}, new int[]{Theme.RED, Theme.CYAN}, new String[]{a.name, b.name}, Math.max(14f, w / 30f), -1)));
        dyno.grabTouch = false;
        dc.addView(dyno, new LinearLayout.LayoutParams(-1, dp(240)));
        root.addView(dc, mlp(0, 4, 0, 6));
        LinearLayout tc = card();
        String[][] rows = {
                {"Power", pw(a.kw), pw(b.kw)},
                {"Torque", Units.tq(a.nm), Units.tq(b.nm)},
                {"Layout", a.shortLayout(), b.shortLayout()},
                {"Displacement", Units.disp(a.cc), Units.disp(b.cc)},
                {"hp / litre", String.valueOf(Math.round(a.hpPerLiter())), String.valueOf(Math.round(b.hpPerLiter()))},
                {"Redline", Units.rpm(a.redline), Units.rpm(b.redline)},
                {"Induction", a.aspName(), b.aspName()},
                {"Years", a.years, b.years}};
        for (String[] r : rows) {
            LinearLayout row = hbox();
            row.setPadding(0, dp(5), 0, dp(5));
            row.addView(tv(r[0], 13, Theme.DIM, false), new LinearLayout.LayoutParams(0, -2, 1));
            TextView x = tv(r[1], 13, Theme.TEXT, true);
            x.setGravity(Gravity.END);
            TextView y = tv(r[2], 13, Theme.TEXT, true);
            y.setGravity(Gravity.END);
            row.addView(x, new LinearLayout.LayoutParams(0, -2, 1.2f));
            row.addView(y, new LinearLayout.LayoutParams(0, -2, 1.2f));
            tc.addView(row);
        }
        root.addView(tc, mlp(0, 4, 0, 6));
        if (!a.vehicles.isEmpty() && !b.vehicles.isEmpty() && a.vehicles.get(0).road() && b.vehicles.get(0).road()) {
            root.addView(button("▶ Drag race: " + a.vehicles.get(0).name + " vs " + b.vehicles.get(0).name, Theme.RED, Color.WHITE,
                    v -> push(runScreen(new Object[][]{{a.vehicles.get(0), new Tune(), a.vehicles.get(0).name}, {b.vehicles.get(0), new Tune(), b.vehicles.get(0).name}}, true))), mlp(0, 6, 0, 0));
        }
        return screen("Compare", sv);
    }

    // ------------------------------------------------------------------ garage

    Screen garageScreen() {
        LinearLayout root = vbox();
        ListView lv = new ListView(this);
        lv.setDivider(null);
        final ArrayList<Store.Build> builds = store.builds();
        LinearLayout head = vbox();
        head.setPadding(dp(12), dp(6), dp(12), dp(6));
        if (builds.isEmpty()) {
            LinearLayout c = card();
            c.addView(tv("Your garage is empty", 16, Theme.TEXT, true));
            c.addView(tv("Open any engine → Tune & top speed → Save to Garage. Saved builds show up here, ready to drag race against each other.", 13, Theme.DIM, false));
            head.addView(c);
        } else if (builds.size() >= 2) {
            head.addView(button("▶ Drag race two builds", Theme.RED, Color.WHITE, v -> pickBuild(builds, "First build", b1 -> pickBuild(builds, "Second build", b2 -> {
                Engine e1 = db.get(b1.engineId), e2 = db.get(b2.engineId);
                if (e1 == null || e2 == null) return;
                push(runScreen(new Object[][]{{e1.vehicles.get(Math.min(b1.vehicle, e1.vehicles.size() - 1)), Tune.decode(b1.tune), b1.name}, {e2.vehicles.get(Math.min(b2.vehicle, e2.vehicles.size() - 1)), Tune.decode(b2.tune), b2.name}}, true));
            }))));
        }
        lv.addHeaderView(head);
        BaseAdapter ad = new BaseAdapter() {
            public int getCount() { return builds.size(); }
            public Object getItem(int i) { return builds.get(i); }
            public long getItemId(int i) { return i; }
            public View getView(int i, View c, ViewGroup p) {
                Store.Build b = builds.get(i);
                Engine e = db.get(b.engineId);
                LinearLayout r = card();
                r.addView(tv(b.name, 16, Theme.TEXT, true));
                String veh = e != null && b.vehicle < e.vehicles.size() ? e.vehicles.get(b.vehicle).name : "?";
                r.addView(tv(veh + " · " + (e != null ? e.name : "?"), 12, Theme.DIM, false));
                r.addView(tv(pw(b.kw) + "  ·  " + (b.top > 0 ? Units.spd(b.top) : "—"), 15, Theme.CYAN, true));
                LinearLayout w = vbox();
                w.setPadding(dp(12), dp(4), dp(12), dp(4));
                w.addView(r);
                return w;
            }
        };
        lv.setAdapter(ad);
        lv.setOnItemClickListener((p, v, i, id) -> {
            int idx = i - lv.getHeaderViewsCount();
            if (idx < 0) return;
            Store.Build b = builds.get(idx);
            Engine e = db.get(b.engineId);
            if (e != null) push(tuneScreen(e, b.vehicle, Tune.decode(b.tune), b.name));
        });
        lv.setOnItemLongClickListener((p, v, i, id) -> {
            int idx = i - lv.getHeaderViewsCount();
            if (idx < 0) return false;
            new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Delete \"" + builds.get(idx).name + "\"?")
                    .setPositiveButton("Delete", (d, w) -> { builds.remove(idx); store.saveBuilds(builds); showTab(1); })
                    .setNegativeButton("Cancel", null).show();
            return true;
        });
        root.addView(lv, new LinearLayout.LayoutParams(-1, -1));
        return screen("Garage · " + builds.size() + " builds", root);
    }

    void pickBuild(ArrayList<Store.Build> builds, String title, Pick<Store.Build> cb) {
        String[] names = new String[builds.size()];
        for (int i = 0; i < names.length; i++) names[i] = builds.get(i).name + " · " + pw(builds.get(i).kw);
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle(title).setItems(names, (d, w) -> cb.on(builds.get(w))).show();
    }

    // ------------------------------------------------------------------ ranks

    int rankCat;
    static final String[] RANKS = {"Most powerful", "Most torque", "Highest hp per litre", "Highest redline", "Biggest displacement", "Smallest displacement", "Fastest vehicles (documented)", "Quickest 0–100 (simulated)", "Most cylinders"};

    Screen ranksScreen() {
        LinearLayout root = vbox();
        LinearLayout chips = vbox();
        root.addView(chips);
        ListView lv = new ListView(this);
        lv.setDivider(null);
        root.addView(lv, new LinearLayout.LayoutParams(-1, 0, 1));
        final ArrayList<Object[]> rows = new ArrayList<>(); // {title, sub, value, Engine}
        BaseAdapter ad = new BaseAdapter() {
            public int getCount() { return rows.size(); }
            public Object getItem(int i) { return rows.get(i); }
            public long getItemId(int i) { return i; }
            public View getView(int i, View c, ViewGroup p) {
                LinearLayout row = c instanceof LinearLayout ? (LinearLayout) c : engineRow();
                Object[] r = rows.get(i);
                ((TextView) row.getChildAt(0)).setText(i < 3 ? new String[]{"🥇", "🥈", "🥉"}[i] : String.valueOf(i + 1));
                LinearLayout mid = (LinearLayout) row.getChildAt(1);
                ((TextView) mid.getChildAt(0)).setText((String) r[0]);
                ((TextView) mid.getChildAt(1)).setText((String) r[1]);
                mid.getChildAt(2).setVisibility(View.GONE);
                LinearLayout right = (LinearLayout) row.getChildAt(2);
                ((TextView) right.getChildAt(0)).setText((String) r[2]);
                ((TextView) right.getChildAt(1)).setText("");
                return row;
            }
        };
        lv.setAdapter(ad);
        lv.setOnItemClickListener((p, v, i, id) -> push(engineScreen((Engine) rows.get(i)[3])));
        final Runnable[] build = new Runnable[1];
        build[0] = () -> {
            chips.removeAllViews();
            View[] cs = new View[RANKS.length];
            for (int i = 0; i < RANKS.length; i++) {
                final int k = i;
                cs[i] = chip(RANKS[i], k == rankCat, v -> { rankCat = k; build[0].run(); });
            }
            chips.addView(chipRow(cs));
            rows.clear();
            ArrayList<Engine> es = new ArrayList<>(db.all);
            switch (rankCat) {
                case 0: es.sort((a, b) -> Float.compare(b.kw, a.kw)); for (Engine e : es) rows.add(new Object[]{e.title(), engineLine(e), est(e) + pw(e.kw), e}); break;
                case 1: es.sort((a, b) -> Float.compare(b.nm, a.nm)); for (Engine e : es) rows.add(new Object[]{e.title(), engineLine(e), Units.tq(e.nm), e}); break;
                case 2: es.sort((a, b) -> Float.compare(b.hpPerLiter(), a.hpPerLiter())); for (Engine e : es) rows.add(new Object[]{e.title(), engineLine(e), Math.round(e.hpPerLiter()) + " hp/L", e}); break;
                case 3: es.sort((a, b) -> Integer.compare(b.redline, a.redline)); for (Engine e : es) rows.add(new Object[]{e.title(), engineLine(e), Units.rpm(e.redline), e}); break;
                case 4: es.sort((a, b) -> Float.compare(b.cc, a.cc)); for (Engine e : es) rows.add(new Object[]{e.title(), engineLine(e), Units.disp(e.cc), e}); break;
                case 5: es.sort((a, b) -> Float.compare(a.cc, b.cc)); for (Engine e : es) rows.add(new Object[]{e.title(), engineLine(e), Units.disp(e.cc), e}); break;
                case 6: {
                    ArrayList<Vehicle> vs = new ArrayList<>();
                    for (Engine e : db.all) for (Vehicle v : e.vehicles) if (v.top > 0) vs.add(v);
                    vs.sort((a, b) -> Float.compare(b.top, a.top));
                    for (Vehicle v : vs) rows.add(new Object[]{v.name, v.typeName() + " · " + v.engine.name, v.topText(Units.mph), v.engine});
                    break;
                }
                case 7: {
                    ArrayList<Object[]> tmp = new ArrayList<>();
                    for (Engine e : db.all) {
                        Curve s = Curve.stock(e);
                        for (Vehicle v : e.vehicles) {
                            if (!v.road() || v.type.equals("drag") || v.type.equals("train") || v.type.equals("haul")) continue;
                            Perf p = Perf.run(v, new Tune(), s, s, false);
                            if (p.t100 > 0) tmp.add(new Object[]{v.name, v.typeName() + " · " + e.name, Units.secs(p.t100), e, p.t100});
                        }
                    }
                    tmp.sort((a, b) -> Float.compare((Float) a[4], (Float) b[4]));
                    rows.addAll(tmp);
                    break;
                }
                default: es.sort((a, b) -> Integer.compare(b.cyl, a.cyl)); for (Engine e : es) rows.add(new Object[]{e.title(), engineLine(e), e.cyl + (e.wankel() ? " rotors" : " cyl"), e});
            }
            ad.notifyDataSetChanged();
        };
        build[0].run();
        return screen("Rankings", root);
    }

    // ------------------------------------------------------------------ arcade

    Screen arcadeScreen() {
        ScrollView sv = new ScrollView(this);
        LinearLayout root = vbox();
        root.setPadding(dp(12), dp(4), dp(12), dp(24));
        sv.addView(root);
        LinearLayout c1 = card();
        c1.addView(tv("HIGHER OR LOWER", 11, Theme.RED, true));
        c1.addView(tv("Does the next engine make more or less power? Best streak: " + store.best(), 14, Theme.TEXT, false));
        c1.addView(button("Play", Theme.RED, Color.WHITE, v -> push(higherLowerScreen())), mlp(0, 8, 0, 0));
        root.addView(c1, mlp(0, 6, 0, 6));
        LinearLayout c2 = card();
        c2.addView(tv("DRAG RACE", 11, Theme.RED, true));
        c2.addView(tv("Pick any two vehicles - a Derbi Senda against a Chiron, a Model T against a Top Fuel dragster.", 14, Theme.TEXT, false));
        c2.addView(button("Pick vehicles", Theme.PANEL2, Theme.TEXT, v -> pickVehicle("Lane 1", a -> pickVehicle("Lane 2", b -> push(runScreen(new Object[][]{{a, new Tune(), a.name}, {b, new Tune(), b.name}}, true))))), mlp(0, 8, 0, 0));
        root.addView(c2, mlp(0, 6, 0, 6));
        LinearLayout c3 = card();
        c3.addView(tv("RANDOM ENGINE", 11, Theme.RED, true));
        c3.addView(tv("Spin the wheel and explore something you have never heard of.", 14, Theme.TEXT, false));
        c3.addView(button("Surprise me", Theme.PANEL2, Theme.TEXT, v -> push(engineScreen(db.all.get(new Random().nextInt(db.all.size()))))), mlp(0, 8, 0, 0));
        root.addView(c3, mlp(0, 6, 0, 6));
        LinearLayout c4 = card();
        c4.addView(tv("TINY vs GIANT", 11, Theme.RED, true));
        c4.addView(tv("Compare the smallest engine in the app with the largest piston engine ever built.", 14, Theme.TEXT, false));
        c4.addView(button("Compare", Theme.PANEL2, Theme.TEXT, v -> {
            Engine small = Collections.min(db.all, Comparator.comparingDouble(x -> x.cc));
            Engine big = Collections.max(db.all, Comparator.comparingDouble(x -> x.cc));
            push(compareScreen(small, big));
        }), mlp(0, 8, 0, 0));
        root.addView(c4, mlp(0, 6, 0, 6));
        return screen("Arcade", sv);
    }

    Screen higherLowerScreen() {
        LinearLayout root = vbox();
        root.setPadding(dp(14), dp(10), dp(14), dp(14));
        final Random rnd = new Random();
        final Engine[] pair = {db.all.get(rnd.nextInt(db.all.size())), null};
        final int[] streak = {0};
        TextView score = tv("", 15, Theme.AMBER, true);
        root.addView(score);
        LinearLayout cards = vbox();
        root.addView(cards, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout btns = hbox();
        root.addView(btns);
        final Runnable[] next = new Runnable[1];
        final Pick<Boolean> guess = higher -> {
            Engine a = pair[0], b = pair[1];
            boolean ok = higher ? b.kw >= a.kw : b.kw <= a.kw;
            if (ok) {
                streak[0]++;
                if (streak[0] > store.best()) store.best(streak[0]);
                haptic(30, 120);
                Toast.makeText(this, "Correct! " + b.name + ": " + pw(b.kw), Toast.LENGTH_SHORT).show();
                pair[0] = b;
            } else {
                haptic(200, 255);
                new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Wrong!")
                        .setMessage(b.title() + " makes " + pw(b.kw) + ".\nStreak: " + streak[0] + " · Best: " + store.best())
                        .setPositiveButton("Again", null).show();
                streak[0] = 0;
                pair[0] = db.all.get(rnd.nextInt(db.all.size()));
            }
            next[0].run();
        };
        next[0] = () -> {
            Engine b;
            do { b = db.all.get(rnd.nextInt(db.all.size())); } while (b == pair[0] || Math.abs(b.kw - pair[0].kw) < 0.01f);
            pair[1] = b;
            score.setText("Streak " + streak[0] + "   ·   Best " + store.best());
            cards.removeAllViews();
            LinearLayout ca = card();
            ca.addView(tv(pair[0].make, 12, Theme.DIM, false));
            ca.addView(tv(pair[0].name, 18, Theme.TEXT, true));
            ca.addView(tv(pw(pair[0].kw), 28, Theme.RED, true));
            ca.addView(tv(engineLine(pair[0]), 12, Theme.DIM, false));
            cards.addView(ca, mlp(0, 10, 0, 6));
            cards.addView(tv("vs", 16, Theme.FAINT, true), mlp(0, 4, 0, 4));
            LinearLayout cb = card();
            cb.addView(tv(b.make, 12, Theme.DIM, false));
            cb.addView(tv(b.name, 18, Theme.TEXT, true));
            cb.addView(tv("? " + Units.powerUnit(), 28, Theme.CYAN, true));
            cb.addView(tv(engineLine(b), 12, Theme.DIM, false));
            cards.addView(cb, mlp(0, 6, 0, 6));
        };
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(0, -2, 1);
        ap.setMargins(dp(4), 0, dp(4), 0);
        btns.addView(button("▲ HIGHER", Theme.GREEN, Theme.BG, v -> guess.on(true)), ap);
        btns.addView(button("▼ LOWER", Theme.RED, Color.WHITE, v -> guess.on(false)), new LinearLayout.LayoutParams(ap));
        next[0].run();
        return screen("Higher or Lower", root);
    }

    // ------------------------------------------------------------------ settings

    Screen settingsScreen() {
        ScrollView sv = new ScrollView(this);
        LinearLayout root = vbox();
        root.setPadding(dp(12), dp(4), dp(12), dp(24));
        sv.addView(root);
        LinearLayout c = card();
        c.addView(tv("UNITS", 11, Theme.RED, true));
        stepRow(c, "Speed", new String[]{"km/h", "mph"}, Units.mph ? 1 : 0, v -> { Units.mph = v == 1; store.saveSettings(); });
        stepRow(c, "Power", new String[]{"hp", "PS", "kW"}, Units.power, v -> { Units.power = v; store.saveSettings(); });
        stepRow(c, "Torque", new String[]{"Nm", "lb-ft"}, Units.torque, v -> { Units.torque = v; store.saveSettings(); });
        root.addView(c, mlp(0, 6, 0, 6));
        LinearLayout cv = card();
        cv.addView(tv("VIBRATIONS", 11, Theme.RED, true));
        cv.addView(tv("Engine rumble, limiter pulses and backfire kicks in the Rev Lab, plus game feedback.", 12, Theme.DIM, false));
        stepRow(cv, "Vibrations", new String[]{"Off", "Light", "Strong"}, store.vibe, v -> { store.vibe = v; store.saveSettings(); if (v > 0) haptic(60, 200); });
        root.addView(cv, mlp(0, 6, 0, 6));
        LinearLayout c2 = card();
        c2.addView(tv("PERFORMANCE", 11, Theme.RED, true));
        int hz = Math.round(maxRefresh());
        int[] caps = {30, 60, 120};
        int ci = store.fpsCap <= 30 ? 0 : (store.fpsCap <= 60 ? 1 : 2);
        c2.addView(tv("Your screen supports up to " + hz + " Hz.", 12, Theme.DIM, false));
        stepRow(c2, "Frame rate", new String[]{"30 fps", "60 fps", "120 fps"}, ci, v -> { store.fpsCap = caps[v]; store.saveSettings(); applyRefreshRate(); });
        stepRow(c2, "3D resolution", Store.RES_NAMES, store.res, v -> { store.res = v; store.quality = Store.RES[v]; store.saveSettings(); });
        c2.addView(tv("Minimum 35% · Medium 50% · High 75% · Extra 100% (native) · Max 150% (supersampled)", 11, Theme.FAINT, false));
        int[] ps = {32, 96, 256};
        int pi = store.photoSamples <= 32 ? 0 : (store.photoSamples >= 256 ? 2 : 1);
        stepRow(c2, "Ray-traced photo quality (samples)", new String[]{"32", "96", "256"}, pi, v -> { store.photoSamples = ps[v]; store.saveSettings(); });
        stepRow(c2, "Show FPS counter", new String[]{"Off", "On"}, store.fps ? 1 : 0, v -> { store.fps = v == 1; GView.showFps = store.fps; store.saveSettings(); });
        root.addView(c2, mlp(0, 6, 0, 6));
        LinearLayout c3 = card();
        c3.addView(tv("ABOUT THE DATA", 11, Theme.RED, true));
        int veh = 0;
        for (Engine e : db.all) veh += e.vehicles.size();
        c3.addView(tv(db.all.size() + " engines · " + veh + " vehicles · " + db.makes.size() + " makers", 15, Theme.TEXT, true));
        c3.addView(tv("Power, torque, rpm and top speeds are the manufacturers' documented figures. ≈ marks approximate figures; \"claimed\" marks figures nobody has independently verified. Top speeds marked (limited) are electronically capped.\n\n"
                + "Every 3D engine is generated from its real configuration: bank angle, bore and stroke, valve count and valvetrain, firing order, induction (throttle bodies, carburettors, plenums, superchargers), turbo count and placement, intercoolers, exhaust routing and cooling. Logos and badges are not reproduced.\n\n"
                + "Performance runs use a physics model calibrated to each vehicle's documented top speed; acceleration times are simulations, not test results.", 13, Theme.DIM, false));
        root.addView(c3, mlp(0, 6, 0, 6));
        return screen("Settings", sv);
    }
}

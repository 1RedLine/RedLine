package com.redline.app;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;

import com.redline.core.Gfx;

/** Gfx implementation on top of android.graphics.Canvas. */
final class AGfx implements Gfx {
    Canvas c;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint img = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG);
    private final Path path = new Path();
    private final RectF rf = new RectF();
    private Bitmap bmp;
    private Bitmap bmp2;
    private static final Typeface MONO_B = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD);

    AGfx() {
        fill.setStyle(Paint.Style.FILL);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);
    }

    @Override public void fillRect(float x, float y, float w, float h, int argb) { fill.setColor(argb); c.drawRect(x, y, x + w, y + h, fill); }

    @Override public void fillRound(float x, float y, float w, float h, float r, int argb) {
        fill.setColor(argb); rf.set(x, y, x + w, y + h); c.drawRoundRect(rf, r, r, fill);
    }

    @Override public void strokeRound(float x, float y, float w, float h, float r, float sw, int argb) {
        stroke.setColor(argb); stroke.setStrokeWidth(sw); rf.set(x, y, x + w, y + h); c.drawRoundRect(rf, r, r, stroke);
    }

    private final Paint grad = new Paint();
    private float gy0 = Float.NaN, gy1;
    private int gTop, gBot;

    @Override public void gradientV(float x, float y, float w, float h, int top, int bottom) {
        if (y != gy0 || y + h != gy1 || top != gTop || bottom != gBot) {
            grad.setShader(new LinearGradient(0, y, 0, y + h, top, bottom, Shader.TileMode.CLAMP));
            gy0 = y; gy1 = y + h; gTop = top; gBot = bottom;
        }
        c.drawRect(x, y, x + w, y + h, grad);
    }

    @Override public void line(float x1, float y1, float x2, float y2, float sw, int argb) {
        stroke.setColor(argb); stroke.setStrokeWidth(sw); stroke.setStrokeCap(Paint.Cap.ROUND); c.drawLine(x1, y1, x2, y2, stroke);
    }

    @Override public void circle(float cx, float cy, float r, int argb) { fill.setColor(argb); c.drawCircle(cx, cy, r, fill); }

    @Override public void ring(float cx, float cy, float r, float sw, int argb) {
        stroke.setColor(argb); stroke.setStrokeWidth(sw); c.drawCircle(cx, cy, r, stroke);
    }

    @Override public void arc(float cx, float cy, float r, float startDeg, float sweepDeg, float sw, int argb) {
        stroke.setColor(argb); stroke.setStrokeWidth(sw); stroke.setStrokeCap(Paint.Cap.BUTT);
        rf.set(cx - r, cy - r, cx + r, cy + r);
        c.drawArc(rf, startDeg, sweepDeg, false, stroke);
        stroke.setStrokeCap(Paint.Cap.ROUND);
    }

    @Override public void poly(float[] xy, int n, int argb) {
        path.reset();
        path.moveTo(xy[0], xy[1]);
        for (int i = 1; i < n; i++) path.lineTo(xy[i * 2], xy[i * 2 + 1]);
        path.close();
        fill.setColor(argb);
        c.drawPath(path, fill);
    }

    @Override public void polyline(float[] xy, int n, float sw, int argb) {
        if (n < 2) return;
        path.reset();
        path.moveTo(xy[0], xy[1]);
        for (int i = 1; i < n; i++) path.lineTo(xy[i * 2], xy[i * 2 + 1]);
        stroke.setColor(argb); stroke.setStrokeWidth(sw);
        c.drawPath(path, stroke);
    }

    private void font(float size, int style) {
        txt.setTextSize(size);
        if ((style & MONO) != 0) txt.setTypeface((style & BOLD) != 0 ? MONO_B : Typeface.MONOSPACE);
        else txt.setTypeface((style & BOLD) != 0 ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
    }

    @Override public void text(String s, float x, float y, float size, int argb, int align, int style) {
        font(size, style);
        txt.setColor(argb);
        txt.setTextAlign(align == CENTER ? Paint.Align.CENTER : (align == RIGHT ? Paint.Align.RIGHT : Paint.Align.LEFT));
        c.drawText(s, x, y, txt);
    }

    @Override public float textWidth(String s, float size, int style) {
        font(size, style);
        return txt.measureText(s);
    }

    @Override public void image(int[] px, int pw, int ph, float x, float y, float w, float h) {
        Bitmap b = bmp;
        if (b == null || b.getWidth() != pw || b.getHeight() != ph) {
            // two cached sizes (viewer + photo) to avoid churn
            if (bmp2 != null && bmp2.getWidth() == pw && bmp2.getHeight() == ph) { Bitmap t = bmp; bmp = bmp2; bmp2 = t; b = bmp; }
            else { bmp2 = bmp; b = bmp = Bitmap.createBitmap(pw, ph, Bitmap.Config.ARGB_8888); }
        }
        b.setPixels(px, 0, pw, 0, 0, pw, ph);
        rf.set(x, y, x + w, y + h);
        c.drawBitmap(b, null, rf, img);
    }

    @Override public void save() { c.save(); }

    @Override public void clip(float x, float y, float w, float h) { c.clipRect(x, y, x + w, y + h); }

    @Override public void translate(float dx, float dy) { c.translate(dx, dy); }

    @Override public void restore() { c.restore(); }
}

package com.redline.app;

import android.content.Context;
import android.graphics.Canvas;
import android.view.MotionEvent;
import android.view.View;

import com.redline.core.Painter;

/** Hosts a Painter: draws every frame while animating and forwards per-pointer touches. */
final class GView extends View {
    Painter painter;
    Runnable afterFrame;
    private final AGfx g = new AGfx();
    private long last;
    boolean grabTouch = true;
    static boolean showFps;
    static int fpsCap = 120;
    static float displayHz = 60f;
    private final Runnable invalidator = this::invalidate;
    private float fps;

    GView(Context c, Painter p) {
        super(c);
        painter = p;
        setFocusable(true);
    }

    @Override protected void onDraw(Canvas canvas) {
        long now = System.nanoTime();
        float dt = last == 0 ? 1f / 60f : (now - last) / 1e9f;
        last = now;
        if (painter == null) return;
        g.c = canvas;
        try {
            painter.paint(g, getWidth(), getHeight(), Math.min(dt, 0.1f));
        } catch (RuntimeException ex) {
            android.util.Log.e("Redline", "paint", ex);
        }
        if (afterFrame != null) afterFrame.run();
        if (showFps && painter.animating()) {
            fps = fps <= 0 ? 1f / Math.max(1e-3f, dt) : fps * 0.9f + 0.1f / Math.max(1e-3f, dt);
            float sz = getResources().getDisplayMetrics().density * 11;
            g.fillRound(getWidth() - sz * 6.2f, getHeight() - sz * 2.1f, sz * 5.8f, sz * 1.7f, sz * 0.4f, 0xAA000000);
            g.text(Math.round(fps) + " fps", getWidth() - sz * 3.3f, getHeight() - sz * 0.85f, sz, 0xFF34D399, com.redline.core.Gfx.CENTER, com.redline.core.Gfx.BOLD);
        }
        if (painter.animating() && isShown()) {
            removeCallbacks(invalidator);
            if (fpsCap >= displayHz - 1f) postInvalidateOnAnimation();
            else {
                long frameNs = 1_000_000_000L / Math.max(1, fpsCap);
                long delayMs = (now + frameNs - System.nanoTime()) / 1_000_000L - 4;
                if (delayMs <= 0) postInvalidateOnAnimation();
                else postOnAnimationDelayed(invalidator, delayMs);
            }
        }
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        last = 0;
        postInvalidateOnAnimation();
    }

    @Override protected void onVisibilityChanged(View changed, int visibility) {
        super.onVisibilityChanged(changed, visibility);
        if (visibility == VISIBLE) { last = 0; postInvalidateOnAnimation(); }
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (painter == null) return false;
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN && grabTouch && getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
        switch (a) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {
                int i = e.getActionIndex();
                painter.touch(Painter.DOWN, e.getPointerId(i), e.getX(i), e.getY(i));
                break;
            }
            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < e.getPointerCount(); i++) painter.touch(Painter.MOVE, e.getPointerId(i), e.getX(i), e.getY(i));
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP: {
                int i = e.getActionIndex();
                painter.touch(Painter.UP, e.getPointerId(i), e.getX(i), e.getY(i));
                break;
            }
            case MotionEvent.ACTION_CANCEL:
                for (int i = 0; i < e.getPointerCount(); i++) painter.touch(Painter.CANCEL, e.getPointerId(i), e.getX(i), e.getY(i));
                break;
        }
        invalidate();
        return true;
    }
}

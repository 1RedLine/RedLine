package com.redline.app;

import android.content.Context;
import android.content.SharedPreferences;

import com.redline.core.Units;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/** Local persistence: settings, favourites, garage builds, high score. */
final class Store {
    static final class Build {
        String name, engineId, tune;
        int vehicle;
        float kw, top;
        long time;
    }

    private final SharedPreferences sp;
    boolean haptics = true;
    int vibe = 2;          // 0 off, 1 light, 2 strong
    boolean fps;
    boolean maxHz = true;
    int fpsCap = 120;      // 30, 60 or 120
    int res = 3;           // 0 Minimum .. 4 Max
    static final float[] RES = {0.35f, 0.5f, 0.75f, 1.0f, 1.5f};
    static final String[] RES_NAMES = {"Minimum", "Medium", "High", "Extra", "Max"};
    float quality = 1.0f;
    int photoSamples = 96;

    Store(Context c) {
        sp = c.getSharedPreferences("redline", Context.MODE_PRIVATE);
        Units.mph = sp.getBoolean("mph", false);
        Units.power = sp.getInt("power", 0);
        Units.torque = sp.getInt("torque", 0);
        haptics = sp.getBoolean("haptics", true);
        vibe = sp.getInt("vibe", haptics ? 2 : 0);
        fps = sp.getBoolean("fps", false);
        maxHz = sp.getBoolean("maxhz", true);
        fpsCap = sp.getInt("fpscap", 120);
        res = Math.max(0, Math.min(4, sp.getInt("res", 3)));
        quality = RES[res];
        quality = sp.getFloat("quality2", 1.0f);
        photoSamples = sp.getInt("photo", 96);
    }

    void saveSettings() {
        sp.edit().putBoolean("mph", Units.mph).putInt("power", Units.power).putInt("torque", Units.torque)
                .putBoolean("haptics", vibe > 0).putInt("vibe", vibe).putBoolean("fps", fps).putBoolean("maxhz", maxHz).putFloat("quality2", quality).putInt("fpscap", fpsCap).putInt("res", res).putInt("photo", photoSamples).apply();
    }

    Set<String> favs() { return new HashSet<>(sp.getStringSet("favs", new HashSet<>())); }

    boolean isFav(String id) { return favs().contains(id); }

    void toggleFav(String id) {
        Set<String> f = favs();
        if (!f.remove(id)) f.add(id);
        sp.edit().putStringSet("favs", f).apply();
    }

    int best() { return sp.getInt("hl_best", 0); }

    void best(int v) { sp.edit().putInt("hl_best", v).apply(); }

    ArrayList<Build> builds() {
        ArrayList<Build> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp.getString("garage", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Build b = new Build();
                b.name = o.optString("name");
                b.engineId = o.optString("engine");
                b.vehicle = o.optInt("vehicle");
                b.tune = o.optString("tune");
                b.kw = (float) o.optDouble("kw");
                b.top = (float) o.optDouble("top");
                b.time = o.optLong("time");
                out.add(b);
            }
        } catch (Exception ignored) { }
        return out;
    }

    void saveBuilds(ArrayList<Build> list) {
        JSONArray a = new JSONArray();
        try {
            for (Build b : list) {
                JSONObject o = new JSONObject();
                o.put("name", b.name).put("engine", b.engineId).put("vehicle", b.vehicle).put("tune", b.tune)
                        .put("kw", b.kw).put("top", b.top).put("time", b.time);
                a.put(o);
            }
        } catch (Exception ignored) { }
        sp.edit().putString("garage", a.toString()).apply();
    }

    void addBuild(Build b) {
        ArrayList<Build> l = builds();
        l.add(0, b);
        saveBuilds(l);
    }
}

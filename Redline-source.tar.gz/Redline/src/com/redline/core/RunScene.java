package com.redline.core;

import java.util.Locale;

/** Animated top-speed run (one lane) or drag race (two lanes) played back from Perf samples. */
public final class RunScene implements Painter {
    public static final class Lane {
        public String name, sub;
        public Perf perf;
        public int color;
        public int redline;
    }

    public final Lane[] lanes;
    public final boolean drag;
    float t;            // simulation time being shown
    float speedUp;
    boolean done;
    float[] rAgain;
    public Runnable onAgain;
    float scroll;

    public RunScene(Lane[] lanes, boolean drag) {
        this.lanes = lanes;
        this.drag = drag;
        float total = 0;
        for (Lane l : lanes) {
            float end = drag ? (l.perf.quarter > 0 ? l.perf.quarter : 30f) : (l.perf.timeToTop > 0 ? l.perf.timeToTop + 1.5f : (l.perf.ns > 0 ? l.perf.st[l.perf.ns - 1] : 10f));
            total = Math.max(total, end);
        }
        speedUp = drag ? 1f : Math.max(1f, total / 22f);
        t = -1.2f;
    }

    @Override public boolean animating() { return !done || t < 1e9f; }

    static float sample(Perf p, float[] arr, float t) {
        if (p.ns == 0) return 0;
        if (t <= p.st[0]) return arr == p.sv || arr == p.sx ? 0 : arr[0];
        for (int i = 1; i < p.ns; i++) {
            if (p.st[i] >= t) {
                float u = (t - p.st[i - 1]) / Math.max(1e-6f, p.st[i] - p.st[i - 1]);
                return arr[i - 1] + (arr[i] - arr[i - 1]) * u;
            }
        }
        return arr[p.ns - 1];
    }

    static int gearAt(Perf p, float t) {
        if (p.ns == 0) return 1;
        for (int i = 1; i < p.ns; i++) if (p.st[i] >= t) return p.sg[i - 1];
        return p.sg[p.ns - 1];
    }

    @Override
    public void paint(Gfx g, float w, float h, float dt) {
        t += dt * speedUp;
        float s = Math.min(w / 24f, h / 40f);
        g.fillRect(0, 0, w, h, Theme.BG);
        // countdown lights
        float roadTop = h * 0.08f, roadBot = h * (drag ? 0.62f : 0.55f);
        boolean allDone = true;
        float leaderX = 0;
        for (Lane l : lanes) {
            float x = sample(l.perf, l.perf.sx, Math.max(0, t));
            leaderX = Math.max(leaderX, x);
            float end = drag ? 402.336f : 1e9f;
            if (drag ? x < end : (l.perf.timeToTop < 0 || t < l.perf.timeToTop + 1f)) allDone = false;
        }
        done = allDone && t > 0;
        // road (pseudo 3D)
        float cx = w / 2;
        float topW = w * 0.18f, botW = w * 0.92f;
        g.gradientV(0, 0, w, roadTop + (roadBot - roadTop) * 0.1f, 0xFF0D1220, Theme.BG);
        float[] road = {cx - topW / 2, roadTop, cx + topW / 2, roadTop, cx + botW / 2, roadBot, cx - botW / 2, roadBot};
        g.poly(road, 4, 0xFF161B24);
        float speedNow = lanes.length > 0 ? sample(lanes[0].perf, lanes[0].perf.sv, Math.max(0, t)) : 0;
        scroll = leaderX;
        // dashes
        int lanesN = Math.max(2, lanes.length);
        for (int k = 1; k < lanesN; k++) {
            float f = (float) k / lanesN - 0.5f;
            for (int d = 0; d < 14; d++) {
                float z0 = ((d * 6f - scroll % 6f) / 84f);
                float z1 = z0 + 3f / 84f;
                if (z0 < 0 || z1 > 1) continue;
                float y0 = roadBot - (roadBot - roadTop) * persp(z0), y1 = roadBot - (roadBot - roadTop) * persp(z1);
                float w0 = botW + (topW - botW) * persp(z0), w1 = botW + (topW - botW) * persp(z1);
                g.line(cx + f * w0, y0, cx + f * w1, y1, Math.max(1f, s * 0.12f * (1 - persp(z0))), 0x88FFFFFF);
            }
        }
        // edges
        g.line(road[0], road[1], road[6], road[7], s * 0.12f, Theme.alpha(Theme.RED, 0.6f));
        g.line(road[2], road[3], road[4], road[5], s * 0.12f, Theme.alpha(Theme.RED, 0.6f));
        // speed streaks
        float streak = Math.min(1f, speedNow / 300f);
        for (int i = 0; i < 18; i++) {
            float sx = (i * 137 % 100) / 100f * w;
            float sy = ((i * 53 % 100) / 100f * roadBot * 0.9f + scroll * 4f) % (roadBot);
            g.line(sx, sy, sx, sy + s * 3f * streak, s * 0.06f, Theme.alpha(0xFFFFFFFF, 0.12f * streak));
        }
        // finish line (drag)
        if (drag) {
            float dz = (402.336f - leaderX + 20f) / 84f;
            if (dz > 0 && dz < 1) {
                float fy = roadBot - (roadBot - roadTop) * persp(dz);
                float fw = botW + (topW - botW) * persp(dz);
                for (int k = 0; k < 16; k++) g.fillRect(cx - fw / 2 + fw * k / 16f, fy - s * 0.2f, fw / 16f, s * 0.4f, k % 2 == 0 ? 0xFFFFFFFF : 0xFF111111);
            }
        }
        // vehicles as glowing sleds
        for (int i = 0; i < lanes.length; i++) {
            Lane l = lanes[i];
            float x = sample(l.perf, l.perf.sx, Math.max(0, t));
            float rel = (x - leaderX + 20f) / 84f;
            rel = Math.max(0.02f, Math.min(0.98f, rel));
            float py = roadBot - (roadBot - roadTop) * persp(rel);
            float pw = botW + (topW - botW) * persp(rel);
            float laneF = lanes.length == 1 ? 0 : ((i + 0.5f) / lanes.length - 0.5f);
            float px = cx + laneF * pw;
            float sz = s * 2.2f * (1 - persp(rel) * 0.7f);
            g.circle(px, py, sz * 1.6f, Theme.alpha(l.color, 0.15f));
            g.fillRound(px - sz * 0.6f, py - sz, sz * 1.2f, sz * 1.8f, sz * 0.4f, l.color);
            g.fillRound(px - sz * 0.45f, py + sz * 0.5f, sz * 0.9f, sz * 0.22f, sz * 0.1f, 0xFFFF4040);
            float v = sample(l.perf, l.perf.sv, Math.max(0, t));
            g.text(Units.spd(v), px, py - sz * 1.4f, s * 0.7f, Theme.TEXT, Gfx.CENTER, Gfx.BOLD);
        }
        // start lights
        if (t < 0) {
            int lit = (int) ((t + 1.2f) / 0.4f);
            for (int k = 0; k < 3; k++) g.circle(cx - s * 2.2f + k * s * 2.2f, h * 0.2f, s * 0.8f, k < lit ? Theme.AMBER : 0x33FFFFFF);
        } else if (t < 0.6f) {
            for (int k = 0; k < 3; k++) g.circle(cx - s * 2.2f + k * s * 2.2f, h * 0.2f, s * 0.8f, Theme.GREEN);
        }
        // HUD per lane
        float hy = roadBot + s * 1.2f;
        float colW = w / lanes.length;
        for (int i = 0; i < lanes.length; i++) {
            Lane l = lanes[i];
            Perf p = l.perf;
            float tt = Math.max(0, t);
            float v = sample(p, p.sv, tt), rpm = sample(p, p.sr, tt), x = sample(p, p.sx, tt);
            int gear = gearAt(p, tt);
            float bx = colW * i + s * 0.6f, bw = colW - s * 1.2f;
            g.fillRound(bx, hy, bw, h - hy - s * (drag ? 4.5f : 9.5f), s * 0.6f, Theme.PANEL);
            g.fillRect(bx, hy, s * 0.3f, s * 3f, l.color);
            g.text(l.name, bx + s * 0.8f, hy + s * 1.2f, s * 0.75f, Theme.TEXT, Gfx.LEFT, Gfx.BOLD);
            g.text(l.sub, bx + s * 0.8f, hy + s * 2.1f, s * 0.58f, Theme.DIM, Gfx.LEFT, 0);
            float big = lanes.length == 1 ? s * 3.2f : s * 2.2f;
            g.text(String.valueOf(Math.round(Units.speedVal(v))), bx + bw / 2, hy + s * 3.2f + big, big, Theme.TEXT, Gfx.CENTER, Gfx.BOLD | Gfx.MONO);
            g.text(Units.speedUnit(), bx + bw / 2, hy + s * 4.0f + big, s * 0.6f, Theme.DIM, Gfx.CENTER, 0);
            float iy = hy + s * 5.2f + big;
            float rf = rpm / Math.max(1, l.redline);
            g.fillRound(bx + s * 0.8f, iy, bw - s * 1.6f, s * 0.5f, s * 0.25f, 0x22FFFFFF);
            g.fillRound(bx + s * 0.8f, iy, (bw - s * 1.6f) * Math.min(1, rf), s * 0.5f, s * 0.25f, rf > 0.95f ? Theme.RED : Theme.AMBER);
            String line = p.gears > 0 ? "Gear " + gear + "  ·  " + Units.rpm(rpm) : "CVT  ·  " + Units.rpm(rpm);
            g.text(line, bx + bw / 2, iy + s * 1.5f, s * 0.62f, Theme.DIM, Gfx.CENTER, 0);
            String d = x < 1000 ? Math.round(x) + " m" : String.format(Locale.US, "%.2f km", x / 1000f);
            g.text(String.format(Locale.US, "%.2f s  ·  %s", tt, d), bx + bw / 2, iy + s * 2.5f, s * 0.62f, Theme.DIM, Gfx.CENTER, 0);
            if (drag && p.quarter > 0 && tt >= p.quarter) {
                g.text(String.format(Locale.US, "%.2f s @ %s", p.quarter, Units.spd(p.trap)), bx + bw / 2, iy + s * 3.7f, s * 0.75f, l.color, Gfx.CENTER, Gfx.BOLD);
            }
        }
        if (drag && done && lanes.length == 2) {
            Lane win = lanes[0].perf.quarter <= lanes[1].perf.quarter || lanes[1].perf.quarter < 0 ? lanes[0] : lanes[1];
            float margin = Math.abs(lanes[0].perf.quarter - lanes[1].perf.quarter);
            g.fillRound(w * 0.1f, h * 0.3f, w * 0.8f, s * 4f, s * 0.8f, 0xEE121720);
            g.text(win.name + " WINS", w / 2, h * 0.3f + s * 1.8f, s * 1.1f, win.color, Gfx.CENTER, Gfx.BOLD);
            g.text(String.format(Locale.US, "by %.3f s", margin), w / 2, h * 0.3f + s * 3.1f, s * 0.75f, Theme.TEXT, Gfx.CENTER, 0);
        }
        if (!drag) drawGraph(g, s * 0.6f, h - s * 9f, w - s * 1.2f, s * 8.2f, s);
        if (drag) {
            float bw = w * 0.4f;
            rAgain = Theme.button(g, done ? "RUN AGAIN" : "SKIP ▸", w / 2 - bw / 2, h - s * 3.2f, bw, s * 2.4f, s * 0.8f, done ? Theme.RED : Theme.PANEL2, Theme.TEXT);
        } else {
            rAgain = new float[]{w - s * 7.2f, roadTop, s * 6.6f, s * 2.2f};
            Theme.button(g, done ? "RUN AGAIN" : "SKIP ▸", rAgain[0], rAgain[1], rAgain[2], rAgain[3], s * 0.68f, done ? Theme.RED : Theme.PANEL2, Theme.TEXT);
        }
    }

    static float persp(float z) { return (float) (1 - 1 / (1 + z * 3.2)) / (float) (1 - 1 / 4.2); }

    private void drawGraph(Gfx g, float x, float y, float w, float h, float s) {
        Lane l = lanes[0];
        Perf p = l.perf;
        g.fillRound(x, y, w, h, s * 0.6f, Theme.PANEL);
        if (p.ns < 2) return;
        float endT = p.timeToTop > 0 ? p.timeToTop + 1.5f : p.st[p.ns - 1];
        float vmax = Math.max(10, p.top) * 1.05f;
        float ix = x + s * 0.6f, iw = w - s * 1.2f, iy = y + s * 1.6f, ih = h - s * 2.2f;
        g.text("SPEED vs TIME", x + s * 0.6f, y + s * 1.0f, s * 0.55f, Theme.DIM, Gfx.LEFT, Gfx.BOLD);
        g.text("Top: " + Units.spd(p.top) + " · " + p.limit, x + w - s * 0.6f, y + s * 1.0f, s * 0.55f, Theme.TEXT, Gfx.RIGHT, Gfx.BOLD);
        float tShow = Math.min(Math.max(0, t), endT);
        int n = 0;
        float[] pts = new float[p.ns * 2];
        for (int i = 0; i < p.ns && p.st[i] <= tShow; i++) {
            pts[n * 2] = ix + iw * p.st[i] / endT;
            pts[n * 2 + 1] = iy + ih * (1 - p.sv[i] / vmax);
            n++;
        }
        g.line(ix, iy + ih * (1 - p.top / vmax), ix + iw, iy + ih * (1 - p.top / vmax), 1f, Theme.alpha(Theme.RED, 0.5f));
        if (n > 1) g.polyline(pts, n, s * 0.18f, l.color);
    }

    @Override
    public void touch(int action, int id, float x, float y) {
        if (action != DOWN) return;
        if (Theme.in(x, y, rAgain)) {
            if (done) { t = -1.2f; done = false; if (onAgain != null) onAgain.run(); }
            else {
                float end = 0;
                for (Lane l : lanes) end = Math.max(end, drag ? (l.perf.quarter > 0 ? l.perf.quarter + 0.5f : 30) : (l.perf.timeToTop > 0 ? l.perf.timeToTop + 1.6f : 30));
                t = end;
            }
        }
    }
}

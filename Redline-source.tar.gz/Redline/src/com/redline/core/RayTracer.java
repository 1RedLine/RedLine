package com.redline.core;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.ArrayList;

/**
 * Progressive CPU ray tracer: BVH, soft shadows from an area light, ambient occlusion,
 * glossy metal reflections, glass-like see-through shells and a reflective studio floor.
 */
public final class RayTracer {
    // triangles
    float[] v;      // 9 per tri
    float[] nrm;    // 9 per tri (vertex normals)
    int[] mat;
    int ntri;
    // materials
    float[] mr, mg, mb, metal, rough, alpha, emit;
    int nmat;
    // bvh
    float[] bmin, bmax;
    int[] left, count, triIdx;
    int nodes;
    // camera
    final float[] cam = new float[3], fwd = new float[3], right = new float[3], up = new float[3];
    float tanHalf, aspect;
    float floorY, sceneR;
    final float[] sceneC = new float[3];
    // light (rectangle)
    final float[] lc = new float[3], lu = new float[3], lv = new float[3];
    float lightPower = 2.4f;
    // image
    public int w, h;
    float[] acc;
    public volatile int samples;
    private final int threads;
    private final ExecutorService pool;
    public volatile boolean cancel;

    public RayTracer() {
        threads = Math.max(1, Runtime.getRuntime().availableProcessors());
        pool = Executors.newFixedThreadPool(threads, r -> {
            Thread t = new Thread(r, "redline-rt");
            t.setDaemon(true);
            t.setPriority(Thread.NORM_PRIORITY - 1);
            return t;
        });
    }

    public void shutdown() { pool.shutdownNow(); }

    // ------------------------------------------------------------------ scene

    public void setup(EngineModel m, Raster ras, int w, int h) {
        this.w = w; this.h = h;
        acc = new float[w * h * 3];
        samples = 0;
        ArrayList<float[]> mats = new ArrayList<>();
        // count tris
        int total = 0;
        for (Part p : m.parts) if (ras.visible(p, m) && p.kind != Part.LINER) total += p.mesh.nt;
        v = new float[total * 9];
        nrm = new float[total * 9];
        mat = new int[total];
        ntri = 0;
        float explode = ras.mode == Raster.EXPLODED ? ras.explodeT : 0f;
        float[] M = new float[12];
        float[] tmp = new float[3];
        boolean see = ras.mode == Raster.XRAY || ras.mode == Raster.FLOW || ras.mode == Raster.THERMAL;
        float ymin = 1e9f;
        for (Part p : m.parts) {
            if (!ras.visible(p, m) || p.kind == Part.LINER) continue;
            System.arraycopy(p.mat, 0, M, 0, 12);
            M[3] += p.explode[0] * explode; M[7] += p.explode[1] * explode; M[11] += p.explode[2] * explode;
            int col = p.color;
            if (p.kind == Part.CHARGE) col = p.color;
            if (ras.mode == Raster.THERMAL) col = Raster.heatColor(p.heat * ras.heatScale);
            float r = srgb(((col >> 16) & 255) / 255f), g = srgb(((col >> 8) & 255) / 255f), b = srgb((col & 255) / 255f);
            float met, ro, al = 1f, em = 0f;
            switch (p.kind) {
                case Part.MOVING: met = 0.75f; ro = 0.18f; break;
                case Part.MISC: met = 0.35f; ro = 0.3f; break;
                case Part.DUCT: met = p.key.equals("header") || p.key.equals("downpipe") || p.key.equals("compressor") || p.key.equals("trumpet") ? 0.7f : 0.25f; ro = 0.3f; break;
                case Part.CHARGE: met = 0; ro = 1; em = 1.6f; al = 0.55f; break;
                case Part.FIGURE: met = 0; ro = 0.8f; break;
                default: met = 0.28f; ro = 0.45f;
            }
            if (p.key.equals("camcover") || p.key.equals("airbox") || p.key.equals("plenum") && (col & 0xFFFFFF) < 0x606060) { met = 0.05f; ro = 0.35f; }
            if (see && (p.kind == Part.SHELL)) { al = 0.12f; r = r * 0.4f + 0.12f; g = g * 0.4f + 0.3f; b = b * 0.4f + 0.42f; }
            if (see && (p.kind == Part.DUCT)) al = 0.35f;
            if (ras.selKey != null && ras.selKey.equals(p.key)) { r = r * 0.5f + 0.05f; g = g * 0.5f + 0.4f; b = b * 0.5f + 0.5f; al = Math.max(al, 0.5f); }
            int mi = mats.size();
            mats.add(new float[]{r, g, b, met, ro, al, em});
            Mesh mesh = p.mesh;
            for (int t = 0; t < mesh.nt; t++) {
                for (int k = 0; k < 3; k++) {
                    int vi = mesh.t[t * 3 + k];
                    M3.apply(M, mesh.p[vi * 3], mesh.p[vi * 3 + 1], mesh.p[vi * 3 + 2], v, ntri * 9 + k * 3);
                    M3.applyDir(M, mesh.n[vi * 3], mesh.n[vi * 3 + 1], mesh.n[vi * 3 + 2], tmp, 0);
                    float l = (float) Math.sqrt(tmp[0] * tmp[0] + tmp[1] * tmp[1] + tmp[2] * tmp[2]);
                    if (l < 1e-9f) l = 1;
                    nrm[ntri * 9 + k * 3] = tmp[0] / l; nrm[ntri * 9 + k * 3 + 1] = tmp[1] / l; nrm[ntri * 9 + k * 3 + 2] = tmp[2] / l;
                    ymin = Math.min(ymin, v[ntri * 9 + k * 3 + 1]);
                }
                mat[ntri] = mi;
                ntri++;
            }
        }
        nmat = mats.size();
        mr = new float[nmat]; mg = new float[nmat]; mb = new float[nmat]; metal = new float[nmat]; rough = new float[nmat]; alpha = new float[nmat]; emit = new float[nmat];
        for (int i = 0; i < nmat; i++) {
            float[] q = mats.get(i);
            mr[i] = q[0]; mg[i] = q[1]; mb[i] = q[2]; metal[i] = q[3]; rough[i] = q[4]; alpha[i] = q[5]; emit[i] = q[6];
        }
        floorY = ymin - m.radius * 0.02f;
        sceneR = Math.max(m.radius, 1e-3f);
        sceneC[0] = m.center[0]; sceneC[1] = m.center[1]; sceneC[2] = m.center[2];
        if (ras.mode == Raster.SCALE) sceneR = Math.max(sceneR, 1f);
        buildBVH();
        // camera from raster view
        ras.buildView();
        float[] V = ras.view;
        System.arraycopy(ras.camPos, 0, cam, 0, 3);
        right[0] = V[0]; right[1] = V[1]; right[2] = V[2];
        up[0] = V[4]; up[1] = V[5]; up[2] = V[6];
        fwd[0] = -V[8]; fwd[1] = -V[9]; fwd[2] = -V[10];
        tanHalf = (float) Math.tan(Math.toRadians(ras.fov / 2));
        aspect = (float) w / h;
        // key light: large soft box above, in front-left of the camera
        float R = sceneR;
        float lx = cam[0] - sceneC[0], lz = cam[2] - sceneC[2];
        float ll = (float) Math.sqrt(lx * lx + lz * lz);
        if (ll < 1e-6f) { lx = 1; lz = 0; ll = 1; }
        lx /= ll; lz /= ll;
        float sx = -lz, sz = lx; // sideways
        lc[0] = sceneC[0] + lx * R * 1.6f + sx * R * 1.4f;
        lc[1] = sceneC[1] + R * 3.2f;
        lc[2] = sceneC[2] + lz * R * 1.6f + sz * R * 1.4f;
        lu[0] = sx * R * 1.3f; lu[1] = 0; lu[2] = sz * R * 1.3f;
        lv[0] = lx * R * 1.0f; lv[1] = 0; lv[2] = lz * R * 1.0f;
    }

    static float srgb(float c) { return (float) Math.pow(c, 2.2); }

    // ------------------------------------------------------------------ BVH

    private float[] cen;

    private void buildBVH() {
        int maxNodes = Math.max(1, ntri * 2);
        bmin = new float[maxNodes * 3];
        bmax = new float[maxNodes * 3];
        left = new int[maxNodes];
        count = new int[maxNodes];
        triIdx = new int[ntri];
        cen = new float[ntri * 3];
        for (int i = 0; i < ntri; i++) {
            triIdx[i] = i;
            for (int k = 0; k < 3; k++) cen[i * 3 + k] = (v[i * 9 + k] + v[i * 9 + 3 + k] + v[i * 9 + 6 + k]) / 3f;
        }
        nodes = 0;
        if (ntri == 0) { nodes = 1; count[0] = 0; return; }
        build(0, ntri);
        cen = null;
    }

    private int build(int start, int end) {
        int node = nodes++;
        float x0 = 1e30f, y0 = 1e30f, z0 = 1e30f, x1 = -1e30f, y1 = -1e30f, z1 = -1e30f;
        float cx0 = 1e30f, cy0 = 1e30f, cz0 = 1e30f, cx1 = -1e30f, cy1 = -1e30f, cz1 = -1e30f;
        for (int i = start; i < end; i++) {
            int t = triIdx[i];
            for (int k = 0; k < 3; k++) {
                float x = v[t * 9 + k * 3], y = v[t * 9 + k * 3 + 1], z = v[t * 9 + k * 3 + 2];
                if (x < x0) x0 = x; if (x > x1) x1 = x;
                if (y < y0) y0 = y; if (y > y1) y1 = y;
                if (z < z0) z0 = z; if (z > z1) z1 = z;
            }
            float cx = cen[t * 3], cy = cen[t * 3 + 1], cz = cen[t * 3 + 2];
            if (cx < cx0) cx0 = cx; if (cx > cx1) cx1 = cx;
            if (cy < cy0) cy0 = cy; if (cy > cy1) cy1 = cy;
            if (cz < cz0) cz0 = cz; if (cz > cz1) cz1 = cz;
        }
        bmin[node * 3] = x0; bmin[node * 3 + 1] = y0; bmin[node * 3 + 2] = z0;
        bmax[node * 3] = x1; bmax[node * 3 + 1] = y1; bmax[node * 3 + 2] = z1;
        int n = end - start;
        if (n <= 4) { left[node] = start; count[node] = n; return node; }
        float ex = cx1 - cx0, ey = cy1 - cy0, ez = cz1 - cz0;
        int axis = ex > ey ? (ex > ez ? 0 : 2) : (ey > ez ? 1 : 2);
        float mid = axis == 0 ? (cx0 + cx1) / 2 : (axis == 1 ? (cy0 + cy1) / 2 : (cz0 + cz1) / 2);
        int i = start, j = end - 1;
        while (i <= j) {
            if (cen[triIdx[i] * 3 + axis] < mid) i++;
            else { int t = triIdx[i]; triIdx[i] = triIdx[j]; triIdx[j] = t; j--; }
        }
        if (i == start || i == end) i = (start + end) / 2;
        count[node] = 0;
        int l = build(start, i);
        int r = build(i, end);
        left[node] = l;
        // right child index stored implicitly: we store it in a parallel slot via count = -r
        count[node] = -r;
        return node;
    }

    // ------------------------------------------------------------------ tracing

    static final class Hit { float t, u, w; int tri = -1; }

    /** Closest hit (ignoreAlpha=false) or any opaque hit for shadow rays. */
    boolean trace(float ox, float oy, float oz, float dx, float dy, float dz, float tmax, Hit hit, boolean shadow, int[] stack) {
        if (ntri == 0) return false;
        float ix = 1f / (Math.abs(dx) < 1e-12f ? 1e-12f : dx), iy = 1f / (Math.abs(dy) < 1e-12f ? 1e-12f : dy), iz = 1f / (Math.abs(dz) < 1e-12f ? 1e-12f : dz);
        int sp = 0;
        stack[sp++] = 0;
        boolean found = false;
        float best = tmax;
        while (sp > 0) {
            int node = stack[--sp];
            // slab test
            float t1 = (bmin[node * 3] - ox) * ix, t2 = (bmax[node * 3] - ox) * ix;
            float tn = Math.min(t1, t2), tf = Math.max(t1, t2);
            t1 = (bmin[node * 3 + 1] - oy) * iy; t2 = (bmax[node * 3 + 1] - oy) * iy;
            tn = Math.max(tn, Math.min(t1, t2)); tf = Math.min(tf, Math.max(t1, t2));
            t1 = (bmin[node * 3 + 2] - oz) * iz; t2 = (bmax[node * 3 + 2] - oz) * iz;
            tn = Math.max(tn, Math.min(t1, t2)); tf = Math.min(tf, Math.max(t1, t2));
            if (tf < Math.max(tn, 0f) || tn > best) continue;
            int c = count[node];
            if (c > 0) {
                int st = left[node];
                for (int k = 0; k < c; k++) {
                    int t = triIdx[st + k];
                    if (shadow && alpha[mat[t]] < 0.9f) continue;
                    int o = t * 9;
                    float e1x = v[o + 3] - v[o], e1y = v[o + 4] - v[o + 1], e1z = v[o + 5] - v[o + 2];
                    float e2x = v[o + 6] - v[o], e2y = v[o + 7] - v[o + 1], e2z = v[o + 8] - v[o + 2];
                    float px = dy * e2z - dz * e2y, py = dz * e2x - dx * e2z, pz = dx * e2y - dy * e2x;
                    float det = e1x * px + e1y * py + e1z * pz;
                    if (Math.abs(det) < 1e-14f) continue;
                    float inv = 1f / det;
                    float tx = ox - v[o], ty = oy - v[o + 1], tz = oz - v[o + 2];
                    float u = (tx * px + ty * py + tz * pz) * inv;
                    if (u < 0 || u > 1) continue;
                    float qx = ty * e1z - tz * e1y, qy = tz * e1x - tx * e1z, qz = tx * e1y - ty * e1x;
                    float w = (dx * qx + dy * qy + dz * qz) * inv;
                    if (w < 0 || u + w > 1) continue;
                    float t0 = (e2x * qx + e2y * qy + e2z * qz) * inv;
                    if (t0 > 1e-5f * sceneR && t0 < best) {
                        best = t0;
                        found = true;
                        if (shadow) return true;
                        hit.t = t0; hit.u = u; hit.w = w; hit.tri = t;
                    }
                }
            } else if (c < 0) {
                int l = left[node], r = -c;
                if (sp + 2 >= stack.length) continue;
                stack[sp++] = r;
                stack[sp++] = l;
            }
        }
        return found;
    }

    private boolean isLeaf(int node) { return count[node] > 0; }

    static final class Ctx {
        Rng rng; int[] stack = new int[256];
        Hit[] hits = {new Hit(), new Hit(), new Hit(), new Hit()};
        float[][] tmp = {new float[3], new float[3], new float[3], new float[3]};
    }

    static final class Rng {
        long s;
        Rng(long seed) { s = seed * 0x9E3779B97F4A7C15L + 1; }
        float next() {
            s ^= s << 13; s ^= s >>> 7; s ^= s << 17;
            return ((s >>> 40) & 0xFFFFFF) / 16777216f;
        }
    }

    private void sky(float dx, float dy, float dz, float[] out) {
        float t = Math.max(0f, dy) ;
        out[0] = 0.010f + 0.035f * t; out[1] = 0.013f + 0.05f * t; out[2] = 0.018f + 0.08f * t;
        // soft box glow
        float lx = lc[0] - sceneC[0], ly = lc[1] - sceneC[1], lz = lc[2] - sceneC[2];
        float l = (float) Math.sqrt(lx * lx + ly * ly + lz * lz);
        float d = (dx * lx + dy * ly + dz * lz) / l;
        if (d > 0.93f) { float k = (d - 0.93f) / 0.07f * 3.5f; out[0] += k; out[1] += k; out[2] += k * 0.97f; }
    }

    /** Radiance along a ray. depth limits reflections. */
    private void radiance(float ox, float oy, float oz, float dx, float dy, float dz, int depth, Ctx ctx, float[] out) {
        Rng rng = ctx.rng; int[] stack = ctx.stack; Hit hit = ctx.hits[depth];
        float tr = 1f, tg = 1f, tb = 1f;
        float cr = 0, cg = 0, cb = 0;
        float[] tmp = ctx.tmp[depth];
        for (int layer = 0; layer < 8; layer++) {
            hit.tri = -1;
            float tFloor = dy < -1e-6f ? (floorY - oy) / dy : 1e30f;
            boolean got = trace(ox, oy, oz, dx, dy, dz, Math.min(tFloor, 1e30f), hit, false, stack);
            if (!got) {
                if (tFloor < 1e29f) {
                    // studio floor
                    float px = ox + dx * tFloor, py = floorY, pz = oz + dz * tFloor;
                    float fr = 0.030f, fg = 0.034f, fb = 0.042f;
                    float gx = Math.abs(((px - sceneC[0]) / (sceneR * 0.25f)) % 1f), gz = Math.abs(((pz - sceneC[2]) / (sceneR * 0.25f)) % 1f);
                    if (gx < 0.015f || gz < 0.015f) { fr += 0.012f; fg += 0.02f; fb += 0.03f; }
                    float lit = direct(px, py, pz, 0, 1, 0, rng, stack);
                    float ao = occlusion(px, py, pz, 0, 1, 0, rng, stack);
                    float dist = (float) Math.sqrt((px - sceneC[0]) * (px - sceneC[0]) + (pz - sceneC[2]) * (pz - sceneC[2])) / (sceneR * 3f);
                    float fade = Math.max(0f, 1f - dist);
                    cr += tr * fr * (0.35f * ao + lit) * fade;
                    cg += tg * fg * (0.35f * ao + lit) * fade;
                    cb += tb * fb * (0.35f * ao + lit) * fade;
                    // glossy floor reflection
                    if (depth > 0) {
                        float fres = 0.04f + 0.5f * (float) Math.pow(1f - Math.abs(dy), 5);
                        float rx = dx + (rng.next() - 0.5f) * 0.06f, ry = -dy, rz = dz + (rng.next() - 0.5f) * 0.06f;
                        float rl = (float) Math.sqrt(rx * rx + ry * ry + rz * rz);
                        radiance(px, py + sceneR * 1e-4f, pz, rx / rl, ry / rl, rz / rl, depth - 1, ctx, tmp);
                        cr += tr * tmp[0] * fres * fade; cg += tg * tmp[1] * fres * fade; cb += tb * tmp[2] * fres * fade;
                    }
                } else {
                    sky(dx, dy, dz, tmp);
                    cr += tr * tmp[0]; cg += tg * tmp[1]; cb += tb * tmp[2];
                }
                break;
            }
            int t = hit.tri;
            int mi = mat[t];
            float px = ox + dx * hit.t, py = oy + dy * hit.t, pz = oz + dz * hit.t;
            float b0 = 1 - hit.u - hit.w;
            int o = t * 9;
            float nx = nrm[o] * b0 + nrm[o + 3] * hit.u + nrm[o + 6] * hit.w;
            float ny = nrm[o + 1] * b0 + nrm[o + 4] * hit.u + nrm[o + 7] * hit.w;
            float nz = nrm[o + 2] * b0 + nrm[o + 5] * hit.u + nrm[o + 8] * hit.w;
            float nl = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
            if (nl < 1e-9f) nl = 1;
            nx /= nl; ny /= nl; nz /= nl;
            if (nx * dx + ny * dy + nz * dz > 0) { nx = -nx; ny = -ny; nz = -nz; }
            float a = alpha[mi];
            float r = mr[mi], g = mg[mi], b = mb[mi];
            float sr, sg, sb;
            if (emit[mi] > 0) {
                sr = r * emit[mi]; sg = g * emit[mi]; sb = b * emit[mi];
            } else {
                float lit = direct(px, py, pz, nx, ny, nz, rng, stack);
                float ao = occlusion(px, py, pz, nx, ny, nz, rng, stack);
                float amb = 0.22f * ao;
                float met = metal[mi];
                float diff = (1f - met * 0.85f);
                sr = r * diff * (lit + amb); sg = g * diff * (lit + amb); sb = b * diff * (lit + amb);
                // specular highlight from the soft box
                float lx = lc[0] - px, ly = lc[1] - py, lz = lc[2] - pz;
                float ll = (float) Math.sqrt(lx * lx + ly * ly + lz * lz);
                lx /= ll; ly /= ll; lz /= ll;
                float hx = lx - dx, hy = ly - dy, hz = lz - dz;
                float hl = (float) Math.sqrt(hx * hx + hy * hy + hz * hz);
                float ndh = Math.max(0f, (nx * hx + ny * hy + nz * hz) / hl);
                float shin = 8f + 120f * (1f - rough[mi]);
                float spec = (float) Math.pow(ndh, shin) * (0.25f + met) * (lit > 0.01f ? 1f : 0.15f);
                sr += spec; sg += spec; sb += spec;
                if (depth > 0 && met > 0.2f && a > 0.9f) {
                    float d2 = dx * nx + dy * ny + dz * nz;
                    float rx = dx - 2 * d2 * nx, ry = dy - 2 * d2 * ny, rz = dz - 2 * d2 * nz;
                    float rj = rough[mi] * 0.35f;
                    rx += (rng.next() - 0.5f) * rj; ry += (rng.next() - 0.5f) * rj; rz += (rng.next() - 0.5f) * rj;
                    float rl = (float) Math.sqrt(rx * rx + ry * ry + rz * rz);
                    radiance(px + nx * sceneR * 1e-4f, py + ny * sceneR * 1e-4f, pz + nz * sceneR * 1e-4f, rx / rl, ry / rl, rz / rl, depth - 1, ctx, tmp);
                    float fres = met * 0.55f + 0.45f * (float) Math.pow(1f + d2, 5);
                    fres = Math.min(1f, fres);
                    sr = sr * (1 - fres * 0.6f) + tmp[0] * r * fres * 1.2f;
                    sg = sg * (1 - fres * 0.6f) + tmp[1] * g * fres * 1.2f;
                    sb = sb * (1 - fres * 0.6f) + tmp[2] * b * fres * 1.2f;
                }
            }
            if (a >= 0.99f) {
                cr += tr * sr; cg += tg * sg; cb += tb * sb;
                break;
            }
            // see-through layer
            float fres = (float) Math.pow(1f - Math.abs(nx * dx + ny * dy + nz * dz), 2);
            float aa = Math.min(1f, a + fres * 0.4f);
            cr += tr * sr * aa; cg += tg * sg * aa; cb += tb * sb * aa;
            tr *= (1 - aa); tg *= (1 - aa); tb *= (1 - aa);
            if (tr + tg + tb < 0.02f) break;
            ox = px + dx * sceneR * 1e-4f; oy = py + dy * sceneR * 1e-4f; oz = pz + dz * sceneR * 1e-4f;
        }
        out[0] = cr; out[1] = cg; out[2] = cb;
    }

    private float direct(float px, float py, float pz, float nx, float ny, float nz, Rng rng, int[] stack) {
        float u = rng.next() - 0.5f, w = rng.next() - 0.5f;
        float lx = lc[0] + lu[0] * u + lv[0] * w - px;
        float ly = lc[1] + lu[1] * u + lv[1] * w - py;
        float lz = lc[2] + lu[2] * u + lv[2] * w - pz;
        float ll = (float) Math.sqrt(lx * lx + ly * ly + lz * lz);
        lx /= ll; ly /= ll; lz /= ll;
        float nd = nx * lx + ny * ly + nz * lz;
        // fill light from the camera side (no shadow)
        float fx = cam[0] - px, fy = cam[1] - py, fz = cam[2] - pz;
        float fl = (float) Math.sqrt(fx * fx + fy * fy + fz * fz);
        float fill = Math.max(0f, (nx * fx + ny * fy + nz * fz) / fl) * 0.16f;
        if (nd <= 0) return fill;
        float e = sceneR * 2e-4f;
        if (trace(px + nx * e, py + ny * e, pz + nz * e, lx, ly, lz, ll, null, true, stack)) return fill;
        return nd * lightPower * 0.5f + fill;
    }

    private float occlusion(float px, float py, float pz, float nx, float ny, float nz, Rng rng, int[] stack) {
        // cosine-weighted hemisphere sample
        float r1 = rng.next(), r2 = rng.next();
        float phi = (float) (2 * Math.PI * r1);
        float sr = (float) Math.sqrt(r2);
        float lx = (float) Math.cos(phi) * sr, ly = (float) Math.sin(phi) * sr, lz = (float) Math.sqrt(1 - r2);
        // basis around n
        float ax, ay, az;
        if (Math.abs(nx) < 0.9f) { ax = 0; ay = nz; az = -ny; } else { ax = -nz; ay = 0; az = nx; }
        float al = (float) Math.sqrt(ax * ax + ay * ay + az * az);
        ax /= al; ay /= al; az /= al;
        float bx = ny * az - nz * ay, by = nz * ax - nx * az, bz = nx * ay - ny * ax;
        float dx = ax * lx + bx * ly + nx * lz, dy = ay * lx + by * ly + ny * lz, dz = az * lx + bz * ly + nz * lz;
        float e = sceneR * 2e-4f;
        boolean occ = trace(px + nx * e, py + ny * e, pz + nz * e, dx, dy, dz, sceneR * 0.45f, null, true, stack);
        return occ ? 0.15f : 1f;
    }

    // ------------------------------------------------------------------ passes

    /** Renders one more sample per pixel using all cores. Returns false when cancelled. */
    public boolean pass() {
        final int s = samples;
        ArrayList<Future<?>> fs = new ArrayList<>();
        final int bands = threads * 4;
        for (int k = 0; k < bands; k++) {
            final int band = k;
            fs.add(pool.submit(() -> {
                Ctx ctx = new Ctx();
                ctx.rng = new Rng(band * 7919L + s * 104729L + 17);
                Rng rng = ctx.rng;
                float[] c = new float[3];
                for (int y = band; y < h; y += bands) {
                    if (cancel) return;
                    for (int x = 0; x < w; x++) {
                        float jx = rng.next(), jy = rng.next();
                        float sx = ((x + jx) / w * 2f - 1f) * tanHalf * aspect;
                        float sy = (1f - (y + jy) / h * 2f) * tanHalf;
                        float dx = fwd[0] + right[0] * sx + up[0] * sy;
                        float dy = fwd[1] + right[1] * sx + up[1] * sy;
                        float dz = fwd[2] + right[2] * sx + up[2] * sy;
                        float dl = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
                        radiance(cam[0], cam[1], cam[2], dx / dl, dy / dl, dz / dl, 2, ctx, c);
                        int i = (y * w + x) * 3;
                        acc[i] += c[0]; acc[i + 1] += c[1]; acc[i + 2] += c[2];
                    }
                }
            }));
        }
        for (Future<?> f : fs) {
            try { f.get(); } catch (Exception ex) { return false; }
        }
        if (cancel) return false;
        samples = s + 1;
        return true;
    }

    /** Tone-mapped ARGB image of the accumulated samples. */
    public void image(int[] out) {
        int n = Math.max(1, samples);
        float inv = 1f / n;
        for (int i = 0; i < w * h; i++) {
            float r = acc[i * 3] * inv, g = acc[i * 3 + 1] * inv, b = acc[i * 3 + 2] * inv;
            out[i] = 0xFF000000 | (tone(r) << 16) | (tone(g) << 8) | tone(b);
        }
    }

    static int tone(float x) {
        // ACES-like filmic curve, then gamma
        x *= 1.1f;
        float a = (x * (2.51f * x + 0.03f)) / (x * (2.43f * x + 0.59f) + 0.14f);
        a = Math.max(0f, Math.min(1f, a));
        return (int) (Math.pow(a, 1 / 2.2) * 255f + 0.5f);
    }

    public int triangles() { return ntri; }
}

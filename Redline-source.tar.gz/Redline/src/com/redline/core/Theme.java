package com.redline.core;

/** Colours and small drawing helpers shared by the custom views. */
public final class Theme {
    public static final int BG = 0xFF0A0D12, PANEL = 0xFF121720, PANEL2 = 0xFF19202B, LINE = 0xFF263040;
    public static final int TEXT = 0xFFE8ECF2, DIM = 0xFF8A96A8, FAINT = 0xFF56627A;
    public static final int RED = 0xFFFF3B30, AMBER = 0xFFFFB020, GREEN = 0xFF34D399, CYAN = 0xFF3BD5FF, BLUE = 0xFF4F8CFF, VIOLET = 0xFFB48CFF;

    private Theme() { }

    public static int alpha(int c, float a) { return (c & 0xFFFFFF) | ((int) (Math.max(0, Math.min(1, a)) * 255) << 24); }

    public static boolean in(float x, float y, float[] r) { return r != null && x >= r[0] && y >= r[1] && x <= r[0] + r[2] && y <= r[1] + r[3]; }

    /** Pill button; returns its rect. */
    public static float[] chip(Gfx g, String label, float x, float y, float h, float size, boolean on, int accent) {
        float w = g.textWidth(label, size, Gfx.BOLD) + h * 0.9f;
        g.fillRound(x, y, w, h, h / 2, on ? alpha(accent, 0.22f) : 0x22FFFFFF);
        if (on) g.strokeRound(x, y, w, h, h / 2, Math.max(1f, h * 0.05f), accent);
        g.text(label, x + w / 2, y + h * 0.68f, size, on ? accent : DIM, Gfx.CENTER, Gfx.BOLD);
        return new float[]{x, y, w, h};
    }

    public static float[] button(Gfx g, String label, float x, float y, float w, float h, float size, int fill, int fg) {
        g.fillRound(x, y, w, h, h * 0.28f, fill);
        g.text(label, x + w / 2, y + h * 0.5f + size * 0.36f, size, fg, Gfx.CENTER, Gfx.BOLD);
        return new float[]{x, y, w, h};
    }

    /** Multi-line text wrapping. Returns height used. */
    public static float wrap(Gfx g, String text, float x, float y, float maxW, float size, int color, int style) {
        float lh = size * 1.32f;
        float yy = y;
        for (String para : text.split("\n")) {
            String[] words = para.split(" ");
            StringBuilder line = new StringBuilder();
            for (String w : words) {
                String t = line.length() == 0 ? w : line + " " + w;
                if (g.textWidth(t, size, style) > maxW && line.length() > 0) {
                    g.text(line.toString(), x, yy + size, size, color, Gfx.LEFT, style);
                    yy += lh;
                    line = new StringBuilder(w);
                } else line = new StringBuilder(t);
            }
            if (line.length() > 0) { g.text(line.toString(), x, yy + size, size, color, Gfx.LEFT, style); yy += lh; }
        }
        return yy - y;
    }

    public static float wrapHeight(Gfx g, String text, float maxW, float size, int style) {
        float lh = size * 1.32f;
        float hgt = 0;
        for (String para : text.split("\n")) {
            String[] words = para.split(" ");
            StringBuilder line = new StringBuilder();
            for (String w : words) {
                String t = line.length() == 0 ? w : line + " " + w;
                if (g.textWidth(t, size, style) > maxW && line.length() > 0) { hgt += lh; line = new StringBuilder(w); }
                else line = new StringBuilder(t);
            }
            if (line.length() > 0) hgt += lh;
        }
        return hgt;
    }
}

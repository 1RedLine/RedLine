package com.redline.core;

/** Minimal 2D drawing surface so the custom views run on Android and on the desktop test rig. */
public interface Gfx {
    int BOLD = 1, MONO = 2;
    int LEFT = 0, CENTER = 1, RIGHT = 2;

    void fillRect(float x, float y, float w, float h, int argb);
    void fillRound(float x, float y, float w, float h, float r, int argb);
    void strokeRound(float x, float y, float w, float h, float r, float sw, int argb);
    void gradientV(float x, float y, float w, float h, int top, int bottom);
    void line(float x1, float y1, float x2, float y2, float sw, int argb);
    void circle(float cx, float cy, float r, int argb);
    void ring(float cx, float cy, float r, float sw, int argb);
    /** Stroked arc, angles in degrees, 0 = 3 o'clock, clockwise positive. */
    void arc(float cx, float cy, float r, float startDeg, float sweepDeg, float sw, int argb);
    void poly(float[] xy, int n, int argb);
    void polyline(float[] xy, int n, float sw, int argb);
    void text(String s, float x, float y, float size, int argb, int align, int style);
    float textWidth(String s, float size, int style);
    /** Draws an ARGB pixel buffer scaled into the destination rect (bilinear). */
    void image(int[] px, int pw, int ph, float x, float y, float w, float h);
    void save();
    void clip(float x, float y, float w, float h);
    void translate(float dx, float dy);
    void restore();
}

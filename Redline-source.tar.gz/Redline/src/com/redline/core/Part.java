package com.redline.core;

public final class Part {
    public static final int SHELL = 0, DUCT = 1, MOVING = 2, MISC = 3, CHARGE = 4, LINER = 5, FIGURE = 6;

    public int id;
    public String key;
    public int kind;
    public int color;
    public Mesh mesh;
    public float[] mat = M3.id();
    public float[] explode = new float[3];
    public int cyl = -1;
    public int bank = -1;
    /** Cutaway: half-space test. If half != 0 the part is hidden when half * dot(cutAxis, camDir) > 0. */
    public int half;
    public float[] cutAxis;
    public float heat = 0.4f;
    public boolean emissive;
    public float alpha = 1f;
    public boolean visible = true;
    public boolean doubleSided;
    public float[] center = new float[3];
    public float rotSpeed; // for turbo wheels (deg per crank degree)

    Part(int id, String key, int kind, int color, Mesh mesh) {
        this.id = id;
        this.key = key;
        this.kind = kind;
        this.color = color;
        this.mesh = mesh;
        float[] b = mesh.bounds();
        center[0] = (b[0] + b[3]) / 2;
        center[1] = (b[1] + b[4]) / 2;
        center[2] = (b[2] + b[5]) / 2;
    }
}

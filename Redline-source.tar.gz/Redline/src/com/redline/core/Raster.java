package com.redline.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Software z-buffer renderer with Gouraud lighting, transparency, outlines and particles. */
public final class Raster {
    public static final int SOLID = 0, XRAY = 1, CUTAWAY = 2, FLOW = 3, THERMAL = 4, EXPLODED = 5, SCALE = 6;
    public static final String[] MODES = {"Solid", "X-ray", "Cutaway", "Flow", "Thermal", "Exploded", "Scale"};

    static final java.util.HashSet<String> HIDDEN_IN_SOLID = new java.util.HashSet<>(Arrays.asList(
            "piston", "rod", "crank", "valve_in", "valve_ex", "cam", "pushrod", "actuator", "sc_rotor", "turbine_wheel", "compressor_wheel", "impeller", "rotor", "eshaft"));

    public int w, h;
    public int[] px;
    float[] zb;
    public int[] id, tid;
    int[] bg;

    public float yaw = 52f, pitch = 24f, dist = 1f, fov = 36f;
    public final float[] target = new float[3];
    public int mode = SOLID;
    public float explodeT;
    public String selKey;
    public int selCyl = -1;
    public boolean outlines = true;
    public float heatScale = 0.7f;
    final float[] view = new float[12];
    float focal;
    public final float[] camPos = new float[3];

    // transparent triangles
    float[] tbuf = new float[21 * 1024];
    float[] tkey = new float[1024];
    int[] tidx = new int[1024], tpart = new int[1024];
    int ntt;
    private final HashMap<String, Integer> keyIndex = new HashMap<>();
    private int[] partGroup = new int[0];

    public void resize(int w, int h) {
        if (w == this.w && h == this.h && px != null) return;
        this.w = Math.max(8, w);
        this.h = Math.max(8, h);
        int n = this.w * this.h;
        px = new int[n];
        zb = new float[n];
        id = new int[n];
        tid = new int[n];
        bg = new int[n];
        for (int y = 0; y < this.h; y++) {
            float t = (float) y / this.h;
            for (int x = 0; x < this.w; x++) {
                float dx = (x - this.w * 0.5f) / this.w, dy = (y - this.h * 0.45f) / this.h;
                float rad = (float) Math.sqrt(dx * dx + dy * dy);
                float g = Math.max(0, 1f - rad * 1.6f);
                int r = (int) (10 + 12 * g + 4 * (1 - t)), gg = (int) (13 + 17 * g + 5 * (1 - t)), b = (int) (19 + 26 * g + 6 * (1 - t));
                boolean grid = (x % 24 == 0) || (y % 24 == 0);
                if (grid) { r += 5; gg += 7; b += 10; }
                bg[y * this.w + x] = 0xFF000000 | (r << 16) | (gg << 8) | b;
            }
        }
    }

    public void fit(EngineModel m) {
        target[0] = m.center[0]; target[1] = m.center[1]; target[2] = m.center[2];
        float r = m.radius;
        if (mode == SCALE) {
            r = Math.max(r, 1.0f);
            target[1] = Math.max(m.center[1], m.yMin + 0.9f);
        }
        dist = r / (float) Math.sin(Math.toRadians(fov / 2)) * 0.92f;
    }

    public void buildView() {
        float[] T = M3.trans(-target[0], -target[1], -target[2]);
        float[] Ry = M3.rotY(yaw);
        float[] Rx = M3.rotX(-pitch);
        float[] V = M3.mul(M3.trans(0, 0, -dist), M3.mul(Rx, M3.mul(Ry, T)));
        System.arraycopy(V, 0, view, 0, 12);
        focal = (h * 0.5f) / (float) Math.tan(Math.toRadians(fov / 2));
        // camera position = R^T * (-t)
        float tx = -view[3], ty = -view[7], tz = -view[11];
        camPos[0] = view[0] * tx + view[4] * ty + view[8] * tz;
        camPos[1] = view[1] * tx + view[5] * ty + view[9] * tz;
        camPos[2] = view[2] * tx + view[6] * ty + view[10] * tz;
    }

    /** Projects a model-space point; returns {sx, sy, depth} or null when behind the camera. */
    public float[] project(float x, float y, float z) {
        float X = view[0] * x + view[1] * y + view[2] * z + view[3];
        float Y = view[4] * x + view[5] * y + view[6] * z + view[7];
        float Z = view[8] * x + view[9] * y + view[10] * z + view[11];
        if (-Z < 1e-4f) return null;
        return new float[]{w * 0.5f + focal * X / -Z, h * 0.5f - focal * Y / -Z, -Z};
    }

    private int group(String key) {
        Integer g = keyIndex.get(key);
        if (g == null) { g = keyIndex.size(); keyIndex.put(key, g); }
        return g;
    }

    public boolean visible(Part p, EngineModel m) {
        if (!p.visible && p.kind != Part.FIGURE) return false;
        if (p.kind == Part.FIGURE) return mode == SCALE;
        if (p.kind == Part.CHARGE) return mode == XRAY || mode == FLOW || mode == CUTAWAY || mode == THERMAL;
        if (p.kind == Part.LINER) return mode == XRAY || mode == FLOW || mode == THERMAL;
        if (mode == CUTAWAY && (p.kind == Part.SHELL)) {
            if (p.half == 2) return false;
            if (p.half != 0 && p.cutAxis != null) {
                float d = p.cutAxis[0] * (camPos[0] - m.center[0]) + p.cutAxis[1] * (camPos[1] - m.center[1]) + p.cutAxis[2] * (camPos[2] - m.center[2]);
                if (p.half * d > 0) return false;
            }
        }
        if (mode == CUTAWAY && (p.key.equals("coil") || p.key.equals("rocker") || p.key.equals("oilfilter"))) return false;
        if ((mode == SOLID || mode == SCALE) && p.kind == Part.MOVING && HIDDEN_IN_SOLID.contains(p.key)) return false;
        if ((mode == XRAY || mode == FLOW) && p.key.equals("fins")) return false;
        return true;
    }

    static int heatColor(float t) {
        float[][] stops = {{0f, 22, 36, 110}, {0.2f, 28, 100, 220}, {0.38f, 30, 196, 210}, {0.55f, 90, 220, 90}, {0.7f, 245, 222, 60}, {0.85f, 255, 128, 30}, {1.0f, 255, 50, 36}, {1.15f, 255, 240, 230}};
        if (t <= 0) return 0xFF16246E;
        for (int i = 1; i < stops.length; i++) {
            if (t <= stops[i][0]) {
                float u = (t - stops[i - 1][0]) / (stops[i][0] - stops[i - 1][0]);
                int r = (int) (stops[i - 1][1] + (stops[i][1] - stops[i - 1][1]) * u);
                int g = (int) (stops[i - 1][2] + (stops[i][2] - stops[i - 1][2]) * u);
                int b = (int) (stops[i - 1][3] + (stops[i][3] - stops[i - 1][3]) * u);
                return 0xFF000000 | (r << 16) | (g << 8) | b;
            }
        }
        return 0xFFFFF0E6;
    }

    // ---------------------------------------------------------------- parallel pipeline

    private static ExecutorService pool;
    private static int workers;
    public long lastNanos;

    static synchronized ExecutorService pool() {
        if (pool == null) {
            workers = Math.max(1, Math.min(8, Runtime.getRuntime().availableProcessors()));
            pool = Executors.newFixedThreadPool(workers, r -> {
                Thread t = new Thread(r, "redline-raster");
                t.setDaemon(true);
                t.setPriority(Thread.MAX_PRIORITY);
                return t;
            });
        }
        return pool;
    }

    // global transformed vertices for this frame
    float[] gx = new float[4096], gy = new float[4096], gz = new float[4096], gr = new float[4096], gg = new float[4096], gb = new float[4096], ga = new float[4096];
    int gn;
    // opaque triangles (vertex indices already oriented), part ids, y-ranges
    int[] ot = new int[3 * 4096], opid = new int[4096];
    short[] oy0 = new short[4096], oy1 = new short[4096];
    int ont;
    private EngineModel cur;
    private int phase;
    private final ArrayList<Callable<Void>> bands = new ArrayList<>();
    private int bandCount;

    private void ensureG(int n) {
        if (gx.length < n) {
            int c = Math.max(n, gx.length * 2);
            gx = Arrays.copyOf(gx, c); gy = Arrays.copyOf(gy, c); gz = Arrays.copyOf(gz, c);
            gr = Arrays.copyOf(gr, c); gg = Arrays.copyOf(gg, c); gb = Arrays.copyOf(gb, c); ga = Arrays.copyOf(ga, c);
        }
    }

    private void addOpaque(int a, int b, int c, int pid) {
        if (ont >= opid.length) {
            int cpt = opid.length * 2;
            ot = Arrays.copyOf(ot, cpt * 3); opid = Arrays.copyOf(opid, cpt);
            oy0 = Arrays.copyOf(oy0, cpt); oy1 = Arrays.copyOf(oy1, cpt);
        }
        ot[ont * 3] = a; ot[ont * 3 + 1] = b; ot[ont * 3 + 2] = c;
        opid[ont] = pid;
        float mn = Math.min(gy[a], Math.min(gy[b], gy[c])), mx = Math.max(gy[a], Math.max(gy[b], gy[c]));
        oy0[ont] = (short) Math.max(0, Math.min(h - 1, (int) Math.floor(mn)));
        oy1[ont] = (short) Math.max(0, Math.min(h - 1, (int) Math.ceil(mx)));
        ont++;
    }

    public void render(EngineModel m) {
        long t0 = System.nanoTime();
        buildView();
        cur = m;
        gn = 0;
        ont = 0;
        ntt = 0;
        if (partGroup.length < m.parts.size()) partGroup = new int[m.parts.size()];
        for (Part p : m.parts) partGroup[p.id] = group(p.key);
        float explode = (mode == EXPLODED) ? explodeT : 0f;
        for (Part p : m.parts) {
            if (!visible(p, m)) continue;
            System.arraycopy(p.mat, 0, M, 0, 12);
            M[3] += p.explode[0] * explode;
            M[7] += p.explode[1] * explode;
            M[11] += p.explode[2] * explode;
            M3.mul(view, M, MV);
            drawPart(p, MV, m);
        }
        if (ntt > 1) sortIdx(tidx, tkey, 0, ntt - 1);
        ExecutorService ex = pool();
        int nb = Math.max(1, Math.min(workers * 2, h / 8));
        if (bands.size() != nb || bandCount != h) {
            bands.clear();
            for (int i = 0; i < nb; i++) {
                final int y0 = h * i / nb, y1 = h * (i + 1) / nb;
                bands.add(() -> { band(y0, y1); return null; });
            }
            bandCount = h;
        }
        try {
            if (workers <= 1) {
                for (phase = 0; phase < 3; phase++) band(0, h);
            } else {
                for (phase = 0; phase < 3; phase++) ex.invokeAll(bands);
            }
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
        }
        lastNanos = System.nanoTime() - t0;
    }

    private final float[] M = new float[12], MV = new float[12];

    /** Phase 0: clear + opaque. Phase 1: outlines. Phase 2: transparent + particles. */
    private void band(int y0, int y1) {
        if (phase == 0) {
            int a = y0 * w, b = y1 * w;
            System.arraycopy(bg, a, px, a, b - a);
            Arrays.fill(zb, a, b, 0f);
            Arrays.fill(id, a, b, -1);
            Arrays.fill(tid, a, b, -1);
            for (int t = 0; t < ont; t++) {
                if (oy1[t] < y0 || oy0[t] >= y1) continue;
                int i0 = ot[t * 3], i1 = ot[t * 3 + 1], i2 = ot[t * 3 + 2];
                tri(gx[i0], gy[i0], gz[i0], gr[i0], gg[i0], gb[i0], gx[i1], gy[i1], gz[i1], gr[i1], gg[i1], gb[i1], gx[i2], gy[i2], gz[i2], gr[i2], gg[i2], gb[i2], opid[t], y0, y1);
            }
        } else if (phase == 1) {
            if (outlines) outline(y0, y1);
        } else {
            for (int k = 0; k < ntt; k++) {
                int t = tidx[k];
                int o = t * 21;
                float ax = tbuf[o], ay = tbuf[o + 1], bx = tbuf[o + 7], by = tbuf[o + 8], cx = tbuf[o + 14], cy = tbuf[o + 15];
                float mn = Math.min(ay, Math.min(by, cy)), mx = Math.max(ay, Math.max(by, cy));
                if (mx < y0 || mn >= y1) continue;
                float area = (bx - ax) * (cy - ay) - (cx - ax) * (by - ay);
                if (area < 0) triBlend(o, o + 14, o + 7, tpart[t], y0, y1);
                else triBlend(o, o + 7, o + 14, tpart[t], y0, y1);
            }
            if (mode == FLOW || mode == XRAY || mode == CUTAWAY || mode == THERMAL) drawParticles(cur, y0, y1);
        }
    }

    private void drawPart(Part p, float[] MV, EngineModel m) {
        Mesh mesh = p.mesh;
        int nv = mesh.nv;
        boolean selected = selKey != null && selKey.equals(p.key) && (selCyl < 0 || p.cyl < 0 || p.cyl == selCyl || !(p.key.equals("piston") || p.key.equals("rod") || p.key.equals("charge")));
        boolean transparent = false;
        boolean doubleSided = p.doubleSided;
        float alpha = 1f;
        float fresnelK = 0f;
        int base = p.color;
        boolean emissive = p.emissive;
        float tintK = 0f;
        int tint = 0xFF64C8FF;
        boolean heat = mode == THERMAL;
        switch (mode) {
            case XRAY:
                if (p.kind == Part.SHELL) { transparent = true; doubleSided = false; alpha = 0.07f; fresnelK = 0.6f; tintK = 0.65f; }
                else if (p.kind == Part.DUCT) { transparent = true; alpha = 0.24f; fresnelK = 0.45f; tintK = 0.35f; doubleSided = false; }
                else if (p.kind == Part.LINER) { transparent = true; alpha = 0.06f; fresnelK = 0.35f; tintK = 0.8f; }
                else if (p.kind == Part.CHARGE) { transparent = true; alpha = 0.6f; }
                break;
            case FLOW:
                if (p.kind == Part.SHELL) { transparent = true; doubleSided = false; alpha = 0.04f; fresnelK = 0.4f; tintK = 0.7f; }
                else if (p.kind == Part.DUCT) { transparent = true; alpha = 0.14f; fresnelK = 0.35f; tintK = 0.4f; doubleSided = false; }
                else if (p.kind == Part.LINER) { transparent = true; alpha = 0.05f; fresnelK = 0.3f; tintK = 0.8f; }
                else if (p.kind == Part.CHARGE) { transparent = true; alpha = 0.45f; }
                break;
            case THERMAL:
                if (p.kind == Part.SHELL) { transparent = true; doubleSided = true; alpha = 0.18f; fresnelK = 0.45f; }
                else if (p.kind == Part.DUCT) { transparent = true; alpha = 0.55f; fresnelK = 0.3f; }
                else if (p.kind == Part.LINER) { transparent = true; alpha = 0.18f; fresnelK = 0.3f; }
                else if (p.kind == Part.CHARGE) { transparent = true; alpha = 0.5f; }
                break;
            case CUTAWAY:
                if (p.kind == Part.SHELL) doubleSided = true;
                else if (p.kind == Part.CHARGE) { transparent = true; alpha = 0.55f; }
                break;
        }
        if ((mode == XRAY || mode == FLOW) && (p.key.equals("flywheel") || p.key.equals("pulley") || p.key.equals("intercooler"))) {
            transparent = true; doubleSided = true; alpha = 0.12f; fresnelK = 0.35f; tintK = 0.5f;
        }
        if (selected) {
            if (transparent && p.kind != Part.CHARGE) alpha = Math.max(alpha, 0.38f);
            tint = 0xFF3BE0FF;
            tintK = Math.max(tintK, 0.5f);
        }
        float br = ((base >> 16) & 255) / 255f, bgc = ((base >> 8) & 255) / 255f, bb = (base & 255) / 255f;
        float tr = ((tint >> 16) & 255) / 255f, tg = ((tint >> 8) & 255) / 255f, tb = (tint & 255) / 255f;
        if (tintK > 0 && !heat) {
            br = br * (1 - tintK) + tr * tintK; bgc = bgc * (1 - tintK) + tg * tintK; bb = bb * (1 - tintK) + tb * tintK;
        }
        if (mode == FLOW && p.kind == Part.MOVING) { br *= 0.55f; bgc *= 0.6f; bb *= 0.7f; }
        float heatBase = p.heat * heatScale;
        float gloss = (p.kind == Part.MOVING || p.kind == Part.MISC) ? 0.5f : 0.25f;
        final float l1x = -0.45f, l1y = 0.62f, l1z = 0.64f;
        final float l2x = 0.7f, l2y = 0.1f, l2z = 0.35f;
        final float hx = l1x * 0.5f, hy = l1y * 0.5f, hz = (l1z + 1f) * 0.5f;
        final float hl = (float) Math.sqrt(hx * hx + hy * hy + hz * hz);
        float[] P = mesh.p, N = mesh.n, H = mesh.h;
        int vb = gn;
        ensureG(gn + nv);
        float halfW = w * 0.5f, halfH = h * 0.5f;
        for (int i = 0; i < nv; i++) {
            int gi = vb + i;
            float x = P[i * 3], y = P[i * 3 + 1], z = P[i * 3 + 2];
            float X = MV[0] * x + MV[1] * y + MV[2] * z + MV[3];
            float Y = MV[4] * x + MV[5] * y + MV[6] * z + MV[7];
            float Z = MV[8] * x + MV[9] * y + MV[10] * z + MV[11];
            float d = -Z;
            if (d < 1e-4f) { gz[gi] = -1; continue; }
            float nx = N[i * 3], ny = N[i * 3 + 1], nz = N[i * 3 + 2];
            float NX = MV[0] * nx + MV[1] * ny + MV[2] * nz;
            float NY = MV[4] * nx + MV[5] * ny + MV[6] * nz;
            float NZ = MV[8] * nx + MV[9] * ny + MV[10] * nz;
            float nl = NX * NX + NY * NY + NZ * NZ;
            if (nl > 1.0001f || nl < 0.9999f) {
                float inv = 1f / (float) Math.sqrt(Math.max(1e-18f, nl));
                NX *= inv; NY *= inv; NZ *= inv;
            }
            float id = 1f / d;
            gx[gi] = halfW + focal * X * id;
            gy[gi] = halfH - focal * Y * id;
            gz[gi] = id;
            float ex = -X * id, ey = -Y * id;
            float ndv = (NX * ex + NY * ey + NZ) / (float) Math.sqrt(ex * ex + ey * ey + 1f);
            float cr = br, cg = bgc, cb = bb;
            if (heat) {
                int hc = heatColor(heatBase * H[i] + (p.kind == Part.CHARGE ? 0.6f : 0f));
                cr = ((hc >> 16) & 255) / 255f; cg = ((hc >> 8) & 255) / 255f; cb = (hc & 255) / 255f;
                if (selected) { cr = cr * 0.5f + 0.5f * tr; cg = cg * 0.5f + 0.5f * tg; cb = cb * 0.5f + 0.5f * tb; }
            }
            if (emissive && !heat) {
                float k = 0.7f + 0.35f * Math.abs(ndv);
                gr[gi] = cr * k; gg[gi] = cg * k; gb[gi] = cb * k;
            } else {
                float sgn = (doubleSided && ndv < 0) ? -1f : 1f;
                float d1 = (NX * l1x + NY * l1y + NZ * l1z) * sgn;
                float d2 = (NX * l2x + NY * l2y + NZ * l2z) * sgn;
                float sp = (NX * hx + NY * hy + NZ * hz) * sgn / hl;
                float lit = 0.26f + 0.78f * Math.max(0, d1) + 0.22f * Math.max(0, d2);
                float spec = 0f;
                if (sp > 0.6f) { float s2 = sp * sp, s4 = s2 * s2, s8 = s4 * s4, s16 = s8 * s8; spec = s16 * s8 * s4 * gloss; }
                float f1 = 1f - Math.abs(ndv);
                float rim = f1 * f1 * f1 * 0.18f;
                if (heat) { lit = 0.55f + 0.45f * lit; spec *= 0.4f; }
                gr[gi] = cr * lit + spec + rim * 0.5f;
                gg[gi] = cg * lit + spec + rim * 0.6f;
                gb[gi] = cb * lit + spec + rim * 0.8f;
            }
            float a = alpha;
            if (fresnelK > 0) { float f = 1f - Math.abs(ndv); a = alpha + fresnelK * f * f; }
            ga[gi] = Math.min(1f, a);
        }
        gn += nv;
        int[] T = mesh.t;
        int idv = p.id;
        for (int k = 0; k < mesh.nt; k++) {
            int a = vb + T[k * 3], b = vb + T[k * 3 + 1], c = vb + T[k * 3 + 2];
            if (gz[a] < 0 || gz[b] < 0 || gz[c] < 0) continue;
            float area = (gx[b] - gx[a]) * (gy[c] - gy[a]) - (gx[c] - gx[a]) * (gy[b] - gy[a]);
            boolean front = area < 0;
            if (!front && !doubleSided) continue;
            float mnx = Math.min(gx[a], Math.min(gx[b], gx[c])), mxx = Math.max(gx[a], Math.max(gx[b], gx[c]));
            float mny = Math.min(gy[a], Math.min(gy[b], gy[c])), mxy = Math.max(gy[a], Math.max(gy[b], gy[c]));
            if (mxx < 0 || mny >= h || mxy < 0 || mnx >= w) continue;
            if (mxx - mnx < 0.35f && mxy - mny < 0.35f) continue;
            if (transparent) addTransparent(a, b, c, idv);
            else if (front) addOpaque(a, c, b, idv);
            else addOpaque(a, b, c, idv);
        }
    }

    private void addTransparent(int a, int b, int c, int part) {
        if (ntt >= tkey.length) {
            int nn = tkey.length * 2;
            tkey = Arrays.copyOf(tkey, nn);
            tidx = Arrays.copyOf(tidx, nn);
            tpart = Arrays.copyOf(tpart, nn);
            tbuf = Arrays.copyOf(tbuf, nn * 21);
        }
        int o = ntt * 21;
        tbuf[o] = gx[a]; tbuf[o + 1] = gy[a]; tbuf[o + 2] = gz[a]; tbuf[o + 3] = gr[a]; tbuf[o + 4] = gg[a]; tbuf[o + 5] = gb[a]; tbuf[o + 6] = ga[a];
        tbuf[o + 7] = gx[b]; tbuf[o + 8] = gy[b]; tbuf[o + 9] = gz[b]; tbuf[o + 10] = gr[b]; tbuf[o + 11] = gg[b]; tbuf[o + 12] = gb[b]; tbuf[o + 13] = ga[b];
        tbuf[o + 14] = gx[c]; tbuf[o + 15] = gy[c]; tbuf[o + 16] = gz[c]; tbuf[o + 17] = gr[c]; tbuf[o + 18] = gg[c]; tbuf[o + 19] = gb[c]; tbuf[o + 20] = ga[c];
        tkey[ntt] = gz[a] + gz[b] + gz[c];
        tidx[ntt] = ntt;
        tpart[ntt] = part;
        ntt++;
    }

    /** Sort ascending by key (far first). */
    private static void sortIdx(int[] idx, float[] key, int lo, int hi) {
        while (lo < hi) {
            int i = lo, j = hi;
            float pv = key[idx[(lo + hi) >>> 1]];
            while (i <= j) {
                while (key[idx[i]] < pv) i++;
                while (key[idx[j]] > pv) j--;
                if (i <= j) { int t = idx[i]; idx[i] = idx[j]; idx[j] = t; i++; j--; }
            }
            if (j - lo < hi - i) { sortIdx(idx, key, lo, j); lo = i; }
            else { sortIdx(idx, key, i, hi); hi = j; }
        }
    }

    private static int clamp255(float v) {
        int i = (int) (v * 255f);
        return i < 0 ? 0 : (i > 255 ? 255 : i);
    }

    /** Opaque, depth-tested Gouraud triangle limited to rows [yLo, yHi). Span-based with incremental attributes. */
    private void tri(float x0, float y0, float z0, float r0, float g0, float b0,
                     float x1, float y1, float z1, float r1, float g1, float b1,
                     float x2, float y2, float z2, float r2, float g2, float b2, int pid, int yLo, int yHi) {
        float area = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0);
        if (area <= 1e-6f) return;
        int minX = Math.max(0, (int) Math.floor(Math.min(x0, Math.min(x1, x2))));
        int maxX = Math.min(w - 1, (int) Math.ceil(Math.max(x0, Math.max(x1, x2))));
        int minY = Math.max(yLo, (int) Math.floor(Math.min(y0, Math.min(y1, y2))));
        int maxY = Math.min(yHi - 1, (int) Math.ceil(Math.max(y0, Math.max(y1, y2))));
        if (minX > maxX || minY > maxY) return;
        float inv = 1f / area;
        float e0dx = -(y2 - y1) * inv, e1dx = -(y0 - y2) * inv, e2dx = -(y1 - y0) * inv;
        float e0dy = (x2 - x1) * inv, e1dy = (x0 - x2) * inv, e2dy = (x1 - x0) * inv;
        float sx = minX + 0.5f, sy = minY + 0.5f;
        float e0 = ((x2 - x1) * (sy - y1) - (y2 - y1) * (sx - x1)) * inv;
        float e1 = ((x0 - x2) * (sy - y2) - (y0 - y2) * (sx - x2)) * inv;
        float e2 = ((x1 - x0) * (sy - y0) - (y1 - y0) * (sx - x0)) * inv;
        r0 *= 255f; r1 *= 255f; r2 *= 255f; g0 *= 255f; g1 *= 255f; g2 *= 255f; b0 *= 255f; b1 *= 255f; b2 *= 255f;
        float zdx = e0dx * z0 + e1dx * z1 + e2dx * z2, zdy = e0dy * z0 + e1dy * z1 + e2dy * z2;
        float rdx = e0dx * r0 + e1dx * r1 + e2dx * r2, rdy = e0dy * r0 + e1dy * r1 + e2dy * r2;
        float gdx = e0dx * g0 + e1dx * g1 + e2dx * g2, gdy = e0dy * g0 + e1dy * g1 + e2dy * g2;
        float bdx = e0dx * b0 + e1dx * b1 + e2dx * b2, bdy = e0dy * b0 + e1dy * b1 + e2dy * b2;
        float zr = e0 * z0 + e1 * z1 + e2 * z2;
        float rr = e0 * r0 + e1 * r1 + e2 * r2, gr0 = e0 * g0 + e1 * g1 + e2 * g2, br0 = e0 * b0 + e1 * b1 + e2 * b2;
        final float[] zb = this.zb;
        final int[] px = this.px, id = this.id;
        final int span = maxX - minX;
        for (int y = minY; y <= maxY; y++) {
            int lo = 0, hi = span;
            boolean skip = false;
            // analytic span: where all three edge functions are >= 0
            if (e0dx > 1e-9f) lo = Math.max(lo, (int) Math.ceil(-e0 / e0dx - 1e-3f)); else if (e0dx < -1e-9f) hi = Math.min(hi, (int) Math.floor(-e0 / e0dx + 1e-3f)); else if (e0 < -1e-6f) skip = true;
            if (e1dx > 1e-9f) lo = Math.max(lo, (int) Math.ceil(-e1 / e1dx - 1e-3f)); else if (e1dx < -1e-9f) hi = Math.min(hi, (int) Math.floor(-e1 / e1dx + 1e-3f)); else if (e1 < -1e-6f) skip = true;
            if (e2dx > 1e-9f) lo = Math.max(lo, (int) Math.ceil(-e2 / e2dx - 1e-3f)); else if (e2dx < -1e-9f) hi = Math.min(hi, (int) Math.floor(-e2 / e2dx + 1e-3f)); else if (e2 < -1e-6f) skip = true;
            if (!skip && lo <= hi) {
                float z = zr + zdx * lo, r = rr + rdx * lo, g = gr0 + gdx * lo, bl = br0 + bdx * lo;
                int i = y * w + minX + lo, end = y * w + minX + hi;
                for (; i <= end; i++) {
                    if (z > zb[i]) {
                        zb[i] = z;
                        id[i] = pid;
                        int ri = (int) r, gi = (int) g, bi = (int) bl;
                        if (ri > 255) ri = 255; else if (ri < 0) ri = 0;
                        if (gi > 255) gi = 255; else if (gi < 0) gi = 0;
                        if (bi > 255) bi = 255; else if (bi < 0) bi = 0;
                        px[i] = 0xFF000000 | (ri << 16) | (gi << 8) | bi;
                    }
                    z += zdx; r += rdx; g += gdx; bl += bdx;
                }
            }
            e0 += e0dy; e1 += e1dy; e2 += e2dy;
            zr += zdy; rr += rdy; gr0 += gdy; br0 += bdy;
        }
    }

    private void triBlend(int oa, int ob, int oc, int pid, int yLo, int yHi) {
        float[] t = tbuf;
        float x0 = t[oa], y0 = t[oa + 1], z0 = t[oa + 2];
        float x1 = t[ob], y1 = t[ob + 1], z1 = t[ob + 2];
        float x2 = t[oc], y2 = t[oc + 1], z2 = t[oc + 2];
        float area = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0);
        if (area <= 1e-6f) return;
        int minX = Math.max(0, (int) Math.floor(Math.min(x0, Math.min(x1, x2))));
        int maxX = Math.min(w - 1, (int) Math.ceil(Math.max(x0, Math.max(x1, x2))));
        int minY = Math.max(yLo, (int) Math.floor(Math.min(y0, Math.min(y1, y2))));
        int maxY = Math.min(yHi - 1, (int) Math.ceil(Math.max(y0, Math.max(y1, y2))));
        if (minX > maxX || minY > maxY) return;
        float inv = 1f / area;
        float r0 = t[oa + 3] * 255f, g0 = t[oa + 4] * 255f, b0 = t[oa + 5] * 255f, a0 = t[oa + 6];
        float r1 = t[ob + 3] * 255f, g1 = t[ob + 4] * 255f, b1 = t[ob + 5] * 255f, a1 = t[ob + 6];
        float r2 = t[oc + 3] * 255f, g2 = t[oc + 4] * 255f, b2 = t[oc + 5] * 255f, a2 = t[oc + 6];
        float e0dx = -(y2 - y1) * inv, e1dx = -(y0 - y2) * inv, e2dx = -(y1 - y0) * inv;
        float e0dy = (x2 - x1) * inv, e1dy = (x0 - x2) * inv, e2dy = (x1 - x0) * inv;
        float sx = minX + 0.5f, sy = minY + 0.5f;
        float e0 = ((x2 - x1) * (sy - y1) - (y2 - y1) * (sx - x1)) * inv;
        float e1 = ((x0 - x2) * (sy - y2) - (y0 - y2) * (sx - x2)) * inv;
        float e2 = ((x1 - x0) * (sy - y0) - (y1 - y0) * (sx - x0)) * inv;
        float zdx = e0dx * z0 + e1dx * z1 + e2dx * z2, zdy = e0dy * z0 + e1dy * z1 + e2dy * z2;
        float rdx = e0dx * r0 + e1dx * r1 + e2dx * r2, rdy = e0dy * r0 + e1dy * r1 + e2dy * r2;
        float gdx = e0dx * g0 + e1dx * g1 + e2dx * g2, gdy = e0dy * g0 + e1dy * g1 + e2dy * g2;
        float bdx = e0dx * b0 + e1dx * b1 + e2dx * b2, bdy = e0dy * b0 + e1dy * b1 + e2dy * b2;
        float adx = e0dx * a0 + e1dx * a1 + e2dx * a2, ady = e0dy * a0 + e1dy * a1 + e2dy * a2;
        float zr = e0 * z0 + e1 * z1 + e2 * z2;
        float rr = e0 * r0 + e1 * r1 + e2 * r2, gr0 = e0 * g0 + e1 * g1 + e2 * g2, br0 = e0 * b0 + e1 * b1 + e2 * b2, ar = e0 * a0 + e1 * a1 + e2 * a2;
        final float[] zb = this.zb;
        final int[] px = this.px, tid = this.tid;
        final int span = maxX - minX;
        for (int y = minY; y <= maxY; y++) {
            int lo = 0, hi = span;
            boolean skip = false;
            if (e0dx > 1e-9f) lo = Math.max(lo, (int) Math.ceil(-e0 / e0dx - 1e-3f)); else if (e0dx < -1e-9f) hi = Math.min(hi, (int) Math.floor(-e0 / e0dx + 1e-3f)); else if (e0 < -1e-6f) skip = true;
            if (e1dx > 1e-9f) lo = Math.max(lo, (int) Math.ceil(-e1 / e1dx - 1e-3f)); else if (e1dx < -1e-9f) hi = Math.min(hi, (int) Math.floor(-e1 / e1dx + 1e-3f)); else if (e1 < -1e-6f) skip = true;
            if (e2dx > 1e-9f) lo = Math.max(lo, (int) Math.ceil(-e2 / e2dx - 1e-3f)); else if (e2dx < -1e-9f) hi = Math.min(hi, (int) Math.floor(-e2 / e2dx + 1e-3f)); else if (e2 < -1e-6f) skip = true;
            if (!skip && lo <= hi) {
                float z = zr + zdx * lo, r = rr + rdx * lo, g = gr0 + gdx * lo, bl = br0 + bdx * lo, al = ar + adx * lo;
                int i = y * w + minX + lo, end = y * w + minX + hi;
                for (; i <= end; i++) {
                    if (z > zb[i]) {
                        int d = px[i];
                        float dr = (d >> 16) & 255, dg = (d >> 8) & 255, db = d & 255;
                        int ri = (int) (dr + (r - dr) * al), gi = (int) (dg + (g - dg) * al), bi = (int) (db + (bl - db) * al);
                        if (ri > 255) ri = 255; else if (ri < 0) ri = 0;
                        if (gi > 255) gi = 255; else if (gi < 0) gi = 0;
                        if (bi > 255) bi = 255; else if (bi < 0) bi = 0;
                        px[i] = 0xFF000000 | (ri << 16) | (gi << 8) | bi;
                        tid[i] = pid;
                    }
                    z += zdx; r += rdx; g += gdx; bl += bdx; al += adx;
                }
            }
            e0 += e0dy; e1 += e1dy; e2 += e2dy;
            zr += zdy; rr += rdy; gr0 += gdy; br0 += bdy; ar += ady;
        }
    }

    private void outline(int y0, int y1) {
        boolean bright = mode == XRAY || mode == FLOW;
        int yEnd = Math.min(y1, h - 1);
        for (int y = y0; y < yEnd; y++) {
            int row = y * w;
            for (int x = 0; x < w - 1; x++) {
                int i = row + x;
                int a = id[i], b = id[i + 1], c = id[i + w];
                if (a < 0 && b < 0 && c < 0) continue;
                boolean edge = false;
                int ga = a < 0 ? -1 : partGroup[a];
                if ((b < 0 ? -1 : partGroup[b]) != ga || (c < 0 ? -1 : partGroup[c]) != ga) edge = true;
                else {
                    float z = zb[i];
                    if (Math.abs(zb[i + 1] - z) > z * 0.035f || Math.abs(zb[i + w] - z) > z * 0.035f) edge = true;
                }
                if (edge) {
                    int d = px[i];
                    int r = (d >> 16) & 255, g = (d >> 8) & 255, bl = d & 255;
                    if (bright) { r = Math.min(255, r + 40); g = Math.min(255, g + 70); bl = Math.min(255, bl + 90); }
                    else { r = r * 45 / 100; g = g * 45 / 100; bl = bl * 50 / 100; }
                    px[i] = 0xFF000000 | (r << 16) | (g << 8) | bl;
                }
            }
        }
    }

    public boolean[] flowMask = {true, true, true, true, true, true, true, true};

    private void drawParticles(EngineModel m, int yLo, int yHi) {
        float scaleK = focal;
        if (mode == FLOW) {
            for (int k = 0; k < m.np; k++) {
                int col = m.pc[k];
                int type = m.pt != null && k < m.pt.length ? m.pt[k] : -1;
                if (type >= 0 && !flowMask[type]) continue;
                float x = m.px[k], y = m.py[k], z = m.pz[k];
                float Z = view[8] * x + view[9] * y + view[10] * z + view[11];
                float d = -Z;
                if (d < 1e-4f) continue;
                float Y = view[4] * x + view[5] * y + view[6] * z + view[7];
                float sy = h * 0.5f - scaleK * Y / d;
                float rad = Math.max(1.3f, m.ps[k] * scaleK / d);
                if (sy + rad < yLo || sy - rad >= yHi) continue;
                float X = view[0] * x + view[1] * y + view[2] * z + view[3];
                float sx = w * 0.5f + scaleK * X / d;
                glow(sx, sy, rad, col, 1f / d, 0.9f, yLo, yHi);
            }
        }
        for (int k = 0; k < m.sparks.size(); k++) {
            float[] s = m.sparks.get(k);
            float x = s[0], y = s[1], z = s[2];
            float X = view[0] * x + view[1] * y + view[2] * z + view[3];
            float Y = view[4] * x + view[5] * y + view[6] * z + view[7];
            float Z = view[8] * x + view[9] * y + view[10] * z + view[11];
            float d = -Z;
            if (d < 1e-4f) continue;
            float sx = w * 0.5f + scaleK * X / d, sy = h * 0.5f - scaleK * Y / d;
            float rad = Math.max(2f, m.B * 0.28f * scaleK / d);
            glow(sx, sy, rad, m.e.diesel() ? 0xFFFFA040 : 0xFFFFF6C8, 1f / d, Math.max(0, Math.min(1, s[3])), yLo, yHi);
        }
    }

    private void glow(float cx, float cy, float r, int col, float iz, float intensity, int yLo, int yHi) {
        int x0 = Math.max(0, (int) (cx - r)), x1 = Math.min(w - 1, (int) (cx + r));
        int y0 = Math.max(yLo, (int) (cy - r)), y1 = Math.min(yHi - 1, (int) (cy + r));
        float a0 = ((col >>> 24) & 255) / 255f * intensity;
        float cr = (col >> 16) & 255, cg = (col >> 8) & 255, cb = col & 255;
        float r2 = r * r;
        for (int y = y0; y <= y1; y++) {
            float dy = y + 0.5f - cy;
            int row = y * w;
            for (int x = x0; x <= x1; x++) {
                float dx = x + 0.5f - cx;
                float dd = dx * dx + dy * dy;
                if (dd > r2) continue;
                int i = row + x;
                if (zb[i] > iz * 1.002f) continue;
                float f = 1f - dd / r2;
                float a = a0 * f * f * 1.2f;
                int d = px[i];
                int r_ = Math.min(255, ((d >> 16) & 255) + (int) (cr * a));
                int g_ = Math.min(255, ((d >> 8) & 255) + (int) (cg * a));
                int b_ = Math.min(255, (d & 255) + (int) (cb * a));
                px[i] = 0xFF000000 | (r_ << 16) | (g_ << 8) | b_;
            }
        }
    }

    /** Part id under a raster pixel, preferring opaque internals in see-through modes. */
    public int pick(int x, int y) {
        if (x < 0 || y < 0 || x >= w || y >= h) return -1;
        int best = -1;
        for (int r = 0; r <= 4 && best < 0; r++) {
            for (int dy = -r; dy <= r && best < 0; dy++)
                for (int dx = -r; dx <= r; dx++) {
                    int xx = x + dx, yy = y + dy;
                    if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
                    int i = yy * w + xx;
                    int o = id[i], t = tid[i];
                    int c = (mode == XRAY || mode == FLOW || mode == THERMAL) ? (o >= 0 ? o : t) : (t >= 0 && (o < 0) ? t : o);
                    if (c >= 0) { best = c; break; }
                }
        }
        return best;
    }
}

package com.redline.core;

import java.util.Locale;

/** User unit preferences and formatting. */
public final class Units {
    public static boolean mph;
    public static int power;   // 0 hp, 1 PS, 2 kW
    public static int torque;  // 0 Nm, 1 lb-ft

    private Units() { }

    public static float powerVal(float kw) {
        switch (power) {
            case 1: return kw / 0.73549875f;
            case 2: return kw;
        }
        return kw / 0.745699872f;
    }

    public static String powerUnit() { return power == 1 ? "PS" : (power == 2 ? "kW" : "hp"); }

    public static String pow(float kw) {
        float v = powerVal(kw);
        if (v < 10) return String.format(Locale.US, "%.1f %s", v, powerUnit());
        return String.format(Locale.US, "%,d %s", Math.round(v), powerUnit());
    }

    public static float torqueVal(float nm) { return torque == 1 ? nm / 1.35581795f : nm; }

    public static String torqueUnit() { return torque == 1 ? "lb-ft" : "Nm"; }

    public static String tq(float nm) {
        float v = torqueVal(nm);
        if (v < 10) return String.format(Locale.US, "%.1f %s", v, torqueUnit());
        return String.format(Locale.US, "%,d %s", Math.round(v), torqueUnit());
    }

    public static float speedVal(float kmh) { return mph ? kmh / 1.609344f : kmh; }

    public static String speedUnit() { return mph ? "mph" : "km/h"; }

    public static String spd(float kmh) { return Math.round(speedVal(kmh)) + " " + speedUnit(); }

    public static String disp(float cc) {
        if (cc < 10) return String.format(Locale.US, "%.1f cc", cc);
        if (cc < 1000) return Math.round(cc) + " cc";
        if (cc < 100000) return String.format(Locale.US, "%.1f L", cc / 1000f);
        return String.format(Locale.US, "%,d L", Math.round(cc / 1000f));
    }

    public static String secs(float s) { return s < 0 ? "—" : String.format(Locale.US, "%.2f s", s); }

    public static String rpm(float r) { return String.format(Locale.US, "%,d rpm", Math.round(r)); }

    public static String mass(float kg) {
        if (kg >= 10000) return String.format(Locale.US, "%,d t", Math.round(kg / 1000f));
        if (kg < 10) return String.format(Locale.US, "%.1f kg", kg);
        return String.format(Locale.US, "%,d kg", Math.round(kg));
    }

    public static String len(float m) {
        if (m < 0.1f) return String.format(Locale.US, "%.0f mm", m * 1000);
        if (m < 2f) return String.format(Locale.US, "%.2f m", m);
        return String.format(Locale.US, "%.1f m", m);
    }
}

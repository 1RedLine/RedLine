package com.redline.core;

/** Triangle mesh with per-vertex normals and a per-vertex scalar (used for heat gradients). */
public final class Mesh {
    public float[] p = new float[96], n = new float[96], h = new float[32];
    public int nv;
    public int[] t = new int[96];
    public int nt;
    /** Builder frame: everything added is transformed by this matrix. */
    public float[] f = M3.id();
    public float heat = 1f;
    private final float[] tmp = new float[3];

    public Mesh frame(float[] m) { f = m.clone(); return this; }

    public int vert(float x, float y, float z, float nx, float ny, float nz) {
        if (nv * 3 + 3 > p.length) {
            p = java.util.Arrays.copyOf(p, p.length * 2);
            n = java.util.Arrays.copyOf(n, n.length * 2);
            h = java.util.Arrays.copyOf(h, h.length * 2);
        }
        M3.apply(f, x, y, z, p, nv * 3);
        M3.applyDir(f, nx, ny, nz, tmp, 0);
        float l = (float) Math.sqrt(tmp[0] * tmp[0] + tmp[1] * tmp[1] + tmp[2] * tmp[2]);
        if (l < 1e-9f) l = 1;
        n[nv * 3] = tmp[0] / l; n[nv * 3 + 1] = tmp[1] / l; n[nv * 3 + 2] = tmp[2] / l;
        h[nv] = heat;
        return nv++;
    }

    public void tri(int a, int b, int c) {
        if (nt * 3 + 3 > t.length) t = java.util.Arrays.copyOf(t, t.length * 2);
        t[nt * 3] = a; t[nt * 3 + 1] = b; t[nt * 3 + 2] = c;
        nt++;
    }

    public void quad(int a, int b, int c, int d) { tri(a, b, c); tri(a, c, d); }

    /** Flat quad with explicit normal, CCW seen from the normal side. */
    void face(float[] a, float[] b, float[] c, float[] d, float nx, float ny, float nz) {
        int i0 = vert(a[0], a[1], a[2], nx, ny, nz);
        int i1 = vert(b[0], b[1], b[2], nx, ny, nz);
        int i2 = vert(c[0], c[1], c[2], nx, ny, nz);
        int i3 = vert(d[0], d[1], d[2], nx, ny, nz);
        quad(i0, i1, i2, i3);
    }

    public Mesh box(float x0, float y0, float z0, float x1, float y1, float z1) {
        float[] a = {x0, y0, z0}, b = {x1, y0, z0}, c = {x1, y1, z0}, d = {x0, y1, z0};
        float[] e = {x0, y0, z1}, g = {x1, y0, z1}, k = {x1, y1, z1}, l = {x0, y1, z1};
        face(e, g, k, l, 0, 0, 1);   // +z
        face(b, a, d, c, 0, 0, -1);  // -z
        face(g, b, c, k, 1, 0, 0);   // +x
        face(a, e, l, d, -1, 0, 0);  // -x
        face(l, k, c, d, 0, 1, 0);   // +y
        face(a, b, g, e, 0, -1, 0);  // -y
        return this;
    }

    /** Box centred on (cx,cy,cz) with half extents. */
    public Mesh boxC(float cx, float cy, float cz, float hx, float hy, float hz) {
        return box(cx - hx, cy - hy, cz - hz, cx + hx, cy + hy, cz + hz);
    }

    private static float[] basis(float ax, float ay, float az) {
        // returns u (3) and v (3) perpendicular to axis
        float ux, uy, uz;
        if (Math.abs(ax) < 0.9f) { ux = 0; uy = az; uz = -ay; } // axis x (1,0,0)
        else { ux = -az; uy = 0; uz = ax; }                     // axis x (0,1,0)
        float l = (float) Math.sqrt(ux * ux + uy * uy + uz * uz);
        ux /= l; uy /= l; uz /= l;
        float vx = ay * uz - az * uy, vy = az * ux - ax * uz, vz = ax * uy - ay * ux;
        return new float[]{ux, uy, uz, vx, vy, vz};
    }

    /** Truncated cone from c along unit axis a, radii r0 -> r1, length len. */
    public Mesh frustum(float cx, float cy, float cz, float ax, float ay, float az, float r0, float r1, float len, int seg, boolean cap0, boolean cap1) {
        float al = (float) Math.sqrt(ax * ax + ay * ay + az * az);
        ax /= al; ay /= al; az /= al;
        float[] b = basis(ax, ay, az);
        float slope = (r0 - r1) / len;
        int base = nv;
        for (int i = 0; i <= seg; i++) {
            double ang = 2 * Math.PI * i / seg;
            float co = (float) Math.cos(ang), si = (float) Math.sin(ang);
            float dx = b[0] * co + b[3] * si, dy = b[1] * co + b[4] * si, dz = b[2] * co + b[5] * si;
            float nx = dx + ax * slope, ny = dy + ay * slope, nz = dz + az * slope;
            vert(cx + dx * r0, cy + dy * r0, cz + dz * r0, nx, ny, nz);
            vert(cx + dx * r1 + ax * len, cy + dy * r1 + ay * len, cz + dz * r1 + az * len, nx, ny, nz);
        }
        for (int i = 0; i < seg; i++) {
            int a0 = base + i * 2, a1 = a0 + 1, b0 = a0 + 2, b1 = a0 + 3;
            quad(a0, b0, b1, a1);
        }
        if (cap0 && r0 > 0) capDisc(cx, cy, cz, -ax, -ay, -az, r0, seg, b, false);
        if (cap1 && r1 > 0) capDisc(cx + ax * len, cy + ay * len, cz + az * len, ax, ay, az, r1, seg, b, true);
        return this;
    }

    private void capDisc(float cx, float cy, float cz, float nx, float ny, float nz, float r, int seg, float[] b, boolean top) {
        int c = vert(cx, cy, cz, nx, ny, nz);
        int first = nv;
        for (int i = 0; i <= seg; i++) {
            double ang = 2 * Math.PI * i / seg;
            float co = (float) Math.cos(ang), si = (float) Math.sin(ang);
            float dx = b[0] * co + b[3] * si, dy = b[1] * co + b[4] * si, dz = b[2] * co + b[5] * si;
            vert(cx + dx * r, cy + dy * r, cz + dz * r, nx, ny, nz);
        }
        for (int i = 0; i < seg; i++) {
            if (top) tri(c, first + i, first + i + 1);
            else tri(c, first + i + 1, first + i);
        }
    }

    public Mesh cyl(float cx, float cy, float cz, float ax, float ay, float az, float r, float len, int seg) {
        return frustum(cx, cy, cz, ax, ay, az, r, r, len, seg, true, true);
    }

    public Mesh sphere(float cx, float cy, float cz, float r, int seg) {
        int rings = seg / 2;
        int base = nv;
        for (int i = 0; i <= rings; i++) {
            double th = Math.PI * i / rings;
            for (int j = 0; j <= seg; j++) {
                double ph = 2 * Math.PI * j / seg;
                float x = (float) (Math.sin(th) * Math.cos(ph)), y = (float) Math.cos(th), z = (float) (Math.sin(th) * Math.sin(ph));
                vert(cx + x * r, cy + y * r, cz + z * r, x, y, z);
            }
        }
        for (int i = 0; i < rings; i++)
            for (int j = 0; j < seg; j++) {
                int a = base + i * (seg + 1) + j, b = a + seg + 1;
                quad(a, a + 1, b + 1, b);
            }
        return this;
    }

    /**
     * Sweep a circle along a polyline. Heat goes from h0 at the start to h1 at the end.
     */
    public Mesh tube(float[] ptsIn, float[] radiiIn, int seg, float h0, float h1) {
        // drop consecutive duplicate points (zero-length segments break the frame)
        int n0 = ptsIn.length / 3;
        float[] pts = new float[ptsIn.length];
        float[] radii = new float[n0];
        int k0 = 0;
        for (int i = 0; i < n0; i++) {
            if (k0 > 0) {
                float dx = ptsIn[i * 3] - pts[(k0 - 1) * 3], dy = ptsIn[i * 3 + 1] - pts[(k0 - 1) * 3 + 1], dz = ptsIn[i * 3 + 2] - pts[(k0 - 1) * 3 + 2];
                if (dx * dx + dy * dy + dz * dz < 1e-12f) continue;
            }
            System.arraycopy(ptsIn, i * 3, pts, k0 * 3, 3);
            radii[k0] = radiiIn[Math.min(i, radiiIn.length - 1)];
            k0++;
        }
        pts = java.util.Arrays.copyOf(pts, k0 * 3);
        int np = k0;
        if (np < 2) return this;
        float[] len = new float[np];
        for (int i = 1; i < np; i++) {
            float dx = pts[i * 3] - pts[i * 3 - 3], dy = pts[i * 3 + 1] - pts[i * 3 - 2], dz = pts[i * 3 + 2] - pts[i * 3 - 1];
            len[i] = len[i - 1] + (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        }
        float total = Math.max(1e-6f, len[np - 1]);
        // initial frame
        float tx = pts[3] - pts[0], ty = pts[4] - pts[1], tz = pts[5] - pts[2];
        float tl = (float) Math.sqrt(tx * tx + ty * ty + tz * tz);
        tx /= tl; ty /= tl; tz /= tl;
        float[] b = basis(tx, ty, tz);
        float ux = b[0], uy = b[1], uz = b[2];
        int base = nv;
        for (int i = 0; i < np; i++) {
            // tangent: average of adjacent segments
            float ax, ay, az;
            if (i == 0) { ax = pts[3] - pts[0]; ay = pts[4] - pts[1]; az = pts[5] - pts[2]; }
            else if (i == np - 1) { ax = pts[i * 3] - pts[i * 3 - 3]; ay = pts[i * 3 + 1] - pts[i * 3 - 2]; az = pts[i * 3 + 2] - pts[i * 3 - 1]; }
            else { ax = pts[i * 3 + 3] - pts[i * 3 - 3]; ay = pts[i * 3 + 4] - pts[i * 3 - 2]; az = pts[i * 3 + 5] - pts[i * 3 - 1]; }
            float al = (float) Math.sqrt(ax * ax + ay * ay + az * az);
            ax /= al; ay /= al; az /= al;
            // parallel transport: remove tangent component from u
            float d = ux * ax + uy * ay + uz * az;
            ux -= d * ax; uy -= d * ay; uz -= d * az;
            float ul = (float) Math.sqrt(ux * ux + uy * uy + uz * uz);
            if (ul < 1e-6f) { float[] bb = basis(ax, ay, az); ux = bb[0]; uy = bb[1]; uz = bb[2]; }
            else { ux /= ul; uy /= ul; uz /= ul; }
            float vx = ay * uz - az * uy, vy = az * ux - ax * uz, vz = ax * uy - ay * ux;
            float r = radii[Math.min(i, radii.length - 1)];
            heat = h0 + (h1 - h0) * (len[i] / total);
            for (int j = 0; j <= seg; j++) {
                double ang = 2 * Math.PI * j / seg;
                float co = (float) Math.cos(ang), si = (float) Math.sin(ang);
                float dx = ux * co + vx * si, dy = uy * co + vy * si, dz = uz * co + vz * si;
                vert(pts[i * 3] + dx * r, pts[i * 3 + 1] + dy * r, pts[i * 3 + 2] + dz * r, dx, dy, dz);
            }
        }
        heat = 1f;
        for (int i = 0; i < np - 1; i++)
            for (int j = 0; j < seg; j++) {
                int a = base + i * (seg + 1) + j, c = a + seg + 1;
                quad(a, c, c + 1, a + 1);
            }
        return this;
    }

    /** Extrude a star-shaped 2D outline (in the plane spanned by u,v around centre) along axis a. */
    public Mesh prism(float cx, float cy, float cz, float[] uv, float ax, float ay, float az, float len) {
        float[] b = basis(ax, ay, az);
        int n = uv.length / 2;
        // sides
        for (int i = 0; i < n; i++) {
            int j = (i + 1) % n;
            float x0 = uv[i * 2], y0 = uv[i * 2 + 1], x1 = uv[j * 2], y1 = uv[j * 2 + 1];
            float ex = x1 - x0, ey = y1 - y0;
            float nx2 = ey, ny2 = -ex; // outward for CCW outline
            float wx = b[0] * nx2 + b[3] * ny2, wy = b[1] * nx2 + b[4] * ny2, wz = b[2] * nx2 + b[5] * ny2;
            float[] p0 = {cx + b[0] * x0 + b[3] * y0, cy + b[1] * x0 + b[4] * y0, cz + b[2] * x0 + b[5] * y0};
            float[] p1 = {cx + b[0] * x1 + b[3] * y1, cy + b[1] * x1 + b[4] * y1, cz + b[2] * x1 + b[5] * y1};
            float[] p2 = {p1[0] + ax * len, p1[1] + ay * len, p1[2] + az * len};
            float[] p3 = {p0[0] + ax * len, p0[1] + ay * len, p0[2] + az * len};
            face(p0, p1, p2, p3, wx, wy, wz);
        }
        // caps (fan)
        for (int cap = 0; cap < 2; cap++) {
            float off = cap == 0 ? 0 : len;
            float sgn = cap == 0 ? -1 : 1;
            int c = vert(cx + ax * off, cy + ay * off, cz + az * off, ax * sgn, ay * sgn, az * sgn);
            int first = nv;
            for (int i = 0; i < n; i++) {
                float x = uv[i * 2], y = uv[i * 2 + 1];
                vert(cx + b[0] * x + b[3] * y + ax * off, cy + b[1] * x + b[4] * y + ay * off, cz + b[2] * x + b[5] * y + az * off, ax * sgn, ay * sgn, az * sgn);
            }
            for (int i = 0; i < n; i++) {
                int j = (i + 1) % n;
                if (cap == 1) tri(c, first + i, first + j); else tri(c, first + j, first + i);
            }
        }
        return this;
    }

    public float[] bounds() {
        float[] b = {1e9f, 1e9f, 1e9f, -1e9f, -1e9f, -1e9f};
        for (int i = 0; i < nv; i++) {
            for (int k = 0; k < 3; k++) {
                float v = p[i * 3 + k];
                if (v < b[k]) b[k] = v;
                if (v > b[k + 3]) b[k + 3] = v;
            }
        }
        return b;
    }
}

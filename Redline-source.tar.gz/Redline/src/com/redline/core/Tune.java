package com.redline.core;

import java.util.Locale;

/** A tuning setup. All fields are small integers so builds serialise to a short string. */
public final class Tune {
    public int ecu;        // 0..3 (ECU remap / jetting stages)
    public int intake;     // 0..2
    public int exhaust;    // 0..2 (expansion chamber for 2-strokes)
    public int cams;       // 0..2 (porting for 2-strokes / rotaries)
    public int boost;      // turbo/SC: extra boost in 0.1 bar steps (0..20); NA: kit boost in 0.1 bar (0..15)
    public int kit;        // NA only: 0 none, 1 turbo kit, 2 supercharger kit
    public int intercooler;// 0/1
    public int fuel;       // 0 pump, 1 race fuel, 2 E85, 3 methanol
    public int nitrous;    // 0..4 -> 0, 15, 30, 50, 75 % of stock power
    public int bigBore;    // 0..3 -> +0, +10, +20, +40 % displacement
    public int revs;       // 0..4 -> +0..+20 % redline
    public int forged;     // 0/1
    public int weight;     // 0..4 -> -0..-20 %
    public int aero;       // 0 stock, 1 low drag, 2 downforce
    public int tires;      // 0 eco, 1 street, 2 sport, 3 semi-slick, 4 drag
    public int gearing;    // -3..+3 (negative = taller / longer)
    public int limiterOff; // 0/1

    public Tune() { tires = 1; }

    public static final String[] ECU = {"Stock", "Stage 1", "Stage 2", "Stage 3"};
    public static final String[] LVL = {"Stock", "Sport", "Race"};
    public static final String[] FUEL = {"Pump fuel", "Race fuel", "E85", "Methanol"};
    public static final String[] TIRES = {"Eco", "Street", "Sport", "Semi-slick", "Drag radial"};
    public static final String[] AERO = {"Stock", "Low-drag", "Downforce"};
    public static final String[] KIT = {"None", "Turbo kit", "Supercharger kit"};
    public static final int[] NOS = {0, 15, 30, 50, 75};
    public static final int[] BORE = {0, 10, 20, 40};

    public boolean isStock() {
        return ecu == 0 && intake == 0 && exhaust == 0 && cams == 0 && boost == 0 && kit == 0 && intercooler == 0
                && fuel == 0 && nitrous == 0 && bigBore == 0 && revs == 0 && forged == 0 && weight == 0 && aero == 0
                && tires == 1 && gearing == 0 && limiterOff == 0;
    }

    public Tune copy() {
        return decode(encode());
    }

    public String encode() {
        return String.format(Locale.US, "%d.%d.%d.%d.%d.%d.%d.%d.%d.%d.%d.%d.%d.%d.%d.%d.%d",
                ecu, intake, exhaust, cams, boost, kit, intercooler, fuel, nitrous, bigBore, revs, forged, weight, aero, tires, gearing, limiterOff);
    }

    public static Tune decode(String s) {
        Tune t = new Tune();
        if (s == null || s.isEmpty()) return t;
        String[] p = s.split("\\.");
        int[] v = new int[17];
        for (int i = 0; i < Math.min(p.length, 17); i++) {
            try { v[i] = Integer.parseInt(p[i]); } catch (Exception ignored) { }
        }
        t.ecu = v[0]; t.intake = v[1]; t.exhaust = v[2]; t.cams = v[3]; t.boost = v[4]; t.kit = v[5];
        t.intercooler = v[6]; t.fuel = v[7]; t.nitrous = v[8]; t.bigBore = v[9]; t.revs = v[10]; t.forged = v[11];
        t.weight = v[12]; t.aero = v[13]; t.tires = v[14]; t.gearing = v[15]; t.limiterOff = v[16];
        return t;
    }

    /** Redline after tuning. */
    public int redline(Engine e) {
        return Math.round(e.redline * (1f + revs * 0.05f));
    }

    public boolean boosted(Engine e) {
        return e.turbos > 0 || e.sc || kit > 0;
    }

    /** 0..100+, how hard the engine is being pushed. */
    public float stress(Engine e, Curve stock, Curve tuned) {
        float gain = tuned.peakKw / Math.max(0.001f, stock.peakKw) - 1f;
        float cap = forged == 1 ? 1.6f : 0.65f;
        if (e.diesel()) cap *= 1.15f;
        if (e.est && e.hp() > 2000) cap *= 1.2f;
        float s = gain / cap * 100f;
        s += revs * (forged == 1 ? 3f : 8f);
        s += nitrous * 6f;
        if (fuel >= 2 && boosted(e)) s -= 8f;
        if (intercooler == 1 && boosted(e)) s -= 5f;
        return Math.max(0f, s);
    }

    public static String stressLabel(float s) {
        if (s < 15) return "Factory-safe";
        if (s < 40) return "Mild";
        if (s < 70) return "Spicy";
        if (s < 100) return "Risky";
        return "Grenade";
    }
}

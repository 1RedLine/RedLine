package com.redline.core;

import java.util.Locale;

/** Power and torque curve chart. */
public final class DynoChart {
    private DynoChart() { }

    public static void draw(Gfx g, float x, float y, float w, float h, Curve[] curves, int[] colors, String[] names, float s, float markRpm) {
        g.fillRound(x, y, w, h, s * 0.5f, Theme.PANEL);
        float padL = s * 3.2f, padR = s * 3.2f, padT = s * 1.6f, padB = s * 2.2f;
        float cx = x + padL, cy = y + padT, cw = w - padL - padR, ch = h - padT - padB;
        float maxR = 0, maxP = 0, maxT = 0;
        for (Curve c : curves) {
            if (c == null) continue;
            maxR = Math.max(maxR, c.redline);
            maxP = Math.max(maxP, Units.powerVal(c.peakKw));
            maxT = Math.max(maxT, Units.torqueVal(c.peakNm));
        }
        if (maxR <= 0) return;
        maxR = niceCeil(maxR);
        maxP = niceCeil(maxP * 1.08f);
        maxT = niceCeil(maxT * 1.08f);
        // grid
        for (int i = 0; i <= 4; i++) {
            float gy = cy + ch * i / 4f;
            g.line(cx, gy, cx + cw, gy, 1f, Theme.LINE);
            g.text(fmt(maxP * (4 - i) / 4f), cx - s * 0.4f, gy + s * 0.3f, s * 0.62f, Theme.DIM, Gfx.RIGHT, 0);
            g.text(fmt(maxT * (4 - i) / 4f), cx + cw + s * 0.4f, gy + s * 0.3f, s * 0.62f, Theme.DIM, Gfx.LEFT, 0);
        }
        int steps = 5;
        for (int i = 0; i <= steps; i++) {
            float gx = cx + cw * i / steps;
            g.line(gx, cy, gx, cy + ch, 1f, Theme.alpha(Theme.LINE, 0.6f));
            float r = maxR * i / steps;
            g.text(r >= 10000 ? String.format(Locale.US, "%.0fk", r / 1000f) : (r >= 1000 ? String.format(Locale.US, "%.1fk", r / 1000f) : String.format(Locale.US, "%.0f", r)), gx, cy + ch + s * 1.0f, s * 0.62f, Theme.DIM, Gfx.CENTER, 0);
        }
        g.text(Units.powerUnit(), cx - s * 0.4f, y + s * 1.0f, s * 0.62f, Theme.TEXT, Gfx.RIGHT, Gfx.BOLD);
        g.text(Units.torqueUnit(), cx + cw + s * 0.4f, y + s * 1.0f, s * 0.62f, Theme.TEXT, Gfx.LEFT, Gfx.BOLD);
        g.text("rpm", cx + cw, cy + ch + s * 1.9f, s * 0.6f, Theme.DIM, Gfx.RIGHT, 0);
        for (int k = 0; k < curves.length; k++) {
            Curve c = curves[k];
            if (c == null) continue;
            int col = colors[k];
            int n = 80;
            float[] pp = new float[n * 2], tp = new float[n * 2];
            int m = 0;
            float r0 = Math.max(c.redline * 0.05f, 1);
            for (int i = 0; i < n; i++) {
                float r = r0 + (c.redline - r0) * i / (n - 1);
                float px = cx + cw * r / maxR;
                pp[m * 2] = px; pp[m * 2 + 1] = cy + ch * (1 - Units.powerVal(c.kw(r)) / maxP);
                tp[m * 2] = px; tp[m * 2 + 1] = cy + ch * (1 - Units.torqueVal(c.torque(r)) / maxT);
                m++;
            }
            g.polyline(pp, m, s * 0.2f, col);
            // dashed torque
            for (int i = 0; i < m - 1; i += 2) g.line(tp[i * 2], tp[i * 2 + 1], tp[i * 2 + 2], tp[i * 2 + 3], s * 0.14f, Theme.alpha(col, 0.85f));
            float ppx = cx + cw * c.rpmPeakKw / maxR, ppy = cy + ch * (1 - Units.powerVal(c.peakKw) / maxP);
            g.circle(ppx, ppy, s * 0.28f, col);
            if (names != null && names.length > k && names[k] != null) {
                g.fillRect(x + padL + k * w * 0.34f, y + h - s * 0.75f, s * 0.8f, s * 0.22f, col);
                g.text(names[k], x + padL + k * w * 0.34f + s, y + h - s * 0.45f, s * 0.6f, Theme.TEXT, Gfx.LEFT, 0);
            }
        }
        if (markRpm > 0 && markRpm <= maxR) {
            float mx = cx + cw * markRpm / maxR;
            g.line(mx, cy, mx, cy + ch, s * 0.1f, Theme.alpha(Theme.TEXT, 0.6f));
        }
    }

    static float niceCeil(float v) {
        if (v <= 0) return 1;
        double e = Math.pow(10, Math.floor(Math.log10(v)));
        double m = v / e;
        double n = m <= 1 ? 1 : m <= 2 ? 2 : m <= 2.5 ? 2.5 : m <= 5 ? 5 : 10;
        return (float) (n * e);
    }

    static String fmt(float v) {
        if (v >= 100000) return String.format(Locale.US, "%.0fk", v / 1000f);
        if (v >= 10000) return String.format(Locale.US, "%.1fk", v / 1000f);
        if (v >= 10) return String.format(Locale.US, "%.0f", v);
        return String.format(Locale.US, "%.1f", v);
    }
}

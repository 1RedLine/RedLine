package com.redline.core;

import java.util.ArrayList;
import java.util.Locale;

public final class Engine {
    public int idx;
    public String id, make, name, code, years, note = "";
    /** I, V, VR, W, B (broad arrow), F (flat), IV (inverted V), R (Wankel), RAD (radial) */
    public String layout;
    public int cyl;          // cylinders (rotors for Wankel)
    public float bank;      // V angle in degrees
    public int rows = 1;    // radial rows
    public float cc;
    public int turbos;      // number of turbochargers
    public boolean sc;      // supercharged
    public boolean hybrid;
    public float kw, nm;
    public int rpmP, rpmT, redline, idle;
    public float bore, stroke;
    public boolean boreKnown;
    public int valves = 4;
    public String vt = "DOHC";
    public int strokes = 4;
    public boolean air, oilCooled, hotV, drySump, est, claimed, flatPlane, nmEst;
    public char fuel = 'P';
    public float engineKg;
    public int year;
    public String cats = "";
    public final ArrayList<Vehicle> vehicles = new ArrayList<>();
    // researched visual profile
    public String intake = "";   // itb, plen, carb, carb4, carb2x4, webers, box, long, updraft, hat
    public int nthr, ncarb;       // throttle bodies / carburettors when grouped
    public String tp = "";       // turbo placement: side, hv, rear, top, front
    public String ic = "";       // intercooler: front, top, side, none
    public String scx = "";      // supercharger type: roots, screw, tvs, cent, gear
    public boolean timingRear, gbxSump, seqTurbo;
    public String ex = "";       // exhaust: merge, stubs, top, zoomie
    public String fan = "";      // shroud, front
    public int cov, blk;          // cam-cover / block colour (0 = default)
    public float tilt;            // whole-engine lean (deg)
    public String look = "";     // short researched visual note

    public float hp() { return kw / 0.745699872f; }
    public float liters() { return cc / 1000f; }
    public boolean turbo() { return turbos > 0; }
    public boolean twoStroke() { return strokes == 2; }
    public boolean wankel() { return layout.equals("R"); }
    public boolean radial() { return layout.equals("RAD"); }
    public boolean diesel() { return fuel == 'D'; }
    public boolean has(String cat) { return (" " + cats + " ").contains(" " + cat + " "); }
    public float hpPerLiter() { return hp() / Math.max(0.001f, liters()); }

    public String layoutName() {
        switch (layout) {
            case "I": return cyl == 1 ? "Single" : (cyl == 2 ? "Parallel-twin" : "Inline-" + cyl);
            case "V": return cyl == 2 ? Math.round(bank) + "° V-twin" : "V" + cyl + " " + Math.round(bank) + "°";
            case "VR": return "VR" + cyl + " " + Math.round(bank) + "°";
            case "W": return "W" + cyl;
            case "B": return "W" + cyl + " broad-arrow";
            case "F": return cyl == 2 ? "Flat-twin (boxer)" : "Flat-" + cyl;
            case "IV": return "Inverted V" + cyl;
            case "R": return cyl + "-rotor Wankel";
            case "RAD": return cyl + "-cyl radial" + (rows > 1 ? " (" + rows + " rows)" : "");
        }
        return layout + cyl;
    }

    public String shortLayout() {
        switch (layout) {
            case "I": return cyl == 1 ? "1-cyl" : (cyl == 2 ? "P-twin" : "I" + cyl);
            case "V": return cyl == 2 ? "V-twin" : "V" + cyl;
            case "VR": return "VR" + cyl;
            case "W": case "B": return "W" + cyl;
            case "F": return cyl == 2 ? "Boxer-2" : "F" + cyl;
            case "IV": return "Inv-V" + cyl;
            case "R": return cyl + "-rotor";
            case "RAD": return "Radial-" + cyl;
        }
        return layout;
    }

    public String aspName() {
        StringBuilder b = new StringBuilder();
        if (turbos == 1) b.append("Turbo");
        else if (turbos == 2) b.append("Twin-turbo");
        else if (turbos == 3) b.append("Triple-turbo");
        else if (turbos == 4) b.append("Quad-turbo");
        else if (turbos > 4) b.append(turbos).append(" turbos");
        if (sc) b.append(b.length() > 0 ? " + supercharger" : "Supercharged");
        if (b.length() == 0) b.append("Naturally aspirated");
        if (hybrid) b.append(" · hybrid");
        return b.toString();
    }

    public String fuelName() {
        switch (fuel) {
            case 'D': return "Diesel";
            case 'M': return "Methanol";
            case 'N': return "Nitromethane";
            case 'G': return "Glow fuel";
            case 'E': return "E85";
            case 'X': return "2-stroke mix";
            case 'A': return "Avgas";
            case 'H': return "Heavy fuel oil";
        }
        return strokes == 2 ? "Petrol/oil mix" : "Petrol";
    }

    public String vtName() {
        switch (vt) {
            case "OHV": return "OHV pushrod";
            case "SOHC": return "SOHC";
            case "DOHC": return "DOHC";
            case "DESMO": return "Desmodromic DOHC";
            case "SV": return "Side-valve";
            case "PORT": return "Piston-ported";
            case "FREE": return "Freevalve (camless)";
            case "IOE": return "Inlet-over-exhaust";
            case "UNI": return "Uniflow (exhaust valve)";
        }
        return vt;
    }

    public float meanPistonSpeed() { return 2f * stroke / 1000f * redline / 60f; }

    public String title() { return make + " " + name; }

    public static String fmt(float v, int dec) {
        return String.format(Locale.US, "%." + dec + "f", v);
    }
}

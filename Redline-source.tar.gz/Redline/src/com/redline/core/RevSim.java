package com.redline.core;

import java.util.Random;

/** Real-time engine rev simulation: inertia, throttle lag, turbo spool, limiters, temperatures, dyno sweep. */
public final class RevSim {
    public final Engine e;
    public final Curve curve;
    public float rpm, throttleIn, throttle, boost, maxBoost;
    public float water = 82, oil = 86, egt = 320, health = 100;
    public boolean running, cranking, cut;
    public int mode;        // 0 free rev, 1 dyno
    public int limiter;     // 0 hard cut, 1 soft cut, 2 launch control, 3 anti-lag
    public float launchRpm;
    public float torqueNow, kwNow;
    public final float[] hist = new float[240];
    public int histPos;
    private float histT;
    // dyno
    public boolean dynoRunning, dynoDone;
    public float dynoRpm;
    public final float[] dynoR = new float[400], dynoKw = new float[400], dynoNm = new float[400];
    public int dynoN;
    public float dynoPeakKw, dynoPeakRpm, dynoPeakNm, dynoPeakNmRpm;
    // effects
    public float flame, shake, vibe, limiterTime;
    public int pops;
    public boolean popEvent, limiterEvent;
    private float crankT, prevThrottle, inertia, tauThrottle, tauBoost;
    private final Random rnd = new Random();
    public final int red;

    public RevSim(Engine e, Curve curve, int redline) {
        this.e = e;
        this.curve = curve;
        this.red = redline;
        rpm = 0;
        maxBoost = e.turbos > 0 ? (e.diesel() ? 2.0f : 1.2f) : (e.sc ? 0.8f : 0f);
        launchRpm = Math.max(e.idle * 2f, Math.min(redline * 0.55f, curve.rpmPeakNm * 0.9f));
        float L = Math.max(0.001f, e.cc / 1000f);
        float tRev = 0.35f * (float) Math.pow(L, 0.35) * (float) Math.sqrt(7000f / Math.max(300, redline));
        if (e.twoStroke() && e.cc < 1000) tRev *= 0.8f;
        tRev = Math.max(0.12f, Math.min(25f, tRev));
        float dOmega = (redline - e.idle) * 2f * (float) Math.PI / 60f;
        inertia = 0.62f * curve.peakNm / Math.max(1e-3f, dOmega / tRev);
        tauThrottle = redline > 9000 ? 0.035f : (e.diesel() ? 0.12f : 0.07f);
        if (redline < 1000) tauThrottle = 1.2f;
        float perTurbo = e.turbos > 0 ? e.cc / e.turbos : 0;
        tauBoost = e.seqTurbo ? 0.35f : (perTurbo > 2500 ? 0.85f : 0.55f);
        if (redline < 1000) tauBoost = 6f;
    }

    public void start() {
        if (running || cranking) return;
        cranking = true;
        crankT = 0;
    }

    public void stop() { running = false; cranking = false; dynoRunning = false; }

    public void startDyno() {
        if (!running) return;
        mode = 1;
        dynoRunning = true;
        dynoDone = false;
        dynoN = 0;
        dynoPeakKw = 0; dynoPeakNm = 0;
        dynoRpm = Math.max(e.idle * 1.5f, red * 0.22f);
    }

    public float torqueAt(float r, float thr, float bst) {
        float base = curve.torque(Math.max(r, 1));
        if (maxBoost > 0 && e.turbos > 0) {
            float naShare = 1f / (1f + maxBoost * 0.85f);
            base *= naShare + (1f - naShare) * Math.max(0f, Math.min(1.1f, bst / maxBoost));
        }
        float f = (float) Math.pow(Math.max(0f, thr), 0.6);
        return base * f;
    }

    public void step(float dt) {
        dt = Math.min(dt, 0.05f);
        popEvent = false;
        limiterEvent = false;
        // throttle lag + idle control
        float target = dynoRunning ? 1f : throttleIn;
        if (running && throttleIn < 0.03f && rpm < e.idle * 1.08f && !dynoRunning) {
            target = Math.max(target, Math.min(0.35f, (e.idle - rpm) / e.idle * 2.5f + 0.04f));
        }
        throttle += (target - throttle) * Math.min(1f, dt / tauThrottle);
        // flames on sharp lift-off at high rpm
        if (running && prevThrottle - throttleIn > 0.5f && rpm > red * 0.5f && !e.diesel()) {
            flame = 1f; pops += 1 + rnd.nextInt(3); popEvent = true;
        }
        prevThrottle = throttleIn;
        // boost
        if (maxBoost > 0) {
            float spool = e.turbos > 0 ? smooth(red * 0.2f, red * 0.5f, rpm) : (0.35f + 0.65f * rpm / red);
            float loadK = (mode == 1 && dynoRunning) ? 1f : 0.55f;
            float bt = maxBoost * throttle * spool * loadK;
            if (limiter == 3 && running && throttleIn < 0.1f && rpm > red * 0.3f && e.turbos > 0) {
                bt = maxBoost * 0.7f;
                if (rnd.nextFloat() < dt * 9f) { flame = Math.max(flame, 0.7f); pops++; popEvent = true; }
            }
            if (!running) bt = 0;
            if (!e.sc || e.turbos > 0) {
                float tau = bt > boost ? tauBoost * (1.4f - 0.8f * Math.min(1f, rpm / red)) : 0.35f;
                boost += (bt - boost) * Math.min(1f, dt / tau);
            } else boost += (bt - boost) * Math.min(1f, dt / 0.05f);
            if (!running && boost < 0) boost = 0;
        }
        float omega = rpm * 2f * (float) Math.PI / 60f;
        float tFric = curve.peakNm * (0.05f + 0.08f * (rpm / red) * (rpm / red)) + curve.peakNm * 0.06f * (1 - throttle);
        if (rpm < 5) tFric = 0;
        float tComb = 0;
        if (cranking) {
            crankT += dt;
            float crankRpm = Math.min(260f, e.idle * 0.3f) * (1f + 0.15f * (float) Math.sin(crankT * 40));
            rpm += (crankRpm - rpm) * Math.min(1f, dt * 8f);
            if (crankT > 0.85f) { cranking = false; running = true; rpm = Math.max(rpm, e.idle * 1.3f); }
        } else if (running) {
            float lim = red;
            boolean launch = limiter == 2 && throttleIn > 0.85f && mode == 0;
            if (launch) lim = launchRpm;
            tComb = torqueAt(rpm, throttle, boost);
            if (limiter == 1 && !launch) {
                float k = Math.max(0f, Math.min(1f, (lim + 60f - rpm) / 260f));
                tComb *= k;
                if (k < 0.6f && rnd.nextFloat() < dt * 6f) { flame = Math.max(flame, 0.45f); popEvent = true; pops++; }
            } else {
                if (rpm >= lim) { if (!cut) { limiterEvent = true; } cut = true; }
                if (cut && rpm < lim - (launch ? 260f : 160f)) cut = false;
                if (cut) {
                    tComb = 0;
                    if (rnd.nextFloat() < dt * (launch ? 14f : 7f)) { flame = Math.max(flame, launch ? 0.8f : 0.5f); popEvent = true; pops++; }
                }
            }
            if (cut || (limiter == 1 && rpm > lim - 100)) limiterTime += dt; else limiterTime = Math.max(0, limiterTime - dt * 2);
        }
        if (dynoRunning) {
            {
                float sweep = (red - e.idle) / (red < 1000 ? 40f : 7f);
                dynoRpm += sweep * dt;
                rpm = dynoRpm;
                float t = torqueAt(rpm, 1f, boost);
                float kw = t * rpm / 9549.3f;
                if (dynoN < dynoR.length) { dynoR[dynoN] = rpm; dynoKw[dynoN] = kw; dynoNm[dynoN] = t; dynoN++; }
                if (kw > dynoPeakKw) { dynoPeakKw = kw; dynoPeakRpm = rpm; }
                if (t > dynoPeakNm) { dynoPeakNm = t; dynoPeakNmRpm = rpm; }
                if (dynoRpm >= red) { dynoRunning = false; dynoDone = true; mode = 0; }
                torqueNow = t; kwNow = kw;
            }
        } else if (!cranking) {
            float net = tComb - tFric;
            omega += net / inertia * dt;
            if (omega < 0) omega = 0;
            rpm = omega * 60f / (2f * (float) Math.PI);
            if (!running && rpm < 30) rpm = Math.max(0, rpm - 400 * dt);
            torqueNow = tComb;
            kwNow = tComb * rpm / 9549.3f;
        }
        // temperatures
        float loadFrac = running ? throttle * (rpm / red) : 0;
        float wT = 85f + 22f * loadFrac + limiterTime * 1.5f;
        water += (wT - water) * Math.min(1f, dt * 0.15f);
        float oT = water + 6f + 28f * (rpm / red) * (rpm / red) + limiterTime * 2.2f;
        oil += (oT - oil) * Math.min(1f, dt * 0.08f);
        float eT = running ? 330f + 640f * throttle * (0.3f + 0.7f * rpm / red) + (limiter == 3 && throttleIn < 0.1f ? 180f : 0) + (cut ? 90 : 0) : 60f;
        if (e.diesel()) eT *= 0.85f;
        egt += (eT - egt) * Math.min(1f, dt * 1.5f);
        if (oil > 132f || limiterTime > 4f) health = Math.max(0f, health - dt * (oil > 140 ? 6f : 1.5f));
        flame = Math.max(0f, flame - dt * 3.2f);
        shake = (cut ? 0.6f : 0f) + (rpm / red) * 0.18f * throttle + flame * 0.3f;
        vibe = running ? (cut ? 1f : 0.12f + 0.55f * (rpm / red) * (rpm / red) * (0.4f + throttle)) : 0f;
        // history
        histT += dt;
        while (histT >= 0.025f) {
            histT -= 0.025f;
            hist[histPos] = rpm;
            histPos = (histPos + 1) % hist.length;
        }
    }

    static float smooth(float a, float b, float x) {
        if (x <= a) return 0;
        if (x >= b) return 1;
        float t = (x - a) / (b - a);
        return t * t * (3 - 2 * t);
    }
}

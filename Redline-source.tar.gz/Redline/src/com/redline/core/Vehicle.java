package com.redline.core;

public final class Vehicle {
    public Engine engine;
    public String name, years, type, drive;
    public int count = 1;          // engines fitted
    public float kg;               // curb mass
    public float top;              // documented top speed km/h, 0 = unknown
    public char topFlag = ' ';     // L limited, C claimed, T target, R record, ' ' documented
    public float kwOverride;       // vehicle-specific engine output, 0 = engine default

    public float kw() { return kwOverride > 0 ? kwOverride : engine.kw; }

    public boolean road() {
        switch (type) {
            case "plane": case "ship": case "boat": case "tool": case "model": return false;
        }
        return true;
    }

    public boolean hasTopSim() { return !type.equals("tool") && !type.equals("model"); }

    public String typeName() {
        switch (type) {
            case "car": return "Car";
            case "bike": return "Motorcycle";
            case "scooter": return "Scooter";
            case "moped": return "Moped";
            case "truck": return "Truck";
            case "haul": return "Mining truck";
            case "train": return "Locomotive";
            case "bus": return "Bus";
            case "plane": return "Aircraft";
            case "ship": return "Ship";
            case "boat": return "Boat";
            case "kart": return "Kart";
            case "lsr": return "Land-speed car";
            case "race": return "Race car";
            case "drag": return "Dragster";
            case "tool": return "Power tool";
            case "model": return "Model aircraft";
            case "rally": return "Rally car";
        }
        return type;
    }

    public String topText(boolean mph) {
        if (top <= 0) return "—";
        String s = mph ? Math.round(top / 1.609344f) + " mph" : Math.round(top) + " km/h";
        switch (topFlag) {
            case 'L': return s + " (limited)";
            case 'C': return s + " (claimed)";
            case 'T': return s + " (target)";
            case 'R': return s + " (record)";
        }
        return s;
    }

    public boolean bikeLike() {
        return type.equals("bike") || type.equals("scooter") || type.equals("moped");
    }
}

package com.redline.core;

import java.util.ArrayList;

/** Procedural, animated 3D engine built from an Engine's real layout, bore, stroke, valvetrain and induction. */
public final class EngineModel {
    public final Engine e;
    public final ArrayList<Part> parts = new ArrayList<>();
    public float B, S, R, L, CH, D, P, headH, halfW;
    public int n, cycle;
    public float[] cylX, cylBeta, cylPhase;
    public int[] cylBank;
    public float[] bankBeta;
    public int[] bankSide;           // intake side sign per bank (local z)
    public float radius;
    public final float[] center = new float[3];
    public float xMin, xMax, yMin, yMax;
    public float theta;             // crank angle (degrees, continuous)
    public float rpm, load;
    public boolean wankel, radial, twoStroke, airCooled;

    // dynamic refs
    Part[] pistons, rods, charges;
    final ArrayList<Part> spinners = new ArrayList<>(); // rotate with crank about X (crank, flywheel, pulleys)
    final ArrayList<Valve> valves = new ArrayList<>();
    final ArrayList<Cam> cams = new ArrayList<>();
    final ArrayList<Part> turboWheels = new ArrayList<>();
    final ArrayList<float[]> turboWheelPivot = new ArrayList<>();
    Part[] rotors;
    public Part figure;

    // particles
    public final ArrayList<Flow> flows = new ArrayList<>();
    public float[] px = new float[0], py = new float[0], pz = new float[0];
    public int[] pc = new int[0];
    public float[] ps = new float[0];
    public int[] pt = new int[0];
    public int np;
    public final ArrayList<float[]> sparks = new ArrayList<>(); // x,y,z,intensity

    public static final int F_AIR = 0, F_BOOST = 1, F_EXH = 2, F_OIL = 3, F_COOL = 4, F_FUEL = 5, F_COOLAIR = 6, F_MIX = 7;
    public static final int[] FLOW_COLOR = {0xFF7FD4FF, 0xFF4FA6FF, 0xFFFF8A3D, 0xFFFFB020, 0xFF2FE6B0, 0xFFFFE14D, 0xFFBFE8FF, 0xFF9DB7FF};
    public static final String[] FLOW_NAME = {"Intake air", "Boosted air", "Exhaust", "Oil", "Coolant", "Fuel", "Cooling air", "Fresh charge"};

    static final class Valve {
        Part p; int cyl; boolean intake; float[] axis; float maxLift; float[] base; Part pushrod; float[] pushBase; float[] pushAxis;
    }

    static final class Cam {
        Part p; float[] base; // bank frame * translate(axis)
    }

    public static final class Flow {
        public float[] pts; float[] cum; float total;
        public int type; int cyl = -1; int gate; // 0 always, 1 intake valve, 2 exhaust valve, 3 two-stroke transfer, 4 two-stroke exhaust port, 5 crankcase intake
        float[] s; float speed = 1f; float size = 1f;
    }

    // ------------------------------------------------------------------ build

    public EngineModel(Engine e) {
        this.e = e;
        wankel = e.wankel();
        radial = e.radial();
        twoStroke = e.twoStroke();
        airCooled = e.air;
        if (wankel) buildWankel();
        else buildPiston();
        buildFigure();
        finishBounds();
        update(0, e.idle, 0.2f, 0);
    }

    private Part add(String key, int kind, int color, Mesh m) {
        Part p = new Part(parts.size(), key, kind, color, m);
        parts.add(p);
        return p;
    }

    private static Mesh mesh(float[] frame) { return new Mesh().frame(frame); }

    int accentColor() {
        String mk = e.make.toLowerCase();
        if (mk.contains("ferrari") || mk.contains("alfa") || mk.contains("maserati") || mk.contains("honda") || mk.contains("ducati") || mk.contains("lancia")) return 0xFFC21F2E;
        if (mk.contains("lamborghini") || mk.contains("koenigsegg") || mk.contains("amg") || mk.contains("pagani")) return 0xFF2A2D33;
        if (mk.contains("porsche") || mk.contains("mercedes") || mk.contains("bugatti") || mk.contains("rolls")) return 0xFFB6BBC2;
        if (mk.contains("bmw")) return 0xFF3E5A87;
        if (mk.contains("chevrolet") || mk.contains("cadillac")) return 0xFFD2A23A;
        if (mk.contains("kawasaki")) return 0xFF3E9C35;
        if (mk.contains("yamaha")) return 0xFF2856A8;
        if (mk.contains("ford") || mk.contains("cosworth")) return 0xFF29467A;
        return 0xFF3B4047;
    }

    private void buildPiston() {
        n = e.cyl;
        B = e.bore / 1000f;
        S = e.stroke / 1000f;
        R = S / 2f;
        boolean marine = twoStroke && e.cc > 1e6f;
        L = S * (marine ? 3.0f : (twoStroke ? 1.95f : 1.75f));
        CH = B * 0.42f;
        D = R + L + CH + B * 0.03f;
        P = B * (airCooled ? 1.45f : 1.22f) + (marine ? B * 0.45f : 0f);
        cycle = twoStroke ? 360 : 720;
        cylX = new float[n];
        cylBeta = new float[n];
        cylPhase = new float[n];
        cylBank = new int[n];
        String lay = e.layout;
        float V = e.bank;
        float offs = B * 0.34f;
        int nb;
        if (lay.equals("I")) {
            nb = 1; bankBeta = new float[]{0};
            for (int i = 0; i < n; i++) { cylX[i] = i * P; cylBeta[i] = 0; cylBank[i] = 0; }
        } else if (lay.equals("V") || lay.equals("IV") || lay.equals("F")) {
            nb = 2;
            float base = lay.equals("IV") ? 180f : 0f;
            float half = lay.equals("F") ? 90f : V / 2f;
            bankBeta = new float[]{base - half, base + half};
            int h = n / 2;
            if (n == 2 && lay.equals("V")) offs = B * 0.36f;
            for (int i = 0; i < n; i++) {
                int b = i < h ? 0 : 1;
                int j = i < h ? i : i - h;
                cylX[i] = j * P + (b == 1 ? offs : 0);
                cylBeta[i] = bankBeta[b];
                cylBank[i] = b;
            }
        } else if (lay.equals("VR")) {
            nb = 1; bankBeta = new float[]{0};
            for (int i = 0; i < n; i++) {
                cylX[i] = i * P * 0.6f;
                cylBeta[i] = (i % 2 == 0 ? -V / 2f : V / 2f);
                cylBank[i] = 0;
            }
        } else if (lay.equals("W")) {
            nb = 2; bankBeta = new float[]{-V / 2f, V / 2f};
            int h = n / 2;
            for (int i = 0; i < n; i++) {
                int b = i < h ? 0 : 1;
                int j = i < h ? i : i - h;
                cylX[i] = j * P * 0.6f + (b == 1 ? offs : 0);
                cylBeta[i] = bankBeta[b] + (j % 2 == 0 ? -7.5f : 7.5f);
                cylBank[i] = b;
            }
        } else if (lay.equals("B")) {
            nb = 3; bankBeta = new float[]{-60, 0, 60};
            int t = n / 3;
            for (int i = 0; i < n; i++) {
                int b = i / t, j = i % t;
                cylX[i] = j * P + b * B * 0.22f;
                cylBeta[i] = bankBeta[b];
                cylBank[i] = b;
            }
        } else { // RAD
            int rows = Math.max(1, e.rows);
            int m = n / rows;
            nb = n; // each cylinder its own "bank"
            bankBeta = new float[n];
            for (int i = 0; i < n; i++) {
                int r = i / m, k = i % m;
                cylBeta[i] = 360f * k / m + (rows > 1 ? r * 180f / m : 0f);
                cylX[i] = -r * B * 2.1f;
                cylBank[i] = i;
                bankBeta[i] = cylBeta[i];
            }
        }
        if (e.tilt != 0 && !radial) {
            for (int i = 0; i < n; i++) cylBeta[i] += e.tilt;
            for (int b = 0; b < nb; b++) bankBeta[b] += e.tilt;
        }
        bankSide = new int[nb];
        for (int b = 0; b < nb; b++) bankSide[b] = intakeSide(bankBeta[b] - e.tilt);
        assignPhases();

        xMin = 1e9f; xMax = -1e9f;
        for (int i = 0; i < n; i++) { xMin = Math.min(xMin, cylX[i]); xMax = Math.max(xMax, cylX[i]); }

        boolean dohc = e.vt.equals("DOHC") || e.vt.equals("DESMO") || e.vt.equals("FREE");
        boolean sohc = e.vt.equals("SOHC") || e.vt.equals("IOE");
        boolean ohv = e.vt.equals("OHV");
        boolean ported = e.vt.equals("PORT");
        headH = ported ? B * 0.38f : (dohc ? B * 0.95f : (sohc ? B * 0.75f : B * 0.55f));
        if (e.vt.equals("UNI")) headH = B * 0.8f;
        halfW = B * 0.64f;
        if (lay.equals("VR") || lay.equals("W")) halfW += D * (float) Math.sin(Math.toRadians(7.5)) ;

        int blockCol = e.blk != 0 ? e.blk : ((e.diesel() || ohv || e.year < 1960) ? 0xFF5F6369 : 0xFF8C939C);
        int headCol = (e.year < 1960 && !radial) ? 0xFF6A6E74 : 0xFF9BA2AB;
        int accent = e.cov != 0 ? e.cov : accentColor();

        // ---------------- per-bank structure
        for (int b = 0; b < nb; b++) {
            float beta = bankBeta[b];
            float[] F = M3.rotX(beta);
            float[] eAxis = new float[3];
            M3.applyDir(F, 0, 0, 1, eAxis, 0);
            float bx0 = 1e9f, bx1 = -1e9f;
            for (int i = 0; i < n; i++) if (cylBank[i] == b) { bx0 = Math.min(bx0, cylX[i]); bx1 = Math.max(bx1, cylX[i]); }
            float x0 = bx0 - P * 0.55f, x1 = bx1 + P * 0.55f;
            if (radial) { x0 = bx0 - B * 0.62f; x1 = bx0 + B * 0.62f; }
            float yb = R + B * 0.25f;
            if (airCooled || radial) {
                for (int i = 0; i < n; i++) if (cylBank[i] == b) buildAirBarrel(i, F);
            } else {
                for (int s = -1; s <= 1; s += 2) {
                    Mesh m = mesh(F);
                    m.box(x0, yb, s < 0 ? -halfW : 0, x1, D, s < 0 ? 0 : halfW);
                    Part p = add("block", Part.SHELL, blockCol, m);
                    p.bank = b; p.half = s; p.cutAxis = eAxis; p.heat = 0.55f;
                }
            }
            // head
            if (!radial) {
                float hz = airCooled ? halfW + B * 0.12f : halfW;
                for (int s = -1; s <= 1; s += 2) {
                    Mesh m = mesh(F);
                    m.box(x0, D, s < 0 ? -hz : 0, x1, D + headH, s < 0 ? 0 : hz);
                    Part p = add("head", Part.SHELL, headCol, m);
                    p.bank = b; p.half = s; p.cutAxis = eAxis; p.heat = 0.7f;
                    float[] ex = new float[3];
                    M3.applyDir(F, 0, B * 2.6f, 0, ex, 0);
                    p.explode = ex;
                }
                if (!e.vt.equals("PORT")) {
                    Mesh m = mesh(F);
                    m.box(x0 + B * 0.06f, D + headH, -hz * 0.86f, x1 - B * 0.06f, D + headH + B * 0.2f, hz * 0.86f);
                    Part p = add("camcover", Part.SHELL, accent, m);
                    p.bank = b; p.half = 2; p.heat = 0.5f;
                    float[] ex = new float[3];
                    M3.applyDir(F, 0, B * 3.8f, 0, ex, 0);
                    p.explode = ex;
                }
                // timing cover at the front
                Mesh tc = mesh(F);
                if (e.timingRear) tc.box(x1, R * 0.3f, -hz * 0.92f, x1 + B * 0.22f, D + headH * 0.9f, hz * 0.92f);
                else tc.box(x0 - B * 0.22f, R * 0.3f, -hz * 0.92f, x0, D + headH * 0.9f, hz * 0.92f);
                Part tcp = add("timing", Part.SHELL, blockCol, tc);
                tcp.bank = b; tcp.half = 2; tcp.heat = 0.4f;
                tcp.explode = new float[]{e.timingRear ? B * 1.4f : -B * 1.4f, 0, 0};
            }
        }

        // ---------------- crankcase, sump
        if (radial) buildRadialCase();
        else {
            float cz = R + B * 0.42f;
            float ytop = R + B * 0.3f;
            if (lay.equals("F")) { ytop = R + B * 0.45f; cz = R + B * 0.3f; }
            float ybot = -(R + B * 0.38f);
            if (lay.equals("IV")) { float t = ytop; ytop = -ybot; ybot = -t; }
            float cx0 = xMin - P * 0.55f, cx1 = xMax + P * 0.55f;
            for (int s = -1; s <= 1; s += 2) {
                Mesh m = mesh(M3.id());
                m.box(cx0, ybot, s < 0 ? -cz : 0, cx1, ytop, s < 0 ? 0 : cz);
                Part p = add("crankcase", Part.SHELL, blockCol, m);
                p.half = s; p.cutAxis = new float[]{0, 0, 1}; p.heat = 0.45f;
            }
            float sumpH = e.drySump ? B * 0.22f : B * 0.62f;
            if (e.gbxSump) sumpH = B * 1.35f;
            if (twoStroke && e.cc < 2000) sumpH = B * 0.15f;
            boolean inverted = lay.equals("IV");
            float sy0 = inverted ? ytop : ybot - sumpH, sy1 = inverted ? ytop + sumpH : ybot;
            for (int s = -1; s <= 1; s += 2) {
                Mesh m = mesh(M3.id());
                m.box(cx0 + B * 0.15f, sy0, s < 0 ? -cz * 0.9f : 0, cx1 - B * 0.15f, sy1, s < 0 ? 0 : cz * 0.9f);
                Part p = add(e.gbxSump ? "gearbox" : "sump", Part.SHELL, 0xFF5C626A, m);
                p.half = s; p.cutAxis = new float[]{0, 0, 1}; p.heat = 0.4f;
                p.explode = new float[]{0, inverted ? B * 2.4f : -B * 2.4f, 0};
            }
        }

        // ---------------- internals
        pistons = new Part[n];
        rods = new Part[n];
        charges = new Part[n];
        Mesh crank = new Mesh();
        float jr = B * 0.22f;
        for (int i = 0; i < n; i++) {
            float[] F = M3.rotX(cylBeta[i]);
            // piston: local origin at wrist pin, +Y up the bore
            Mesh pm = new Mesh();
            pm.frustum(0, -B * 0.42f, 0, 0, 1, 0, B * 0.48f, B * 0.49f, B * 0.42f + CH, 16, true, true);
            pm.cyl(-B * 0.36f, 0, 0, 1, 0, 0, B * 0.11f, B * 0.72f, 8);
            Part pp = add("piston", Part.MOVING, 0xFFCDD2D8, pm);
            pp.cyl = i; pp.heat = 0.8f;
            float[] ex = new float[3];
            M3.applyDir(F, 0, B * 1.9f, 0, ex, 0);
            pp.explode = ex;
            pistons[i] = pp;
            // rod: from big end (origin) up +Y to small end at L
            Mesh rm = new Mesh();
            rm.cyl(-B * 0.13f, 0, 0, 1, 0, 0, B * 0.27f, B * 0.26f, 12);
            rm.box(-B * 0.09f, B * 0.15f, -B * 0.1f, B * 0.09f, L - B * 0.1f, B * 0.1f);
            rm.cyl(-B * 0.1f, L, 0, 1, 0, 0, B * 0.15f, B * 0.2f, 10);
            Part rp = add("rod", Part.MOVING, e.redline > 8500 && !twoStroke ? 0xFFB8AE9C : 0xFF9EA4AC, rm);
            rp.cyl = i; rp.heat = 0.45f;
            float[] exr = new float[3];
            M3.applyDir(F, 0, B * 0.9f, 0, exr, 0);
            rp.explode = exr;
            rods[i] = rp;
            // charge (gas column)
            Mesh cm = new Mesh();
            cm.cyl(0, 0, 0, 0, 1, 0, 1f, 1f, 16);
            Part cp = add("charge", Part.CHARGE, 0xFF6FA8FF, cm);
            cp.cyl = i; cp.emissive = true; cp.alpha = 0.55f;
            charges[i] = cp;
            // liner (only visible in x-ray)
            Mesh lm = mesh(F);
            lm.frustum(cylX[i], R + L * 0.35f, 0, 0, 1, 0, B * 0.52f, B * 0.52f, D - (R + L * 0.35f), 16, false, false);
            Part lp = add("liner", Part.LINER, 0xFFA8B0BA, lm);
            lp.cyl = i; lp.alpha = 0.18f; lp.doubleSided = true; lp.heat = 0.65f; lp.half = 2;
            // crank throw for this cylinder at angle beta+phase
            float ang = cylBeta[i] + cylPhase[i];
            float[] T = M3.rotX(ang);
            crank.frame(T);
            float w = B * 0.13f;
            float cx = cylX[i];
            crank.box(cx - B * 0.32f, -R * 0.55f, -B * 0.3f, cx - B * 0.32f + w, R + B * 0.16f, B * 0.3f);
            crank.box(cx + B * 0.32f - w, -R * 0.55f, -B * 0.3f, cx + B * 0.32f, R + B * 0.16f, B * 0.3f);
            crank.box(cx - B * 0.32f, -R * 0.55f - B * 0.32f, -B * 0.42f, cx + B * 0.32f, -R * 0.55f, B * 0.42f); // counterweight
            crank.cyl(cx - B * 0.3f, R, 0, 1, 0, 0, B * 0.2f, B * 0.6f, 12);
        }
        crank.frame(M3.id());
        crank.cyl(xMin - P * 0.75f, 0, 0, 1, 0, 0, jr, (xMax - xMin) + P * 1.5f, 14);
        Part cp = add("crank", Part.MOVING, 0xFF7D838B, crank);
        cp.heat = 0.45f;
        cp.explode = new float[]{0, -B * 1.6f, 0};
        spinners.add(cp);
        // flywheel and front pulley
        Mesh fw = new Mesh();
        float fr = Math.max(R + B * 0.5f, B * 0.8f);
        if (radial) fr = 0;
        if (fr > 0) {
            fw.cyl(xMax + P * 0.7f, 0, 0, 1, 0, 0, fr, B * 0.14f, 28);
            for (int k = 0; k < 6; k++) {
                double a = Math.PI * 2 * k / 6;
                fw.boxC(xMax + P * 0.7f + B * 0.15f, (float) Math.sin(a) * fr * 0.55f, (float) Math.cos(a) * fr * 0.55f, B * 0.02f, B * 0.06f, B * 0.06f);
            }
            Part f = add("flywheel", Part.MOVING, 0xFF6F757D, fw);
            f.heat = 0.3f;
            f.explode = new float[]{B * 1.6f, 0, 0};
            spinners.add(f);
            Mesh pu = new Mesh();
            pu.cyl(xMin - P * 0.95f, 0, 0, 1, 0, 0, B * 0.42f, B * 0.18f, 20);
            pu.boxC(xMin - P * 0.95f - B * 0.01f, B * 0.25f, 0, B * 0.01f, B * 0.05f, B * 0.05f);
            Part pul = add("pulley", Part.MOVING, 0xFF2F3338, pu);
            pul.explode = new float[]{-B * 1.8f, 0, 0};
            spinners.add(pul);
        }

        buildValvetrain(dohc, sohc, ohv);
        buildPlugs();
        buildIntake();
        buildExhaust();
        buildAncillaries();
        buildFlows();
    }

    private int intakeSide(float beta) {
        String lay = e.layout;
        if (lay.equals("I") || lay.equals("VR")) return -1;
        if (lay.equals("F")) return beta < 0 ? 1 : -1;
        if (radial) return 1;
        int s = beta < 0 ? 1 : -1;
        if (lay.equals("IV")) s = -s;
        if (Math.abs(beta) < 1f) s = -1;
        if (e.hotV) s = -s;
        return s;
    }

    private void assignPhases() {
        int[] order;
        String lay = e.layout;
        if (radial) {
            int rows = Math.max(1, e.rows), m = n / rows;
            for (int i = 0; i < n; i++) {
                int r = i / m, k = i % m;
                float ph = -cylBeta[i] + 360f * (k % 2) + r * 180f;
                cylPhase[i] = mod(ph, cycle);
            }
            return;
        }
        if (n == 2 && lay.equals("V")) {
            cylPhase[0] = mod(-cylBeta[0], cycle);
            cylPhase[1] = mod(-cylBeta[1] + 360f, cycle);
            return;
        }
        if (n == 2 && lay.equals("F")) {
            cylPhase[0] = 0; cylPhase[1] = mod(-360f, cycle);
            return;
        }
        if (n == 2 && lay.equals("I") && !twoStroke && e.vt.equals("SOHC") && e.make.contains("Royal")) {
            cylPhase[0] = 0; cylPhase[1] = mod(-270f, cycle);
            return;
        }
        // firing sequence
        if (lay.equals("I") || lay.equals("VR")) order = inlineOrder(n);
        else {
            // interleave banks
            int nb = bankBeta.length;
            int per = n / nb;
            int[] io = inlineOrder(per);
            order = new int[n];
            int k = 0;
            for (int i = 0; i < per; i++)
                for (int b = 0; b < nb; b++) {
                    int j = io[(i + b * (per > 2 ? per / 2 : 0)) % per];
                    order[k++] = b * per + j;
                }
        }
        float interval = (float) cycle / n;
        for (int k = 0; k < n; k++) cylPhase[order[k]] = mod(-k * interval, cycle);
    }

    private static int[] inlineOrder(int n) {
        switch (n) {
            case 1: return new int[]{0};
            case 2: return new int[]{0, 1};
            case 3: return new int[]{0, 1, 2};
            case 4: return new int[]{0, 2, 3, 1};
            case 5: return new int[]{0, 1, 3, 4, 2};
            case 6: return new int[]{0, 4, 2, 5, 1, 3};
            case 8: return new int[]{0, 5, 1, 4, 7, 2, 6, 3};
        }
        int[] o = new int[n];
        int k = 0;
        for (int i = 0; i < n; i += 2) o[k++] = i;
        for (int i = n - 1 - (n % 2 == 0 ? 0 : 1); i > 0; i -= 2) o[k++] = i;
        if (k < n) for (int i = 1; i < n && k < n; i += 2) { boolean has = false; for (int j = 0; j < k; j++) if (o[j] == i) has = true; if (!has) o[k++] = i; }
        return o;
    }

    static float mod(float a, float m) {
        float r = a % m;
        return r < 0 ? r + m : r;
    }

    private void buildAirBarrel(int i, float[] F) {
        float x = cylX[i];
        float y0 = R + L * 0.3f;
        Mesh m = mesh(F);
        m.cyl(x, y0, 0, 0, 1, 0, B * 0.62f, D - y0, 18);
        Part p = add("barrel", Part.SHELL, radial ? 0xFF707780 : 0xFF8C939C, m);
        p.half = 2; p.heat = 0.6f; p.cyl = i;
        Mesh fm = mesh(F);
        float fr = B * (radial ? 0.86f : 0.95f);
        int nf = Math.max(4, (int) ((D - y0) / (B * 0.11f)));
        for (int k = 0; k < nf; k++) {
            float y = y0 + (D - y0) * (k + 0.5f) / nf;
            fm.cyl(x, y, 0, 0, 1, 0, fr, B * 0.025f, 12);
        }
        Part fp = add("fins", Part.SHELL, 0xFF7A8189, fm);
        fp.half = 2; fp.heat = 0.55f; fp.cyl = i;
        if (radial) {
            Mesh hm = mesh(F);
            hm.boxC(x, D + B * 0.32f, 0, B * 0.62f, B * 0.32f, B * 0.62f);
            for (int k = 0; k < 4; k++) hm.boxC(x, D + B * 0.12f + k * B * 0.14f, 0, B * 0.82f, B * 0.012f, B * 0.82f);
            Part hp = add("head", Part.SHELL, 0xFF8F969E, hm);
            hp.half = 2; hp.heat = 0.7f; hp.cyl = i;
            float[] ex = new float[3];
            M3.applyDir(F, 0, B * 2.2f, 0, ex, 0);
            hp.explode = ex;
        }
    }

    private void buildRadialCase() {
        int rows = Math.max(1, e.rows);
        float cr = R + L * 0.32f;
        for (int r = 0; r < rows; r++) {
            Mesh m = new Mesh();
            m.cyl(-r * B * 2.1f - B * 0.75f, 0, 0, 1, 0, 0, cr, B * 1.5f, 28);
            Part p = add("crankcase", Part.SHELL, 0xFF6C737B, m);
            p.half = 2; p.heat = 0.45f;
        }
        Mesh nose = new Mesh();
        nose.frustum(B * 0.75f, 0, 0, 1, 0, 0, cr * 0.95f, cr * 0.55f, B * 1.4f, 26, false, true);
        Part np2 = add("reduction", Part.SHELL, 0xFF7A8189, nose);
        np2.half = 2; np2.explode = new float[]{-B * 1.8f, 0, 0};
        Mesh hub = new Mesh();
        hub.frustum(B * 2.15f, 0, 0, 1, 0, 0, cr * 0.32f, 0.01f, B * 0.9f, 20, true, false);
        Part hp = add("prop", Part.MOVING, 0xFF2D3036, hub);
        hp.explode = new float[]{-B * 2.6f, 0, 0};
        spinners.add(hp);
        // rear supercharger drum
        Mesh sc = new Mesh();
        float back = -(rows - 1) * B * 2.1f - B * 0.75f;
        sc.cyl(back - B * 1.3f, 0, 0, 1, 0, 0, cr * 0.8f, B * 1.3f, 26);
        Part scp = add("supercharger", Part.DUCT, 0xFF8F969E, sc);
        scp.heat = 0.35f; scp.explode = new float[]{B * 1.8f, 0, 0};
    }

    private void buildValvetrain(boolean dohc, boolean sohc, boolean ohv) {
        if (radial) {
            // pushrod tubes to each head
            for (int i = 0; i < n; i++) {
                float[] F = M3.rotX(cylBeta[i]);
                Mesh m = mesh(F);
                m.cyl(cylX[i] + B * 0.55f, R + L * 0.25f, B * 0.2f, 0, 1, 0, B * 0.05f, D - R - L * 0.25f + B * 0.3f, 6);
                m.cyl(cylX[i] + B * 0.55f, R + L * 0.25f, -B * 0.2f, 0, 1, 0, B * 0.05f, D - R - L * 0.25f + B * 0.3f, 6);
                Part p = add("pushrod", Part.MISC, 0xFF9AA0A8, m);
                p.cyl = i; p.half = 2;
            }
        }
        if (e.vt.equals("PORT")) return;
        boolean uni = e.vt.equals("UNI");
        int nv = e.valves;
        int nin = uni ? 0 : (nv >= 4 ? (nv == 5 ? 3 : nv / 2) : (nv == 3 ? 2 : 1));
        int nex = uni ? nv : nv - nin;
        float rin = nin >= 3 ? 0.13f : (nin == 2 ? 0.17f : 0.24f);
        float rex = nex >= 2 ? 0.15f : 0.21f;
        if (uni) rex = nex == 1 ? 0.28f : 0.14f;
        for (int i = 0; i < n; i++) {
            int b = cylBank[i];
            float[] F = M3.rotX(cylBeta[i]);
            int side = bankSide[b];
            for (int k = 0; k < nin + nex; k++) {
                boolean in = k < nin;
                int cnt = in ? nin : nex;
                int idx = in ? k : k - nin;
                float rv = (in ? rin : rex) * B;
                float xo = cnt == 1 ? 0 : (idx - (cnt - 1) / 2f) * B * (cnt == 3 ? 0.27f : 0.38f);
                float zo = uni ? (nex == 1 ? 0 : (idx < 2 ? -1 : 1) * B * 0.2f) : (in ? side : -side) * B * (cnt == 3 && idx == 1 ? 0.27f : 0.21f);
                if (uni && nex == 4) xo = (idx % 2 == 0 ? -1 : 1) * B * 0.2f;
                float tilt = uni ? 0 : (float) Math.toRadians(e.vt.equals("OHV") ? 8 : 17);
                float sz = Math.signum(zo);
                float ax = 0, ay = (float) Math.cos(tilt), az = (float) Math.sin(tilt) * sz;
                float sx = cylX[i] + xo, sy = D + B * 0.02f, szz = zo;
                if (e.vt.equals("SV")) { sy = D - B * 0.02f; szz = -side * B * 0.85f + (in ? -B * 0.0f : 0); xo = (in ? -1 : 1) * B * 0.22f; sx = cylX[i] + xo; ay = 1; az = 0; }
                Mesh m = new Mesh();
                m.cyl(0, 0, 0, ax, ay, az, rv, B * 0.04f, 14);
                m.cyl(0, B * 0.04f * ay, B * 0.04f * az, ax, ay, az, B * 0.03f, B * 0.6f, 6);
                Part vp = add(in ? "valve_in" : "valve_ex", Part.MOVING, in ? 0xFFBFC6CE : 0xFFB19E86, m);
                vp.cyl = i; vp.heat = in ? 0.5f : 0.95f;
                Valve v = new Valve();
                v.p = vp; v.cyl = i; v.intake = in;
                float[] axisW = new float[3];
                M3.applyDir(F, ax, ay, az, axisW, 0);
                v.axis = axisW;
                v.maxLift = rv * 0.55f;
                v.base = M3.mul(F, M3.trans(sx, sy, szz));
                float[] ex = new float[3];
                M3.applyDir(F, 0, B * 2.9f, 0, ex, 0);
                vp.explode = ex;
                if (ohv && !radial) {
                    // pushrod from block cam to head top
                    Mesh pr = new Mesh();
                    float len = D + headH * 0.7f - (R + B * 0.45f);
                    pr.cyl(0, 0, 0, 0, 1, 0, B * 0.035f, len, 6);
                    Part pp = add("pushrod", Part.MOVING, 0xFF9AA0A8, pr);
                    pp.cyl = i;
                    v.pushrod = pp;
                    v.pushBase = M3.mul(F, M3.trans(sx, R + B * 0.45f, side * B * 0.5f * (in ? 1 : 0.6f)));
                    v.pushAxis = new float[]{axisW[0], axisW[1], axisW[2]};
                    pp.explode = ex.clone();
                    Mesh rk = mesh(F);
                    rk.boxC(sx, D + headH * 0.75f, (szz + side * B * 0.5f) / 2f, B * 0.05f, B * 0.05f, B * 0.3f);
                    Part rkp = add("rocker", Part.MISC, 0xFF8A9098, rk);
                    rkp.cyl = i; rkp.half = 2;
                    rkp.explode = ex.clone();
                }
                valves.add(v);
            }
        }
        // camshafts
        if (dohc || sohc) {
            int nb = bankBeta.length;
            for (int b = 0; b < nb; b++) {
                if (radial) break;
                float[] F = M3.rotX(bankBeta[b]);
                int side = bankSide[b];
                float bx0 = 1e9f, bx1 = -1e9f;
                for (int i = 0; i < n; i++) if (cylBank[i] == b) { bx0 = Math.min(bx0, cylX[i]); bx1 = Math.max(bx1, cylX[i]); }
                int shafts = dohc ? 2 : 1;
                for (int sh = 0; sh < shafts; sh++) {
                    boolean inShaft = dohc ? sh == 0 : true;
                    float zc = dohc ? (sh == 0 ? side : -side) * B * 0.26f : 0;
                    float yc = D + headH * 0.62f;
                    Mesh m = new Mesh();
                    if (e.vt.equals("FREE")) {
                        // Freevalve: pneumatic actuators instead of a camshaft
                        for (int i = 0; i < n; i++) if (cylBank[i] == b)
                            for (int k = -1; k <= 1; k += 2) m.cyl(cylX[i] + k * B * 0.19f - 0, -B * 0.1f, 0, 0, 1, 0, B * 0.09f, B * 0.25f, 10);
                    } else {
                        m.cyl(bx0 - P * 0.5f, 0, 0, 1, 0, 0, B * 0.085f, (bx1 - bx0) + P, 10);
                        for (int i = 0; i < n; i++) if (cylBank[i] == b) {
                            float centre = twoStroke ? 180 : (inShaft && dohc ? 450f : 270f);
                            float ang = (cylPhase[i] - centre) / 2f + 180f;
                            for (int k = -1; k <= 1; k += 2) {
                                if (!dohc && k == 1) ang += 45;
                                Mesh lobe = m;
                                float[] save = lobe.f;
                                lobe.frame(M3.rotX(ang));
                                lobe.box(cylX[i] + k * B * 0.19f - B * 0.06f, -B * 0.1f, -B * 0.1f, cylX[i] + k * B * 0.19f + B * 0.06f, B * 0.2f, B * 0.1f);
                                lobe.frame(save);
                            }
                        }
                    }
                    Part cp = add(e.vt.equals("FREE") ? "actuator" : "cam", Part.MOVING, 0xFF90969E, m);
                    cp.heat = 0.45f; cp.bank = b;
                    float[] ex = new float[3];
                    M3.applyDir(F, 0, B * 3.4f, 0, ex, 0);
                    cp.explode = ex;
                    Cam c = new Cam();
                    c.p = cp;
                    c.base = M3.mul(F, M3.trans(0, yc, zc));
                    if (e.vt.equals("FREE")) { c.base = M3.mul(F, M3.trans(0, D + headH * 0.62f, zc)); }
                    cams.add(c);
                }
            }
        } else if (ohv && !radial) {
            Mesh m = new Mesh();
            m.cyl(xMin - P * 0.5f, 0, 0, 1, 0, 0, B * 0.1f, (xMax - xMin) + P, 10);
            for (int i = 0; i < n; i++) {
                float ang = cylPhase[i] / 2f;
                float[] save = m.f;
                m.frame(M3.rotX(ang));
                m.box(cylX[i] - B * 0.07f, -B * 0.12f, -B * 0.12f, cylX[i] + B * 0.07f, B * 0.22f, B * 0.12f);
                m.frame(save);
            }
            Part cp = add("cam", Part.MOVING, 0xFF90969E, m);
            cp.heat = 0.45f;
            cp.explode = new float[]{0, B * 0.8f, 0};
            Cam c = new Cam();
            c.p = cp;
            float yc = e.layout.equals("I") ? R + B * 0.45f : R + B * 0.75f;
            float zc = e.layout.equals("I") ? bankSide[0] * B * 0.5f : 0;
            if (e.layout.equals("F")) { yc = 0; zc = 0; }
            if (e.layout.equals("IV")) yc = -yc;
            c.base = M3.trans(0, yc, zc);
            cams.add(c);
        }
    }

    private void buildPlugs() {
        if (wankel) return;
        boolean diesel = e.diesel();
        for (int i = 0; i < n; i++) {
            float[] F = M3.rotX(cylBeta[i]);
            float top = D + (radial ? B * 0.66f : headH) + B * (e.vt.equals("PORT") ? 0.1f : 0.28f);
            Mesh m = mesh(F);
            float zc = e.vt.equals("SV") ? -bankSide[cylBank[i]] * B * 0.3f : 0;
            m.cyl(cylX[i], D - B * 0.01f, zc, 0, 1, 0, B * 0.055f, top - D, 8);
            m.cyl(cylX[i], top - B * 0.05f, zc, 0, 1, 0, B * 0.085f, B * 0.12f, 8);
            Part p = add(diesel ? "injector" : (e.fuel == 'G' ? "glowplug" : "plug"), Part.MISC, diesel ? 0xFF9C8A5A : 0xFFE4E6EA, m);
            p.cyl = i; p.heat = 0.6f;
            float[] ex = new float[3];
            M3.applyDir(F, 0, B * 4.6f, 0, ex, 0);
            p.explode = ex;
            if (!diesel && !radial && e.year > 1995 && !e.vt.equals("PORT")) {
                Mesh c = mesh(F);
                c.boxC(cylX[i], top + B * 0.08f, zc, B * 0.12f, B * 0.08f, B * 0.16f);
                Part cp = add("coil", Part.MISC, 0xFF202327, c);
                cp.cyl = i; cp.half = 2;
                cp.explode = ex.clone();
            }
        }
    }

    // intake runner start points per cylinder (model space) for flows
    float[][] intakeTube, exhaustTube;
    float[][] boostTube = new float[0][];

    private float[] lp(float[] F, float x, float y, float z) {
        float[] o = new float[3];
        M3.apply(F, x, y, z, o, 0);
        return o;
    }

    private static float[] cat(float[]... ps) {
        float[] r = new float[ps.length * 3];
        for (int i = 0; i < ps.length; i++) System.arraycopy(ps[i], 0, r, i * 3, 3);
        return r;
    }


    String intakeType() {
        if (radial) return "radial";
        if (!e.intake.isEmpty()) return e.intake;
        if (!e.sc && e.turbos == 0 && (e.redline >= 7800) && n <= 12) return "itb";
        if (e.year < 1985 && !e.diesel() && e.turbos == 0 && !e.sc) return "carb";
        return "plen";
    }

    boolean veeLayout() {
        String lay = e.layout;
        return (lay.equals("V") || lay.equals("W") || lay.equals("IV") || lay.equals("B")) && n > 2 && e.bank <= 120 && !e.hotV;
    }

    float plenumY;      // valley plenum height (engine frame)
    float[] scTop;      // where a top supercharger sits
    float[] icInlet;    // where charge pipes end

    private float[] bankRange(int b) {
        float bx0 = 1e9f, bx1 = -1e9f;
        for (int i = 0; i < n; i++) if (cylBank[i] == b) { bx0 = Math.min(bx0, cylX[i]); bx1 = Math.max(bx1, cylX[i]); }
        return new float[]{bx0, bx1};
    }

    private Part duct(String key, int color, Mesh m, float heat, float[] explode) {
        Part p = add(key, Part.DUCT, color, m);
        p.heat = heat;
        if (explode != null) p.explode = explode;
        return p;
    }

    private void buildIntake() {
        intakeTube = new float[n][];
        String it = intakeType();
        boolean vee = veeLayout();
        String lay = e.layout;
        float px0 = xMin - P * 0.5f, px1 = xMax + P * 0.5f;
        if (vee) {
            float a = (float) Math.toRadians(e.bank / 2f);
            plenumY = (D + headH * 0.6f) * (float) Math.cos(a) + B * 0.55f;
            if (lay.equals("IV")) plenumY = -plenumY;
        }
        float up = lay.equals("IV") ? -1f : 1f;
        if (it.equals("radial")) {
            for (int i = 0; i < n; i++) {
                float[] F = M3.rotX(cylBeta[i]);
                float back = cylX[i] + B * 0.9f;
                float[] p0 = lp(F, cylX[i] - B * 0.1f, D + B * 0.25f, 0);
                float[] p1 = lp(F, back, D + B * 0.1f, 0);
                float[] p2 = lp(F, back + B * 0.2f, R + L * 0.35f, 0);
                float[] pts = cat(p2, p1, p0);
                Mesh m = new Mesh();
                m.tube(pts, new float[]{B * 0.12f}, 8, 0.3f, 0.3f);
                Part p = duct("intake", 0xFF7A8189, m, 0.25f, null);
                p.cyl = i;
                intakeTube[i] = pts;
            }
            return;
        }
        boolean centralTop = vee && (it.equals("plen") || it.equals("box") || it.equals("carb4") || it.equals("carb2x4") || it.equals("webers") || it.equals("hat") || it.equals("updraft") || (it.equals("carb") && e.ncarb > 0 && e.ncarb < n));
        boolean longRunner = it.equals("long");
        float longPlenY = D + headH + B * 1.15f;
        for (int i = 0; i < n; i++) {
            int b = cylBank[i];
            float[] F = M3.rotX(cylBeta[i]);
            float[] FB = M3.rotX(bankBeta[b]);
            int s = bankSide[b];
            float hz = halfW;
            float[] port;
            if (twoStroke && !e.vt.equals("UNI")) port = lp(F, cylX[i], R + B * 0.2f, s * B * 0.55f);
            else port = lp(FB, cylX[i], D + headH * 0.42f, s * (e.vt.equals("SV") ? hz + B * 0.05f : hz));
            float[] out1, end, pts;
            if (longRunner) {
                // VR6: runners loop up and over the head into a plenum sitting above the exhaust side
                float[] a1 = lp(FB, cylX[i], D + headH * 0.45f, s * (hz + B * 0.45f));
                float[] a2 = lp(FB, cylX[i], D + headH + B * 0.55f, s * (hz + B * 0.35f));
                float[] a3 = lp(FB, cylX[i], longPlenY + B * 0.1f, s * hz * 0.2f);
                end = lp(FB, cylX[i], longPlenY, -s * hz * 0.45f);
                pts = cat(end, a3, a2, a1, port);
                out1 = a1;
            } else if (centralTop) {
                out1 = lp(FB, cylX[i], D + headH * 0.55f, s * (hz + B * 0.22f));
                end = new float[]{cylX[i], plenumY - up * B * 0.2f, 0};
                pts = cat(end, out1, port);
            } else if (lay.equals("F") || e.bank > 120 || (lay.equals("V") && n == 2)) {
                out1 = lp(FB, cylX[i], D + headH * 0.5f, s * (hz + B * 0.35f));
                end = lp(FB, cylX[i], D * 0.72f, s * (hz + B * 1.1f));
                pts = cat(end, out1, port);
            } else {
                out1 = lp(FB, cylX[i], D + headH * 0.5f, s * (hz + B * 0.45f));
                end = lp(FB, cylX[i], D + headH * 0.2f, s * (hz + B * 1.15f));
                pts = cat(end, out1, port);
            }
            Mesh m = new Mesh();
            m.tube(pts, new float[]{B * 0.17f}, 10, 0.2f, 0.25f);
            float[] exv = new float[3];
            M3.applyDir(FB, 0, B * 0.6f, s * B * 1.2f, exv, 0);
            if (centralTop) exv = new float[]{0, up * B * 2f, 0};
            if (longRunner) exv = new float[]{0, B * 2.6f, 0};
            Part rp = duct("runner", longRunner ? 0xFF2E3237 : 0xFF5A6068, m, 0.2f, exv);
            rp.cyl = i;
            intakeTube[i] = pts;
            boolean perCylCarb = it.equals("carb") && (e.ncarb == 0 || e.ncarb >= n);
            if ((it.equals("itb") || perCylCarb) && !centralTop) {
                float dx = end[0] - out1[0], dy = end[1] - out1[1], dz = end[2] - out1[2];
                float dl = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
                dx /= dl; dy /= dl; dz /= dl;
                Mesh tm = new Mesh();
                if (perCylCarb) {
                    tm.cyl(end[0], end[1], end[2], dx, dy, dz, B * 0.22f, B * 0.35f, 10);
                    tm.frustum(end[0] + dx * B * 0.35f, end[1] + dy * B * 0.35f, end[2] + dz * B * 0.35f, dx, dy, dz, B * 0.2f, B * 0.32f, B * 0.25f, 12, false, true);
                } else {
                    tm.cyl(end[0], end[1], end[2], dx, dy, dz, B * 0.2f, B * 0.16f, 12);
                    tm.frustum(end[0] + dx * B * 0.16f, end[1] + dy * B * 0.16f, end[2] + dz * B * 0.16f, dx, dy, dz, B * 0.17f, B * 0.33f, B * 0.42f, 14, false, false);
                }
                Part tp = duct(perCylCarb ? "carb" : "trumpet", perCylCarb ? 0xFFB3AFA4 : 0xFFAEB4BB, tm, 0.15f, rp.explode.clone());
                tp.cyl = i; tp.doubleSided = !perCylCarb;
                float[] ext = {end[0] + dx * B * 0.6f, end[1] + dy * B * 0.6f, end[2] + dz * B * 0.6f};
                intakeTube[i] = cat(ext, end, out1, port);
            }
        }
        // ---- central (valley) induction
        if (centralTop) {
            float top = plenumY + up * B * 0.35f;
            Mesh pm = new Mesh();
            pm.box(px0, Math.min(plenumY - up * B * 0.25f, top), -B * 0.45f, px1, Math.max(plenumY - up * B * 0.25f, top), B * 0.45f);
            duct(it.equals("carb4") || it.equals("carb2x4") ? "manifold" : "plenum", it.equals("plen") ? 0xFF4C5259 : 0xFF8F959D, pm, 0.2f, new float[]{0, up * B * 2.0f, 0});
            float cx = (px0 + px1) / 2f;
            if (it.equals("box")) {
                Mesh bm = new Mesh();
                bm.box(px0 - P * 0.1f, top, -halfW * 1.4f, px1 + P * 0.1f, top + up * B * 0.85f, halfW * 1.4f);
                duct("airbox", 0xFF24272C, bm, 0.15f, new float[]{0, up * B * 3.2f, 0});
                int nt = Math.max(1, e.nthr);
                Mesh th = new Mesh();
                for (int k = 0; k < nt; k++) {
                    float tx = nt == 1 ? cx : px0 + (px1 - px0) * (k + 0.5f) / nt;
                    float tz = (k % 2 == 0 ? -1 : 1) * halfW * 0.7f;
                    th.cyl(tx, top + up * B * 0.85f, tz, 0, up, 0, B * 0.26f, B * 0.3f, 14);
                }
                duct("throttle", 0xFF8E949C, th, 0.15f, new float[]{0, up * B * 3.6f, 0});
            } else if (it.equals("webers")) {
                int nc = e.ncarb > 0 ? e.ncarb : Math.max(2, n / 2);
                Mesh wm = new Mesh();
                for (int k = 0; k < nc; k++) {
                    float tx = px0 + (px1 - px0) * (k + 0.5f) / nc;
                    wm.boxC(tx, top + up * B * 0.25f, 0, B * 0.32f, B * 0.25f, B * 0.45f);
                    for (int c = -1; c <= 1; c += 2) wm.frustum(tx, top + up * B * 0.5f, c * B * 0.22f, 0, up, 0, B * 0.16f, B * 0.24f, B * 0.35f, 12, false, false);
                }
                Part w = duct("weber", 0xFFB9B3A6, wm, 0.15f, new float[]{0, up * B * 3f, 0});
                w.doubleSided = true;
            } else if (it.equals("carb4") || it.equals("carb2x4")) {
                int nc = it.equals("carb2x4") ? 2 : 1;
                Mesh cm = new Mesh();
                for (int k = 0; k < nc; k++) {
                    float tx = nc == 1 ? cx : cx + (k == 0 ? -1 : 1) * P * 0.9f;
                    cm.boxC(tx, top + up * B * 0.3f, 0, B * 0.55f, B * 0.3f, B * 0.5f);
                }
                duct("carb4", 0xFFB3AFA4, cm, 0.15f, new float[]{0, up * B * 3f, 0});
                Mesh ac = new Mesh();
                float acR = nc == 2 ? B * 1.9f : B * 1.4f;
                ac.cyl(cx, top + up * B * 0.6f, 0, 0, up, 0, acR, B * 0.38f, 28);
                duct("aircleaner", e.blk != 0 ? 0xFF2A2D33 : 0xFF3C4148, ac, 0.1f, new float[]{0, up * B * 4.2f, 0});
            } else if (it.equals("carb")) {
                int nc = Math.max(1, e.ncarb);
                Mesh cm = new Mesh();
                for (int k = 0; k < nc; k++) {
                    float tx = px0 + (px1 - px0) * (k + 0.5f) / nc;
                    cm.cyl(tx, top, 0, 0, up, 0, B * 0.3f, B * 0.5f, 12);
                }
                duct("carb", 0xFFB3AFA4, cm, 0.15f, new float[]{0, up * B * 3f, 0});
            } else if (it.equals("updraft")) {
                Mesh cm = new Mesh();
                cm.box(xMax + P * 0.9f, -R - B * 1.2f, -B * 0.5f, xMax + P * 1.6f, -R - B * 0.3f, B * 0.5f);
                duct("carb", 0xFFB3AFA4, cm, 0.15f, new float[]{B * 2f, -B * 1f, 0});
                Mesh pipe = new Mesh();
                pipe.tube(cat(new float[]{xMax + P * 1.25f, -R - B * 0.3f, 0}, new float[]{xMax + P * 1.25f, plenumY * 0.6f, 0}, new float[]{xMax, plenumY, 0}), new float[]{B * 0.3f}, 12, 0.3f, 0.3f);
                duct("boostpipe", 0xFF7A8189, pipe, 0.3f, null);
            } else if (!e.sc && e.turbos == 0) {
                int nt = Math.max(1, e.nthr);
                Mesh th = new Mesh();
                for (int k = 0; k < nt; k++) th.cyl(px0 - B * 0.45f, plenumY + (nt == 1 ? 0 : (k == 0 ? -1 : 1) * B * 0.0f), (nt == 1 ? 0 : (k == 0 ? -1 : 1) * B * 0.35f), 1, 0, 0, B * 0.24f, B * 0.45f, 16);
                duct("throttle", 0xFF8E949C, th, 0.15f, null);
            }
            scTop = new float[]{cx, top, 0};
            icInlet = new float[]{px0 - B * 0.4f, plenumY, 0};
        } else if (longRunner) {
            float[] FB = M3.rotX(bankBeta[0]);
            int s = bankSide[0];
            Mesh m = mesh(FB);
            m.box(px0, longPlenY - B * 0.3f, -s * halfW * 0.85f, px1, longPlenY + B * 0.35f, -s * halfW * 0.05f);
            duct("plenum", 0xFF2E3237, m, 0.2f, new float[]{0, B * 3.0f, 0});
            Mesh th = mesh(FB);
            th.cyl(px0 - B * 0.45f, longPlenY, -s * halfW * 0.45f, 1, 0, 0, B * 0.26f, B * 0.45f, 16);
            duct("throttle", 0xFF8E949C, th, 0.15f, new float[]{0, B * 3.0f, 0});
            icInlet = lp(FB, px0 - B * 0.4f, longPlenY, -s * halfW * 0.45f);
        } else {
            boolean perCyl = it.equals("itb") || (it.equals("carb") && (e.ncarb == 0 || e.ncarb >= n));
            for (int b = 0; b < bankBeta.length && !perCyl; b++) {
                float[] FB = M3.rotX(bankBeta[b]);
                int s = bankSide[b];
                float[] r = bankRange(b);
                float yc, zc;
                if (lay.equals("F") || e.bank > 120 || (lay.equals("V") && n == 2)) { yc = D * 0.72f; zc = s * (halfW + B * 1.25f); }
                else { yc = D + headH * 0.2f; zc = s * (halfW + B * 1.3f); }
                Mesh m = mesh(FB);
                m.boxC((r[0] + r[1]) / 2f, yc, zc, (r[1] - r[0]) / 2f + P * 0.45f, B * (it.equals("carb") ? 0.18f : 0.32f), B * 0.25f);
                float[] ex = new float[3];
                M3.applyDir(FB, 0, B * 0.6f, s * B * 1.6f, ex, 0);
                Part p = duct(it.equals("carb") ? "manifold" : "plenum", e.sc ? 0xFF8F969E : 0xFF51575F, m, 0.2f, ex);
                p.bank = b;
                if (it.equals("carb")) {
                    int nc = Math.max(1, e.ncarb / Math.max(1, bankBeta.length));
                    Mesh cm = mesh(FB);
                    for (int k = 0; k < nc; k++) {
                        float tx = r[0] + (r[1] - r[0]) * (nc == 1 ? 0.5f : (float) k / (nc - 1));
                        cm.cyl(tx, yc, zc + s * B * 0.25f, 0, 0, s, B * 0.26f, B * 0.45f, 12);
                        cm.cyl(tx, yc, zc + s * B * 0.7f, 0, 0, s, B * 0.42f, B * 0.2f, 16);
                    }
                    duct("carb", 0xFFB3AFA4, cm, 0.15f, ex.clone());
                } else if (b == 0 && !e.sc) {
                    Mesh th = mesh(FB);
                    th.cyl(r[0] - P * 0.5f - B * 0.45f, yc, zc, 1, 0, 0, B * 0.22f, B * 0.45f, 16);
                    duct("throttle", 0xFF8E949C, th, 0.15f, ex.clone());
                }
                if (b == 0) icInlet = lp(FB, r[0] - P * 0.5f - B * 0.4f, yc, zc);
            }
            if (icInlet == null) icInlet = new float[]{xMin - P, D, 0};
        }
        if (e.sc || !e.scx.isEmpty()) buildSupercharger(vee || longRunner);
    }

    /** Positive-displacement blowers sit on top with visible rotors; centrifugal units get a snail housing. */
    private void buildSupercharger(boolean central) {
        String t = e.scx.isEmpty() ? "roots" : e.scx;
        if (radial) return;
        float up = e.layout.equals("IV") ? -1f : 1f;
        if (t.equals("gear")) {
            float cr = Math.max(B * 0.9f, R + B * 0.5f);
            Mesh m = new Mesh();
            m.cyl(xMax + P * 0.95f, 0, 0, 1, 0, 0, cr, B * 0.55f, 24);
            Part p = duct("supercharger", 0xFF8F969E, m, 0.35f, new float[]{B * 2.2f, 0, 0});
            Mesh w = new Mesh();
            float wx = xMax + P * 0.95f + B * 0.27f;
            w.cyl(wx - B * 0.08f, 0, 0, 1, 0, 0, cr * 0.25f, B * 0.16f, 10);
            for (int k = 0; k < 12; k++) {
                float[] sv = w.f;
                w.frame(M3.rotX(30f * k));
                w.box(wx - B * 0.07f, cr * 0.22f, -B * 0.015f, wx + B * 0.07f, cr * 0.85f, B * 0.015f);
                w.frame(sv);
            }
            Part wp = add("impeller", Part.MOVING, 0xFFD4D9DE, w);
            wp.explode = p.explode.clone();
            scRotors.add(wp); scRotorSpeed.add(8f); scRotorPivot.add(new float[]{0, 0, 0});
            return;
        }
        if (t.equals("cent")) {
            int s = bankSide[0];
            float[] FB = M3.rotX(bankBeta[0]);
            float[] c = lp(FB, xMin - P * 0.3f, D * 0.5f, s * (halfW + B * 1.2f));
            Mesh m = new Mesh();
            m.cyl(c[0] - B * 0.2f, c[1], c[2], 1, 0, 0, B * 0.55f, B * 0.4f, 20);
            volute(m, c[0], c, B * 0.55f, B);
            m.cyl(c[0] - B * 0.6f, c[1], c[2], 1, 0, 0, B * 0.3f, B * 0.4f, 14);
            Part p = duct("supercharger", 0xFFAEB4BB, m, 0.35f, new float[]{-B * 1.6f, 0, s * B * 1.2f});
            Mesh w = new Mesh();
            for (int k = 0; k < 10; k++) {
                float[] sv = w.f;
                w.frame(M3.rotX(36f * k));
                w.box(-B * 0.12f, B * 0.08f, -B * 0.012f, B * 0.12f, B * 0.42f, B * 0.012f);
                w.frame(sv);
            }
            Part wp = add("impeller", Part.MOVING, 0xFFD4D9DE, w);
            wp.explode = p.explode.clone();
            scRotors.add(wp); scRotorSpeed.add(12f); scRotorPivot.add(c);
            Mesh pipe = new Mesh();
            pipe.tube(cat(new float[]{c[0], c[1] + B * 0.6f, c[2]}, icInlet != null ? icInlet : new float[]{xMin, D, 0}), new float[]{B * 0.18f}, 10, 0.4f, 0.3f);
            duct("boostpipe", 0xFF5E646C, pipe, 0.4f, null);
            return;
        }
        // roots / twin-screw / TVS
        float len = Math.max(P * 1.2f, (xMax - xMin) * 0.75f);
        float x0 = (xMin + xMax) / 2f - len / 2f;
        float[] base;
        float[] F;
        if (central && scTop != null) { base = new float[]{x0, scTop[1], 0}; F = M3.id(); }
        else {
            int s = bankSide[0];
            F = M3.rotX(bankBeta[0]);
            float[] c = lp(F, x0, D * 0.55f, s * (halfW + B * 0.85f));
            base = c;
            F = M3.id();
        }
        float hw = B * 0.48f, hh = B * 0.62f;
        Mesh h = new Mesh();
        h.box(base[0], base[1], base[2] - hw, base[0] + len, base[1] + up * hh, base[2] + hw);
        h.cyl(base[0] - B * 0.35f, base[1] + up * hh * 0.5f, base[2], 1, 0, 0, B * 0.2f, B * 0.35f, 12);
        h.cyl(base[0] - B * 0.55f, base[1] + up * hh * 0.5f, base[2], 1, 0, 0, B * 0.32f, B * 0.2f, 18);
        if (e.intake.equals("hat")) {
            h.box(base[0] + len * 0.25f, base[1] + up * hh, base[2] - hw * 0.8f, base[0] + len * 0.75f, base[1] + up * (hh + B * 0.75f), base[2] + hw * 0.8f);
        }
        Part sp = duct(e.intake.equals("hat") ? "blower" : "supercharger", t.equals("tvs") ? 0xFF2C2F35 : 0xFF9AA1A9, h, 0.35f, new float[]{0, up * B * 3.2f, 0});
        sp.doubleSided = true;
        // the two lobed rotors, visible in x-ray
        int lobes = t.equals("tvs") ? 4 : (t.equals("screw") ? 5 : 3);
        for (int r = -1; r <= 1; r += 2) {
            float[] uv = new float[lobes * 8 * 2];
            float rr = hw * 0.46f;
            for (int i = 0; i < lobes * 8; i++) {
                double a = 2 * Math.PI * i / (lobes * 8);
                float rad = rr * (0.62f + 0.38f * (float) Math.abs(Math.cos(lobes * a / 2)));
                uv[i * 2] = (float) Math.cos(a) * rad;
                uv[i * 2 + 1] = (float) Math.sin(a) * rad;
            }
            Mesh rm = new Mesh();
            rm.prism(0, 0, 0, uv, 1, 0, 0, len * 0.94f);
            Part rp = add("sc_rotor", Part.MOVING, 0xFFC9CED4, rm);
            rp.explode = sp.explode.clone();
            scRotors.add(rp);
            scRotorSpeed.add(r * (lobes == 5 ? 2.4f : 2.0f));
            scRotorPivot.add(new float[]{base[0] + len * 0.03f, base[1] + up * hh * 0.5f, base[2] + r * hw * 0.48f});
        }
        // belt from crank pulley
        Mesh belt = new Mesh();
        float bx = xMin - P * 0.95f + B * 0.09f;
        belt.tube(cat(new float[]{bx, B * 0.42f, 0}, new float[]{bx, base[1] + up * hh * 0.5f + B * 0.3f, base[2]}, new float[]{bx, base[1] + up * hh * 0.5f - B * 0.3f, base[2]}, new float[]{bx, -B * 0.42f, 0}), new float[]{B * 0.04f}, 6, 0.3f, 0.3f);
        Part bp = add("belt", Part.MISC, 0xFF1B1D21, belt);
        bp.half = 2;
    }

    final ArrayList<Part> scRotors = new ArrayList<>();
    final ArrayList<Float> scRotorSpeed = new ArrayList<>();
    final ArrayList<float[]> scRotorPivot = new ArrayList<>();

    private float[] turboPos(int b, int k, int count) {
        float[] r = bankRange(b);
        int s = -bankSide[b];
        float[] FB = M3.rotX(bankBeta[b]);
        String tp = e.tp.isEmpty() ? (e.hotV ? "hv" : "side") : e.tp;
        if (tp.equals("hv") && bankBeta.length >= 2) {
            float a = (float) Math.toRadians(e.bank / 2f);
            float ty = (D + headH * 0.5f) * (float) Math.cos(a) + B * 0.3f;
            float tx = count == 1 ? (r[0] + r[1]) / 2f : r[0] + (r[1] - r[0]) * k / Math.max(1, count - 1);
            return new float[]{tx, ty, (b == 0 ? -1 : 1) * B * 0.55f};
        }
        if (tp.equals("rear")) {
            return lp(FB, r[1] + P * 1.1f, D * 0.55f + k * B * 1.15f, s * (halfW + B * 0.9f));
        }
        if (tp.equals("top")) {
            float tx = r[1] - P * 0.2f - k * P * 1.2f;
            return lp(FB, tx, D + headH + B * 0.9f, s * halfW * 0.35f);
        }
        if (tp.equals("front")) return lp(FB, r[0] - P * 1.1f, D * 0.55f, s * (halfW + B * 0.9f));
        float tx = count == 1 ? (r[0] + r[1]) / 2f : r[0] + (r[1] - r[0]) * k / Math.max(1, count - 1);
        return lp(FB, tx, D * 0.48f, s * (halfW + B * 1.45f));
    }

    private void buildExhaust() {
        exhaustTube = new float[n][];
        boolean bikeLike = false;
        for (Vehicle v : e.vehicles) if (v.bikeLike() || v.type.equals("kart")) bikeLike = true;
        boolean expansion = twoStroke && e.cc < 1600 && !e.vt.equals("UNI") && bikeLike;
        boolean marine = e.vt.equals("UNI") && e.cc > 1e6f;
        String exs = e.ex;
        int nb = bankBeta.length;
        int[] perBank = new int[nb];
        if (e.turbos > 0 && !radial) {
            if (nb == 1) perBank[0] = e.turbos;
            else for (int t = 0; t < e.turbos; t++) perBank[t % nb]++;
        }
        float[][] turboIn = new float[nb][];
        for (int b = 0; b < nb && !radial; b++) {
            for (int k = 0; k < perBank[b]; k++) {
                float[] c = marine ? new float[]{xMin + (xMax - xMin) * (k + 0.5f) / perBank[b], D + headH + B * 2.2f, -bankSide[b] * B * 1.9f} : turboPos(b, k, perBank[b]);
                buildTurbo(c, b);
                if (turboIn[b] == null) turboIn[b] = c;
            }
        }
        if (marine) {
            int s = -bankSide[0];
            Mesh er = new Mesh();
            er.cyl(xMin - P * 0.5f, D + headH + B * 1.1f, s * B * 1.3f, 1, 0, 0, B * 0.75f, (xMax - xMin) + P, 24);
            duct("exrec", 0xFF8D7A68, er, 0.85f, new float[]{0, B * 2f, s * B * 2f});
            Mesh sr = new Mesh();
            sr.box(xMin - P * 0.5f, R + L * 0.45f, -s * (halfW + B * 0.1f), xMax + P * 0.5f, R + L * 0.45f + B * 1.6f, -s * (halfW + B * 1.4f));
            duct("scav", 0xFF6A7078, sr, 0.3f, new float[]{0, 0, -s * B * 2.4f});
        }
        for (int i = 0; i < n; i++) {
            int b = cylBank[i];
            float[] F = M3.rotX(cylBeta[i]);
            float[] FB = M3.rotX(bankBeta[b]);
            int s = -bankSide[b];
            float hz = halfW;
            float[] pts, radii;
            if (radial) {
                float[] p0 = lp(F, cylX[i], D + B * 0.25f, -B * 0.1f);
                float[] p1 = lp(F, cylX[i] - B * 0.8f, D + B * 0.25f, -B * 0.25f);
                float[] p2 = lp(F, cylX[i] - B * 1.1f, D + B * 0.9f, -B * 0.25f);
                pts = cat(p0, p1, p2);
                radii = new float[]{B * 0.13f};
            } else if (expansion) {
                float[] port = lp(F, cylX[i], D - S * 0.55f, s * B * 0.5f);
                float[] a1 = lp(F, cylX[i], D - S * 0.6f, s * B * 1.1f);
                float[] a2 = lp(FB, cylX[i] + B * 0.2f, -R - B * 1.2f, s * B * 0.9f);
                float[] a3 = lp(FB, cylX[i] + B * 2.6f, -R - B * 1.7f, s * B * 0.75f);
                float[] a4 = lp(FB, cylX[i] + B * 5.0f, -R - B * 1.6f, s * B * 0.7f);
                float[] a5 = lp(FB, cylX[i] + B * 6.6f, -R - B * 1.2f, s * B * 0.7f);
                float[] a6 = lp(FB, cylX[i] + B * 7.6f, -R - B * 0.9f, s * B * 0.7f);
                pts = cat(port, a1, a2, a3, a4, a5, a6);
                radii = new float[]{B * 0.2f, B * 0.24f, B * 0.36f, B * 0.72f, B * 0.72f, B * 0.25f, B * 0.12f};
            } else {
                float[] port = twoStroke && !e.vt.equals("UNI") ? lp(F, cylX[i], D - S * 0.55f, s * B * 0.5f)
                        : e.vt.equals("UNI") ? lp(FB, cylX[i], D + headH, 0)
                        : lp(FB, cylX[i], D + headH * 0.35f, s * (e.vt.equals("SV") ? hz + B * 0.05f : hz));
                if (exs.equals("stubs")) {
                    float[] a1 = lp(FB, cylX[i], D + headH * 0.35f, s * (hz + B * 0.45f));
                    float[] a2 = lp(FB, cylX[i] + B * 0.45f, D + headH * 0.1f, s * (hz + B * 0.75f));
                    pts = cat(port, a1, a2);
                    radii = new float[]{B * 0.15f, B * 0.16f, B * 0.2f};
                } else if (exs.equals("zoomie")) {
                    float[] a1 = lp(FB, cylX[i], D + headH * 0.35f, s * (hz + B * 0.4f));
                    float[] a2 = lp(FB, cylX[i] + B * 0.9f, D + headH + B * 0.9f, s * (hz + B * 0.9f));
                    pts = cat(port, a1, a2);
                    radii = new float[]{B * 0.16f, B * 0.18f, B * 0.24f};
                } else if (exs.equals("top")) {
                    float a = (float) Math.toRadians(e.bank / 2f);
                    float yv = (D + headH) * (float) Math.cos(a) + B * 1.4f;
                    float[] a1 = lp(FB, cylX[i], D + headH * 0.6f, s * (hz + B * 0.3f));
                    float[] a2 = new float[]{cylX[i] + B * 0.3f, yv - B * 0.5f, (b == 0 ? -1 : 1) * B * 0.5f};
                    float[] a3 = new float[]{xMax + P * 0.8f, yv, (b == 0 ? -1 : 1) * B * 0.45f};
                    pts = cat(port, a1, a2, a3);
                    radii = new float[]{B * 0.16f, B * 0.17f, B * 0.2f, B * 0.24f};
                } else if (marine) {
                    float[] a1 = lp(FB, cylX[i], D + headH + B * 0.5f, 0);
                    float[] a2 = lp(FB, cylX[i], D + headH + B * 1.1f, s * B * 0.6f);
                    pts = cat(port, a1, a2);
                    radii = new float[]{B * 0.22f, B * 0.26f, B * 0.3f};
                } else {
                    float[] a1, a2, a3;
                    if (e.hotV && nb == 2) {
                        if (turboIn[b] == null) turboIn[b] = turboIn[1 - b];
                        a1 = lp(FB, cylX[i], D + headH * 0.5f, s * (hz + B * 0.3f));
                        a2 = turboIn[b] != null ? new float[]{cylX[i] * 0.5f + turboIn[b][0] * 0.5f, turboIn[b][1] - B * 0.3f, turboIn[b][2] * 0.6f} : a1;
                        a3 = turboIn[b] != null ? turboIn[b].clone() : a1;
                    } else {
                        a1 = lp(FB, cylX[i], D + headH * 0.25f, s * (hz + B * 0.45f));
                        a2 = lp(FB, cylX[i], D * 0.62f, s * (hz + B * 0.9f));
                        if (turboIn[b] != null) a3 = turboIn[b].clone();
                        else a3 = lp(FB, xMax + P * 0.8f, D * 0.42f, s * (hz + B * 1.1f));
                    }
                    pts = cat(port, a1, a2, a3);
                    radii = new float[]{B * 0.17f, B * 0.17f, B * 0.19f, B * 0.22f};
                }
            }
            Mesh m = new Mesh();
            m.tube(pts, radii, 10, 1f, 0.75f);
            String key = expansion ? "expansion" : (exs.equals("stubs") ? "stub" : "header");
            Part p = add(key, Part.DUCT, e.vt.equals("UNI") ? 0xFF8D7A68 : 0xFFA9764E, m);
            p.cyl = i; p.heat = 1f;
            float[] ex = new float[3];
            M3.applyDir(FB, 0, 0, s * B * 1.8f, ex, 0);
            p.explode = ex;
            exhaustTube[i] = pts;
        }
        boolean tails = !expansion && !radial && !marine && !exs.equals("stubs") && !exs.equals("zoomie") && !exs.equals("top");
        if (tails) {
            for (int b = 0; b < nb; b++) {
                float[] FB = M3.rotX(bankBeta[b]);
                int s = -bankSide[b];
                float[] start = turboIn[b] != null ? turboIn[b] : lp(FB, xMax + P * 0.8f, D * 0.42f, s * (halfW + B * 1.1f));
                float[] mid = new float[]{Math.max(start[0], xMax) + P * 0.6f, start[1] * 0.4f - R, start[2] * 0.8f};
                float[] end = new float[]{Math.max(start[0], xMax) + P * 1.8f, -R - B * 0.9f, start[2] * 0.7f};
                Mesh m = new Mesh();
                m.tube(cat(start, mid, end), new float[]{B * 0.26f}, 12, 0.75f, 0.45f);
                Part p = duct("downpipe", 0xFF8D7A68, m, 0.8f, new float[]{B * 1.6f, 0, 0});
                p.bank = b;
            }
        }
    }

    private void buildTurbo(float[] c, int bank) {
        float tr = B * 0.48f;
        Mesh m = new Mesh();
        m.cyl(c[0] - B * 0.42f, c[1], c[2], 1, 0, 0, tr, B * 0.32f, 18);           // turbine housing
        m.frustum(c[0] - B * 0.1f, c[1], c[2], 1, 0, 0, tr * 0.42f, tr * 0.42f, B * 0.22f, 12, false, false);
        volute(m, c[0] - B * 0.26f, c, tr, B);
        Part tp = add("turbine", Part.DUCT, 0xFF6E6159, m);
        tp.heat = 1f; tp.bank = bank;
        Mesh m2 = new Mesh();
        m2.cyl(c[0] + B * 0.12f, c[1], c[2], 1, 0, 0, tr * 1.1f, B * 0.34f, 18);   // compressor housing
        m2.cyl(c[0] + B * 0.46f, c[1], c[2], 1, 0, 0, tr * 0.5f, B * 0.3f, 12);    // inlet
        volute(m2, c[0] + B * 0.29f, c, tr * 1.1f, B);
        Part cp = add("compressor", Part.DUCT, 0xFFB0B6BD, m2);
        cp.heat = 0.45f; cp.bank = bank;
        float[] ex = new float[]{0, c[1] > 0 ? B * 1.4f : -B * 1.4f, c[2] > 0 ? B * 1.6f : -B * 1.6f};
        tp.explode = ex; cp.explode = ex.clone();
        for (int w = 0; w < 2; w++) {
            Mesh wm = new Mesh();
            float wx = w == 0 ? -B * 0.26f : B * 0.29f;
            float wr = w == 0 ? tr * 0.75f : tr * 0.88f;
            wm.cyl(wx - B * 0.06f, 0, 0, 1, 0, 0, wr * 0.25f, B * 0.16f, 8);
            for (int k = 0; k < 8; k++) {
                float a = 360f * k / 8;
                float[] save = wm.f;
                wm.frame(M3.rotX(a));
                wm.box(wx - B * 0.05f, wr * 0.2f, -B * 0.012f, wx + B * 0.05f, wr, B * 0.012f);
                wm.frame(save);
            }
            Part wp = add(w == 0 ? "turbine_wheel" : "compressor_wheel", Part.MOVING, w == 0 ? 0xFF8E8379 : 0xFFD4D9DE, wm);
            wp.heat = w == 0 ? 1f : 0.4f; wp.bank = bank;
            wp.explode = ex.clone();
            turboWheels.add(wp);
            turboWheelPivot.add(c);
        }
        if (e.turbos > 0 && !e.diesel() || true) {
            // boost pipe: compressor -> front -> plenum/throttle
            float[] a = new float[]{c[0] + B * 0.75f, c[1], c[2]};
            String icp = e.ic.isEmpty() ? "front" : e.ic;
            float[] dst = icInlet != null ? icInlet : new float[]{xMin - P * 0.9f, Math.max(c[1], D * 0.9f), 0};
            float[] b = icp.equals("top") ? new float[]{(c[0] + dst[0]) / 2f, Math.max(c[1], dst[1]) + B * 0.5f, c[2] * 0.5f}
                    : new float[]{xMin - P * 0.9f, c[1] * 0.5f, c[2] * 0.6f};
            float[] d = dst;
            Mesh pm = new Mesh();
            pm.tube(cat(a, b, d), new float[]{B * 0.17f}, 10, 0.45f, 0.3f);
            Part p = add("boostpipe", Part.DUCT, 0xFF5E646C, pm);
            p.heat = 0.4f;
            p.explode = new float[]{-B * 1.2f, 0, 0};
            float[][] nbt = java.util.Arrays.copyOf(boostTube, boostTube.length + 1);
            nbt[boostTube.length] = cat(new float[]{c[0] + B * 1.0f, c[1], c[2]}, a, b, d);
            boostTube = nbt;
        }
    }

    /** Snail-shaped scroll around a turbo housing (axis along X). */
    private static void volute(Mesh m, float x, float[] c, float r, float B) {
        int k = 22;
        float[] pts = new float[(k + 2) * 3];
        float[] rad = new float[k + 2];
        for (int i = 0; i <= k; i++) {
            float t = (float) i / k;
            double a = Math.toRadians(-60 + 320 * t);
            float rr = r * (0.95f + 0.35f * t);
            pts[i * 3] = x; pts[i * 3 + 1] = c[1] + (float) Math.cos(a) * rr; pts[i * 3 + 2] = c[2] + (float) Math.sin(a) * rr;
            rad[i] = B * (0.07f + 0.13f * t);
        }
        double a = Math.toRadians(260);
        pts[(k + 1) * 3] = x; pts[(k + 1) * 3 + 1] = pts[k * 3 + 1] + (float) Math.cos(a + Math.PI / 2) * r * 0.9f; pts[(k + 1) * 3 + 2] = pts[k * 3 + 2] + (float) Math.sin(a + Math.PI / 2) * r * 0.9f;
        rad[k + 1] = B * 0.2f;
        m.tube(pts, rad, 10, m.heat, m.heat);
    }

    private void buildAncillaries() {
        if (radial) return;
        // intercooler for turbo road engines
        String icp = e.ic.isEmpty() ? ((e.turbos > 0 && e.cc < 20000) ? "front" : "none") : e.ic;
        if ((e.turbos > 0 || e.sc) && icp.equals("front")) {
            Mesh m = new Mesh();
            float w = Math.max(halfW * 2.2f, B * 2.2f);
            m.box(xMin - P * 1.15f, -R, -w / 2f, xMin - P * 1.0f, D * 0.55f, w / 2f);
            Part p = add("intercooler", Part.DUCT, 0xFF3E434A, m);
            p.heat = 0.3f; p.explode = new float[]{-B * 2.2f, 0, 0};
        } else if (icp.equals("top")) {
            Mesh m = new Mesh();
            float yb;
            if (veeLayout() || e.hotV) {
                float a = (float) Math.toRadians(e.bank / 2f);
                yb = (D + headH) * (float) Math.cos(a) + B * (e.sc ? 1.75f : 0.95f);
                if (e.layout.equals("F")) yb = D * 0.5f + B * 1.1f;
                for (int k = -1; k <= 1; k += 2) {
                    if (!e.sc && !e.hotV && k == 1 && e.turbos == 0) continue;
                    m.box(xMin - P * 0.2f, yb, k < 0 ? -halfW * 1.1f : B * 0.08f, xMax + P * 0.2f, yb + B * 0.32f, k < 0 ? -B * 0.08f : halfW * 1.1f);
                }
            } else {
                float[] FB = M3.rotX(bankBeta[0]);
                m.frame(FB);
                yb = D + headH + B * 0.45f;
                if (e.layout.equals("F")) { m.frame(M3.id()); yb = Math.max(B * 1.2f, D * 0.4f); }
                m.box(xMin - P * 0.3f, yb, -halfW * 1.2f, xMax + P * 0.3f, yb + B * 0.3f, halfW * 1.2f);
            }
            Part p = add("intercooler", Part.DUCT, 0xFF3E434A, m);
            p.heat = 0.3f; p.explode = new float[]{0, B * 3.6f, 0};
        }
        if (e.fan.equals("shroud")) {
            Mesh m = new Mesh();
            float zw = e.layout.equals("F") ? (D + headH) * 0.95f : halfW * 1.4f;
            float yb = e.layout.equals("F") ? B * 0.55f : D + headH + B * 0.2f;
            m.box(xMin - P * 0.55f, yb, -zw, xMax + P * 0.55f, yb + B * 0.9f, zw);
            Part p = add("shroud", Part.SHELL, 0xFF26292E, m);
            p.half = 2; p.heat = 0.3f; p.explode = new float[]{0, B * 3.0f, 0};
            Mesh f = new Mesh();
            float fx = xMin - P * 0.9f, fy = yb + B * 0.45f;
            f.cyl(fx, 0, 0, 1, 0, 0, B * 0.12f, B * 0.25f, 10);
            for (int k = 0; k < 9; k++) {
                float[] sv = f.f;
                f.frame(M3.rotX(40f * k));
                f.box(fx, B * 0.1f, -B * 0.03f, fx + B * 0.22f, B * 0.85f, B * 0.03f);
                f.frame(sv);
            }
            Part fp = add("fan", Part.MOVING, 0xFF3A3F46, f);
            fp.explode = new float[]{-B * 1.6f, B * 3.0f, 0};
            scRotors.add(fp); scRotorSpeed.add(1.8f); scRotorPivot.add(new float[]{0, fy, 0});
        } else if (e.fan.equals("front")) {
            Mesh f = new Mesh();
            float fx = xMin - P * 1.15f;
            f.cyl(fx, 0, 0, 1, 0, 0, B * 0.15f, B * 0.25f, 10);
            for (int k = 0; k < 8; k++) {
                float[] sv = f.f;
                f.frame(M3.rotX(45f * k));
                f.box(fx, B * 0.1f, -B * 0.03f, fx + B * 0.22f, B * 1.15f, B * 0.03f);
                f.frame(sv);
            }
            Part fp = add("fan", Part.MOVING, 0xFF3A3F46, f);
            fp.explode = new float[]{-B * 2f, 0, 0};
            scRotors.add(fp); scRotorSpeed.add(1f); scRotorPivot.add(new float[]{0, 0, 0});
        }
        if (!airCooled) {
            Mesh m = new Mesh();
            m.cyl(xMin - P * 0.85f, R * 0.6f + B * 0.4f, B * 0.45f, 1, 0, 0, B * 0.24f, B * 0.2f, 14);
            Part p = add("waterpump", Part.MISC, 0xFF8F959D, m);
            p.heat = 0.45f; p.explode = new float[]{-B * 1.6f, 0, 0};
        }
        Mesh of = new Mesh();
        of.cyl(xMin + P * 0.2f, -R * 0.2f, -(R + B * 0.42f), 0, 0, -1, B * 0.2f, B * 0.32f, 14);
        Part ofp = add("oilfilter", Part.MISC, 0xFF2F4D7A, of);
        ofp.heat = 0.4f; ofp.half = 2;
    }

    private void buildWankel() {
        n = e.cyl;
        cycle = 360;
        float perRotor = e.cc / n;
        float k = (float) Math.cbrt(perRotor / 654f);
        float Rg = 0.105f * k, ecc = 0.015f * k, w = 0.08f * k;
        B = Rg; S = ecc * 2; R = ecc; L = 0; D = Rg; P = w + 0.04f * k; headH = 0;
        cylX = new float[n]; cylBeta = new float[n]; cylPhase = new float[n]; cylBank = new int[n];
        bankBeta = new float[]{0}; bankSide = new int[]{-1};
        rotors = new Part[n];
        pistons = new Part[0]; rods = new Part[0]; charges = new Part[0];
        int seg = 72;
        float[] housing = new float[seg * 2], rotor = new float[36 * 2];
        for (int i = 0; i < seg; i++) {
            double a = 2 * Math.PI * i / seg;
            float x = (float) (ecc * Math.cos(3 * a) + Rg * Math.cos(a)), y = (float) (ecc * Math.sin(3 * a) + Rg * Math.sin(a));
            housing[i * 2] = x * 1.32f; housing[i * 2 + 1] = y * 1.32f;
        }
        for (int i = 0; i < 36; i++) {
            int side = i / 12;
            float t = (i % 12) / 12f;
            double a0 = 2 * Math.PI * side / 3, a1 = 2 * Math.PI * (side + 1) / 3;
            float x0 = (float) Math.cos(a0) * Rg * 0.97f, y0 = (float) Math.sin(a0) * Rg * 0.97f;
            float x1 = (float) Math.cos(a1) * Rg * 0.97f, y1 = (float) Math.sin(a1) * Rg * 0.97f;
            float mx = x0 + (x1 - x0) * t, my = y0 + (y1 - y0) * t;
            float bulge = (float) Math.sin(Math.PI * t) * Rg * 0.18f;
            double am = (a0 + a1) / 2;
            rotor[i * 2] = mx + (float) Math.cos(am) * bulge;
            rotor[i * 2 + 1] = my + (float) Math.sin(am) * bulge;
        }
        for (int r = 0; r < n; r++) {
            float x = r * P;
            cylX[r] = x;
            cylPhase[r] = mod(-r * 360f / n, 360);
            Mesh hm = new Mesh();
            hm.prism(x, 0, 0, housing, 1, 0, 0, w);
            Part hp = add("rotor_housing", Part.SHELL, 0xFF8C939C, hm);
            hp.half = 2; hp.heat = 0.6f; hp.cyl = r;
            Mesh sp = new Mesh();
            sp.cyl(x - 0.02f * k, 0, 0, 1, 0, 0, Rg * 1.45f, 0.02f * k, 32);
            Part spp = add("side_housing", Part.SHELL, 0xFF6E757D, sp);
            spp.half = 2; spp.heat = 0.5f;
            Mesh rm = new Mesh();
            rm.prism(0, 0, 0, rotor, 1, 0, 0, w * 0.94f);
            Part rp = add("rotor", Part.MOVING, 0xFFB7BDC4, rm);
            rp.cyl = r; rp.heat = 0.75f;
            rotors[r] = rp;
            // plugs: two on the trailing side
            for (int pl = 0; pl < 2; pl++) {
                Mesh pm = new Mesh();
                float zz = -Rg * 1.25f, yy = (pl == 0 ? -0.18f : 0.18f) * Rg;
                pm.cyl(x + w / 2f, yy, zz, 0, 0, -1, 0.006f * k, 0.05f * k, 8);
                Part pp = add("plug", Part.MISC, 0xFFE4E6EA, pm);
                pp.cyl = r;
            }
        }
        Mesh es = new Mesh();
        es.cyl(-P * 0.6f, 0, 0, 1, 0, 0, 0.022f * k, P * (n + 0.2f), 14);
        for (int r = 0; r < n; r++) {
            float[] save = es.f;
            es.frame(M3.rotX(cylPhase[r]));
            es.cyl(r * P + 0.005f, 0, ecc, 1, 0, 0, 0.045f * k, w * 0.9f, 18);
            es.frame(save);
        }
        Part ep = add("eshaft", Part.MOVING, 0xFF7D838B, es);
        spinners.add(ep);
        Mesh fw = new Mesh();
        fw.cyl((n - 1) * P + w + 0.06f * k, 0, 0, 1, 0, 0, Rg * 1.25f, 0.03f * k, 28);
        Part fp = add("flywheel", Part.MOVING, 0xFF6F757D, fw);
        spinners.add(fp);
        xMin = 0; xMax = (n - 1) * P + w;
        // intake + exhaust per rotor
        intakeTube = new float[n][];
        exhaustTube = new float[n][];
        for (int r = 0; r < n; r++) {
            float x = r * P + w / 2f;
            float[] in = cat(new float[]{x, Rg * 2.4f, Rg * 0.9f}, new float[]{x, Rg * 1.6f, Rg * 0.7f}, new float[]{x, Rg * 0.8f, Rg * 0.35f});
            Mesh im = new Mesh();
            im.tube(in, new float[]{0.018f * k}, 10, 0.2f, 0.2f);
            Part ip = add("runner", Part.DUCT, 0xFF5A6068, im);
            ip.heat = 0.2f; ip.cyl = r;
            intakeTube[r] = in;
            float[] ex = cat(new float[]{x, -Rg * 0.2f, Rg * 1.15f}, new float[]{x, -Rg * 0.8f, Rg * 1.9f}, new float[]{x + 0.12f * k, -Rg * 1.6f, Rg * 2.0f}, new float[]{xMax + 0.3f * k, -Rg * 1.9f, Rg * 1.6f});
            Mesh xm = new Mesh();
            xm.tube(ex, new float[]{0.02f * k}, 10, 1f, 0.7f);
            Part xp = add("header", Part.DUCT, 0xFFA9764E, xm);
            xp.heat = 1f; xp.cyl = r;
            exhaustTube[r] = ex;
        }
        if (e.turbos > 0) {
            buildTurbo(new float[]{xMax * 0.5f, -Rg * 1.6f, Rg * 2.3f}, 0);
        }
        flowsWankel();
    }

    private void buildFigure() {
        float H = 1.75f;
        float gx = (xMin + xMax) / 2f;
        Mesh m = new Mesh();
        float floor = 0; // set after bounds
        m.cyl(0, 0, -0.09f, 0, 1, 0, 0.065f, 0.82f, 10);
        m.cyl(0, 0, 0.09f, 0, 1, 0, 0.065f, 0.82f, 10);
        m.frustum(0, 0.8f, 0, 0, 1, 0, 0.17f, 0.2f, 0.62f, 12, true, true);
        m.cyl(0, 0.84f, -0.26f, 0, 1, 0, 0.045f, 0.6f, 8);
        m.cyl(0, 0.84f, 0.26f, 0, 1, 0, 0.045f, 0.6f, 8);
        m.sphere(0, H - 0.12f, 0, 0.12f, 12);
        figure = add("figure", Part.FIGURE, 0xFF6E86A8, m);
        figure.visible = false;
        figure.center[0] = gx;
    }

    private void finishBounds() {
        float[] mn = {1e9f, 1e9f, 1e9f}, mx = {-1e9f, -1e9f, -1e9f};
        for (Part p : parts) {
            if (p.kind == Part.FIGURE || p.kind == Part.CHARGE) continue;
            float[] b = p.mesh.bounds();
            for (int k = 0; k < 3; k++) { mn[k] = Math.min(mn[k], b[k]); mx[k] = Math.max(mx[k], b[k + 3]); }
        }
        for (int k = 0; k < 3; k++) center[k] = (mn[k] + mx[k]) / 2f;
        float dx = mx[0] - mn[0], dy = mx[1] - mn[1], dz = mx[2] - mn[2];
        radius = 0.5f * (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        yMin = mn[1]; yMax = mx[1];
        // put the figure on the floor next to the engine
        figure.mat = M3.trans(center[0], mn[1], mn[2] - 0.45f - Math.max(0.1f, radius * 0.05f));
        dims = new float[]{dx, dy, dz};
    }

    public float[] dims;

    // ------------------------------------------------------------------ flows

    private Flow flow(int type, float[] pts, int count, float size) {
        Flow f = new Flow();
        f.type = type; f.pts = pts; f.size = size;
        int npt = pts.length / 3;
        f.cum = new float[npt];
        for (int i = 1; i < npt; i++) {
            float dx = pts[i * 3] - pts[i * 3 - 3], dy = pts[i * 3 + 1] - pts[i * 3 - 2], dz = pts[i * 3 + 2] - pts[i * 3 - 1];
            f.cum[i] = f.cum[i - 1] + (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        }
        f.total = Math.max(1e-6f, f.cum[npt - 1]);
        f.s = new float[count];
        for (int i = 0; i < count; i++) f.s[i] = (float) i / count;
        flows.add(f);
        return f;
    }

    private void buildFlows() {
        float sz = B * 0.07f;
        for (int i = 0; i < n; i++) {
            float[] F = M3.rotX(cylBeta[i]);
            float[] chamber = lp(F, cylX[i], D - B * 0.15f, 0);
            float[] inT = intakeTube[i];
            float[] pin = java.util.Arrays.copyOf(inT, inT.length + 3);
            System.arraycopy(chamber, 0, pin, inT.length, 3);
            Flow f = flow(F_AIR, pin, 10, sz);
            f.cyl = i; f.gate = twoStroke && !e.vt.equals("UNI") ? 5 : 1;
            float[] exT = exhaustTube[i];
            float[] pex = new float[exT.length + 3];
            System.arraycopy(chamber, 0, pex, 0, 3);
            System.arraycopy(exT, 0, pex, 3, exT.length);
            Flow g = flow(F_EXH, pex, 12, sz * 1.15f);
            g.cyl = i; g.gate = twoStroke && !e.vt.equals("UNI") ? 4 : 2;
            if (twoStroke && !e.vt.equals("UNI")) {
                // transfer: crankcase -> transfer port -> cylinder
                float[] tr = cat(lp(F, cylX[i], 0, -bankSide[cylBank[i]] * B * 0.2f), lp(F, cylX[i], R + L * 0.6f, -bankSide[cylBank[i]] * B * 0.55f), lp(F, cylX[i], D - S * 0.75f, 0), chamber);
                Flow t = flow(F_MIX, tr, 8, sz);
                t.cyl = i; t.gate = 3;
            }
            if (e.diesel() || e.year > 1995 && !twoStroke) {
                // fuel to injector
                float[] tip = lp(F, cylX[i], D + (e.diesel() ? 0 : headH * 0.4f), e.diesel() ? 0 : bankSide[cylBank[i]] * halfW * 0.7f);
                float[] rail = lp(F, cylX[i], D + headH * 0.9f, bankSide[cylBank[i]] * halfW * 0.9f);
                Flow fu = flow(F_FUEL, cat(rail, tip), 3, sz * 0.8f);
                fu.cyl = i; fu.gate = 1;
            }
        }
        for (float[] bt : boostTube) flow(F_BOOST, bt, 14, sz * 1.1f);
        // oil loop
        float cz = R + B * 0.42f;
        float yb = radial ? 0 : -(R + B * 0.38f) - B * 0.3f;
        float[] oil;
        if (radial) {
            oil = cat(new float[]{xMin - B, 0, R * 0.5f}, new float[]{xMax + B * 0.3f, 0, R * 0.5f}, new float[]{xMax + B * 0.3f, R * 1.4f, 0}, new float[]{xMin - B, R * 1.4f, 0}, new float[]{xMin - B, 0, R * 0.5f});
        } else {
            float headTop = D + headH * 0.7f;
            float[] FB = M3.rotX(bankBeta[0]);
            oil = cat(new float[]{xMax, yb, 0}, new float[]{xMin - P * 0.3f, yb, 0}, new float[]{xMin - P * 0.3f, 0, cz * 0.8f},
                    new float[]{xMax, 0, cz * 0.8f}, lp(FB, xMax, D * 0.6f, halfW * 0.8f), lp(FB, xMax, headTop, 0), lp(FB, xMin, headTop, 0),
                    lp(FB, xMin - P * 0.35f, D * 0.5f, 0), new float[]{xMin - P * 0.35f, yb * 0.5f, 0}, new float[]{xMax, yb, 0});
        }
        Flow of = flow(F_OIL, oil, 26, sz);
        of.speed = 0.6f;
        if (bankBeta.length == 2 && !radial) {
            float[] FB = M3.rotX(bankBeta[1]);
            float headTop = D + headH * 0.7f;
            Flow o2 = flow(F_OIL, cat(new float[]{xMin, 0, -cz * 0.8f}, lp(FB, xMin, D * 0.6f, 0), lp(FB, xMin, headTop, 0), lp(FB, xMax, headTop, 0), lp(FB, xMax, D * 0.5f, 0), new float[]{xMax, yb, 0}), 14, sz);
            o2.speed = 0.6f;
        }
        // coolant or cooling air
        if (airCooled || radial) {
            for (int b = 0; b < Math.min(bankBeta.length, radial ? 0 : 3); b++) {
                float[] FB = M3.rotX(bankBeta[b]);
                for (int k = 0; k < 3; k++) {
                    float y = R + L * 0.5f + (D - R - L * 0.5f) * k / 2f;
                    Flow ca = flow(F_COOLAIR, cat(lp(FB, xMin - P * 1.2f, y, B * 0.3f), lp(FB, xMax + P * 1.2f, y, -B * 0.3f)), 8, sz * 0.9f);
                    ca.speed = 1.4f;
                }
            }
            if (radial) {
                for (int k = 0; k < 10; k++) {
                    double a = 2 * Math.PI * k / 10;
                    float rr = D * 0.95f;
                    Flow ca = flow(F_COOLAIR, cat(new float[]{xMin - B * 2.5f, (float) Math.cos(a) * rr, (float) Math.sin(a) * rr}, new float[]{xMax - B * 2.5f - (e.rows) * B * 2.1f, (float) Math.cos(a) * rr, (float) Math.sin(a) * rr}), 6, sz * 1.3f);
                    ca.speed = 1.6f;
                }
            }
        } else {
            for (int b = 0; b < bankBeta.length; b++) {
                float[] FB = M3.rotX(bankBeta[b]);
                float y0 = R + B * 0.5f, y1 = D - B * 0.1f;
                float z = halfW * 0.82f;
                float[] pts = cat(new float[]{xMin - P * 0.85f, R * 0.6f + B * 0.4f, B * 0.45f}, lp(FB, xMin - P * 0.4f, y0, z), lp(FB, xMax + P * 0.3f, y0, z), lp(FB, xMax + P * 0.3f, y1, -z),
                        lp(FB, xMin, y1, -z), lp(FB, xMin, D + headH * 0.3f, z * 0.6f), lp(FB, xMax, D + headH * 0.35f, z * 0.6f), lp(FB, xMax + P * 0.2f, D + headH * 0.35f, -z * 0.3f), lp(FB, xMin - P * 0.6f, D + headH * 0.4f, 0));
                Flow c = flow(F_COOL, pts, 22, sz);
                c.speed = 0.7f;
            }
        }
    }

    private void flowsWankel() {
        float sz = B * 0.05f;
        for (int r = 0; r < n; r++) {
            Flow f = flow(F_AIR, intakeTube[r], 10, sz);
            f.cyl = r; f.gate = 0;
            Flow g = flow(F_EXH, exhaustTube[r], 12, sz * 1.1f);
            g.cyl = r; g.gate = 0;
        }
        for (float[] bt : boostTube) flow(F_BOOST, bt, 12, sz);
        float x0 = -P * 0.5f, x1 = xMax + P * 0.3f;
        Flow c = flow(F_COOL, cat(new float[]{x0, B * 1.2f, 0}, new float[]{x1, B * 1.2f, 0}, new float[]{x1, -B * 1.2f, 0}, new float[]{x0, -B * 1.2f, 0}, new float[]{x0, B * 1.2f, 0}), 24, sz);
        c.speed = 0.7f;
        Flow o = flow(F_OIL, cat(new float[]{x0, 0, B * 0.15f}, new float[]{x1, 0, B * 0.15f}, new float[]{x1, -B * 0.5f, 0}, new float[]{x0, -B * 0.5f, 0}, new float[]{x0, 0, B * 0.15f}), 16, sz);
        o.speed = 0.5f;
    }

    // ------------------------------------------------------------------ animation

    private final float[] tmpA = new float[12], tmpB = new float[12];

    public float pistonY(float a) {
        double r = Math.toRadians(a);
        double s = Math.sin(r);
        return (float) (R * Math.cos(r) + Math.sqrt(L * L - R * R * s * s));
    }

    /** Valve lift 0..1 for a cylinder at local cycle angle (0 = firing TDC). */
    public static float lift(float a, boolean intake, int cycle) {
        if (cycle == 360) {
            if (intake) return 0;
            return window(a, 80, 280);
        }
        if (intake) return window(a, 340, 580);
        return window(a, 140, 380);
    }

    static float window(float a, float open, float close) {
        float span = close - open;
        float x = a - open;
        if (x < 0) x += 720;
        if (x > span) { x -= 720; if (x < 0 || x > span) return 0; }
        return (float) Math.sin(Math.PI * x / span);
    }

    public float cycleAngle(int cyl) { return mod(theta + cylPhase[cyl], cycle); }

    public static String strokeName(float a, boolean two) {
        if (two) {
            if (a < 100) return "Power";
            if (a < 130) return "Exhaust";
            if (a < 240) return "Scavenge";
            if (a < 265) return "Exhaust";
            return "Compression";
        }
        if (a < 180) return "Power";
        if (a < 360) return "Exhaust";
        if (a < 540) return "Intake";
        return "Compression";
    }

    public int chargeColor(int cyl) {
        float a = cycleAngle(cyl);
        boolean diesel = e.diesel();
        if (twoStroke) {
            if (a < 95) return lerpColor(0xFFFFF1B0, 0xFFFF6A1A, a / 95f);
            if (a < 130) return lerpColor(0xFFFF6A1A, 0xFF8C7A70, (a - 95) / 35f);
            if (a < 260) return lerpColor(0xFF8C7A70, 0xFF6FA8FF, (a - 130) / 130f);
            return lerpColor(0xFF6FA8FF, 0xFFB08CFF, (a - 260) / 100f);
        }
        if (a < 180) return lerpColor(diesel ? 0xFFFFC870 : 0xFFFFF4C0, 0xFFFF4A10, Math.min(1f, a / 120f));
        if (a < 360) return lerpColor(0xFFB0603A, 0xFF6B625E, (a - 180) / 180f);
        if (a < 540) return lerpColor(0xFF4C6E9A, diesel ? 0xFF9AD2FF : 0xFF5FA4FF, (a - 360) / 180f);
        return lerpColor(diesel ? 0xFF9AD2FF : 0xFF5FA4FF, diesel ? 0xFFE6F4FF : 0xFFB48CFF, (a - 540) / 180f);
    }

    public static int lerpColor(int a, int b, float t) {
        t = Math.max(0, Math.min(1, t));
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return 0xFF000000 | ((int) (ar + (br - ar) * t) << 16) | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }

    // scratch matrices (no allocation per frame)
    private final float[] spinMat = M3.id(), propMat = M3.id(), mA = new float[12], mB = new float[12], mC = new float[12];
    private float[][] cylF;
    private final float[] spt = new float[3];

    public void update(float thetaDeg, float rpm, float load, float dtSim) {
        float dTheta = thetaDeg - theta;
        theta = thetaDeg;
        this.rpm = rpm;
        this.load = load;
        if (cylF == null) {
            cylF = new float[n][];
            for (int i = 0; i < n; i++) cylF[i] = M3.rotX(cylBeta[i]);
            for (Part p : spinners) p.mat = p.key.equals("prop") ? propMat : spinMat;
        }
        M3.rotXT(theta, 0, 0, 0, spinMat);
        M3.rotXT(theta * 0.5f, 0, 0, 0, propMat);
        sparks.clear();
        boolean portOrUni = e.vt.equals("PORT") || e.vt.equals("UNI");
        boolean uni = e.vt.equals("UNI");
        if (wankel) {
            float Rg = B;
            for (int r = 0; r < n; r++) {
                float th = theta + cylPhase[r];
                double tr = Math.toRadians(th);
                M3.rotXT(th / 3f, cylX[r], -(float) Math.sin(tr) * R, (float) Math.cos(tr) * R, rotors[r].mat);
                float a = mod(th, 360);
                if (a > 350 || a < 12) sparks.add(new float[]{cylX[r] + 0.04f, 0, -Rg * 1.15f, 1f - Math.abs(a > 180 ? a - 360 : a) / 12f});
            }
        } else {
            float top = D + (portOrUni ? B * 0.02f : B * 0.12f);
            float rr = B * 0.47f;
            for (int i = 0; i < n; i++) {
                float a = theta + cylPhase[i];
                float y = pistonY(a);
                float[] F = cylF[i];
                M3.mul(F, M3.transInto(cylX[i], y, 0, mA), pistons[i].mat);
                double ar = Math.toRadians(a);
                float cy = R * (float) Math.cos(ar), cz = R * (float) Math.sin(ar);
                float psi = (float) Math.toDegrees(Math.atan2(-cz, y - cy));
                M3.mul(F, M3.rotXT(psi, cylX[i], cy, cz, mA), rods[i].mat);
                float crown = y + CH;
                float hh = Math.max(0.001f, top - crown);
                M3.set(mA, rr, 0, 0, cylX[i], 0, hh, 0, crown, 0, 0, rr, 0);
                M3.mul(F, mA, charges[i].mat);
                charges[i].color = chargeColor(i);
                float ca = cycleAngle(i);
                if (!e.diesel() && (ca > 352 || ca < 14)) {
                    M3.apply(F, cylX[i], D - B * 0.02f, 0, spt, 0);
                    float d = ca > 180 ? ca - 360 : ca;
                    sparks.add(new float[]{spt[0], spt[1], spt[2], 1f - Math.abs(d - 2) / 14f});
                } else if (e.diesel() && (ca > 350 || ca < 20)) {
                    M3.apply(F, cylX[i], D - B * 0.05f, 0, spt, 0);
                    sparks.add(new float[]{spt[0], spt[1], spt[2], 0.6f});
                }
            }
            for (Valve v : valves) {
                float ca = cycleAngle(v.cyl);
                float l = uni ? window(ca, 100, 260) * v.maxLift : ((cycle == 360) ? 0 : lift(ca, v.intake, cycle) * v.maxLift);
                float[] m = v.p.mat;
                System.arraycopy(v.base, 0, m, 0, 12);
                m[3] -= v.axis[0] * l; m[7] -= v.axis[1] * l; m[11] -= v.axis[2] * l;
                if (v.pushrod != null) {
                    float[] pm = v.pushrod.mat;
                    System.arraycopy(v.pushBase, 0, pm, 0, 12);
                    pm[3] += v.pushAxis[0] * l; pm[7] += v.pushAxis[1] * l; pm[11] += v.pushAxis[2] * l;
                }
            }
            boolean free = e.vt.equals("FREE");
            for (Cam c : cams) {
                if (free) { if (c.p.mat != c.base) c.p.mat = c.base; }
                else M3.mul(c.base, M3.rotXT(theta / 2f, 0, 0, 0, mA), c.p.mat);
            }
        }
        for (int i = 0; i < scRotors.size(); i++) {
            float[] pv = scRotorPivot.get(i);
            M3.rotXT(theta * scRotorSpeed.get(i), pv[0], pv[1], pv[2], scRotors.get(i).mat);
        }
        // turbo wheels spin with exhaust energy
        float tw = (rpm / Math.max(1, e.redline)) * (0.3f + load) * 2400f;
        for (int i = 0; i < turboWheels.size(); i++) {
            Part p = turboWheels.get(i);
            float[] c = turboWheelPivot.get(i);
            p.rotSpeed = (p.rotSpeed + tw * dtSim) % 360000f;
            M3.rotXT(p.rotSpeed, c[0], c[1], c[2], p.mat);
        }
        updateFlows(dTheta, dtSim);
    }

    private void updateFlows(float dTheta, float dt) {
        int total = 0;
        for (Flow f : flows) total += f.s.length;
        total += sparks.size() * 6;
        if (px.length < total) {
            px = new float[total]; py = new float[total]; pz = new float[total]; pc = new int[total]; ps = new float[total]; pt = new int[total];
        }
        np = 0;
        float revs = Math.abs(dTheta) / 360f;
        for (Flow f : flows) {
            float gateV = 1f;
            if (f.cyl >= 0 && !wankel) {
                float ca = cycleAngle(f.cyl);
                switch (f.gate) {
                    case 1: gateV = lift(ca, true, cycle); break;
                    case 2: gateV = e.vt.equals("UNI") ? window(ca, 100, 260) : lift(ca, false, cycle); break;
                    case 3: gateV = window(ca, 120, 240); break;
                    case 4: gateV = window(ca, 95, 265); break;
                    case 5: gateV = window(ca, 250, 470); break;
                }
                if (f.type == F_FUEL) gateV = e.diesel() ? window(ca, 690, 740) * 2f : lift(ca, true, cycle);
            }
            float step = revs * f.speed * (f.cyl >= 0 ? 1.6f * gateV : 0.9f);
            int npt = f.pts.length / 3;
            for (int k = 0; k < f.s.length; k++) {
                f.s[k] += step;
                if (f.s[k] >= 1f) f.s[k] -= (float) Math.floor(f.s[k]);
                float d = f.s[k] * f.total;
                int i = 1;
                while (i < npt - 1 && f.cum[i] < d) i++;
                float seg = f.cum[i] - f.cum[i - 1];
                float t = seg > 0 ? (d - f.cum[i - 1]) / seg : 0;
                t = Math.max(0, Math.min(1, t));
                px[np] = f.pts[(i - 1) * 3] + (f.pts[i * 3] - f.pts[(i - 1) * 3]) * t;
                py[np] = f.pts[(i - 1) * 3 + 1] + (f.pts[i * 3 + 1] - f.pts[(i - 1) * 3 + 1]) * t;
                pz[np] = f.pts[(i - 1) * 3 + 2] + (f.pts[i * 3 + 2] - f.pts[(i - 1) * 3 + 2]) * t;
                int col = FLOW_COLOR[f.type];
                if (f.type == F_EXH) col = lerpColor(0xFFFFB060, 0xFF8A8580, f.s[k]);
                float alpha = f.cyl >= 0 ? Math.max(0.25f, Math.min(1f, gateV * 1.5f + 0.2f)) : 1f;
                pc[np] = (col & 0xFFFFFF) | ((int) (alpha * 255) << 24);
                ps[np] = f.size;
                pt[np] = f.type;
                np++;
            }
        }
    }

    public int flowTypesPresent() {
        int mask = 0;
        for (Flow f : flows) mask |= 1 << f.type;
        return mask;
    }

    public Part partById(int id) { return id >= 0 && id < parts.size() ? parts.get(id) : null; }
}

package com.redline.core;

/** A full-surface custom view: drawn with Gfx, fed with per-pointer touch events. */
public interface Painter {
    int DOWN = 0, MOVE = 1, UP = 2, CANCEL = 3;

    void paint(Gfx g, float w, float h, float dt);

    void touch(int action, int id, float x, float y);

    /** True while the view needs continuous redraws. */
    boolean animating();
}

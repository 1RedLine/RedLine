package com.redline.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;

/** Interactive 3D engine view: orbit, zoom, tap parts, view modes, labels, fluids and ray-traced photo mode. */
public final class EngineViewer implements Painter {
    public final EngineModel model;
    public final Raster ras = new Raster();
    public float rpm, load = 0.3f;
    public float slow = 1f / 60f;       // display speed factor (1/60 = 60x slow motion)
    public boolean autoRotate = true, labels = false, paused, showInfo = true;
    public float quality = 1.0f;        // render scale (user setting: 0.35 .. 1.5)
    public static float targetHz = 60f;
    private long lastSig;
    private float lastTheta = Float.NaN;
    private boolean forceRender = true;
    public int mode = Raster.SOLID;
    public boolean photo;
    public String selKey;
    public int selCyl = -1;
    public String[] info;
    public boolean compact;            // smaller overlays when embedded
    public Runnable onSelect;
    float theta;
    float explodeTarget;
    // view rect
    float vx, vy, vw, vh;
    // touch state
    private final HashMap<Integer, float[]> ptr = new HashMap<>();
    private float downX, downY;
    private long downT;
    private boolean moved;
    private float pinchD;
    private float idleSpin;
    private float[] closeRect, legendRect;
    private final float[][] flowRects = new float[8][];

    // photo mode
    private RayTracer rt;
    private Thread rtThread;
    private volatile int[] rtImage;
    private volatile int rtW, rtH, rtSamples;
    private volatile boolean rtDirty;
    public int photoTarget = 96;

    public EngineViewer(Engine e) {
        model = new EngineModel(e);
        rpm = e.idle;
        ras.mode = mode;
        ras.fit(model);
    }

    public void setMode(int m) {
        mode = m;
        ras.mode = m;
        explodeTarget = m == Raster.EXPLODED ? 1f : 0f;
        model.figure.visible = m == Raster.SCALE;
        ras.fit(model);
        restartPhoto();
    }

    public void setPhoto(boolean on) {
        photo = on;
        if (on) restartPhoto(); else stopPhoto();
    }

    public void resetView() {
        ras.yaw = 52; ras.pitch = 24;
        ras.fit(model);
        restartPhoto();
    }

    @Override public boolean animating() { return true; }

    public void dispose() { stopPhoto(); if (rt != null) rt.shutdown(); }

    // ------------------------------------------------------------ photo (ray tracing)

    private void stopPhoto() {
        if (rt != null) rt.cancel = true;
        Thread t = rtThread;
        rtThread = null;
        if (t != null) { try { t.join(400); } catch (InterruptedException ignored) { } }
        if (rt != null) rt.cancel = false;
    }

    private void restartPhoto() {
        if (!photo) return;
        stopPhoto();
        rtDirty = true;
    }

    private void startPhotoIfNeeded() {
        if (!photo || !rtDirty || vw < 8 || vh < 8) return;
        rtDirty = false;
        if (rt == null) rt = new RayTracer();
        final int w = Math.max(16, (int) (vw * (mode == Raster.XRAY || mode == Raster.FLOW || mode == Raster.THERMAL ? 0.4f : 0.55f)));
        final int h = Math.max(16, (int) (vh * w / vw));
        final Raster cam = new Raster();
        cam.resize(w, h);
        cam.yaw = ras.yaw; cam.pitch = ras.pitch; cam.dist = ras.dist; cam.fov = ras.fov;
        System.arraycopy(ras.target, 0, cam.target, 0, 3);
        cam.mode = mode; cam.explodeT = ras.explodeT; cam.selKey = selKey; cam.heatScale = ras.heatScale;
        rt.cancel = false;
        rt.setup(model, cam, w, h);
        rtSamples = 0;
        Thread t = new Thread(() -> {
            int[] buf = new int[w * h];
            while (rtThread == Thread.currentThread() && rt.samples < photoTarget) {
                if (!rt.pass()) break;
                rt.image(buf);
                int[] out = buf.clone();
                rtW = w; rtH = h; rtImage = out; rtSamples = rt.samples;
            }
        }, "redline-photo");
        t.setDaemon(true);
        rtThread = t;
        rtImage = null;
        t.start();
    }

    // ------------------------------------------------------------ painting

    public void paint(Gfx g, float w, float h, float dt) { paintIn(g, 0, 0, w, h, dt); }

    public void paintIn(Gfx g, float x, float y, float w, float h, float dt) {
        vx = x; vy = y; vw = w; vh = h;
        float dtc = Math.min(dt, 0.05f);
        // animation
        if (!paused && mode != Raster.EXPLODED && !photo) theta += rpm / 60f * 360f * dtc * slow;
        if (autoRotate && ptr.isEmpty() && !photo) {
            idleSpin += dtc;
            if (idleSpin > 2.5f) ras.yaw += dtc * 9f;
        }
        ras.explodeT += (explodeTarget - ras.explodeT) * Math.min(1f, dtc * 4f);
        if (theta != lastTheta || forceRender) { model.update(theta, rpm, load, dtc * (paused ? 0 : 1)); lastTheta = theta; forceRender = true; }
        float q = quality;
        int rw = Math.max(16, (int) (w * q)), rh = Math.max(16, (int) (h * q));
        ras.resize(rw, rh);
        ras.selKey = selKey;
        ras.selCyl = selCyl;
        ras.heatScale = 0.45f + 0.55f * Math.min(1f, rpm / Math.max(1, model.e.redline) * 0.7f + load * 0.5f);
        g.save();
        g.clip(x, y, w, h);
        if (photo) {
            startPhotoIfNeeded();
            int[] img = rtImage;
            if (img == null) {
                ras.render(model);
                g.image(ras.px, ras.w, ras.h, x, y, w, h);
            } else g.image(img, rtW, rtH, x, y, w, h);
        } else {
            long sig = signature();
            if (sig != lastSig || forceRender) { ras.render(model); lastSig = sig; forceRender = false; }
            g.image(ras.px, ras.w, ras.h, x, y, w, h);
        }
        float s = compact ? Math.min(w, h) / 30f : Math.min(w, h) / 26f;
        s = Math.max(10f, Math.min(s, 22f));
        if (labels && !photo) drawLabels(g, x, y, w, h, s * 0.85f);
        drawHud(g, x, y, w, h, s);
        if (info != null && showInfo) drawInfo(g, x, y, w, h, s);
        g.restore();
    }

    private void drawHud(Gfx g, float x, float y, float w, float h, float s) {
        Engine e = model.e;
        String modeName = photo ? "Ray-traced photo" : Raster.MODES[mode];
        g.text(modeName.toUpperCase(Locale.US), x + s * 0.8f, y + s * 1.4f, s * 0.75f, Theme.CYAN, Gfx.LEFT, Gfx.BOLD);
        if (photo) {
            int sm = rtSamples;
            String st = sm >= photoTarget ? "Done · " + sm + " samples/pixel" : "Ray tracing… " + sm + " samples";
            g.text(st, x + s * 0.8f, y + s * 2.6f, s * 0.7f, Theme.DIM, Gfx.LEFT, 0);
            float bw = w * 0.3f;
            g.fillRound(x + s * 0.8f, y + s * 3.1f, bw, s * 0.25f, s * 0.12f, 0x33FFFFFF);
            g.fillRound(x + s * 0.8f, y + s * 3.1f, bw * Math.min(1f, sm / (float) photoTarget), s * 0.25f, s * 0.12f, Theme.CYAN);
            return;
        }
        if (!compact) {
            float slowX = 1f / slow;
            String sp = slow >= 0.999f ? "real time" : (slowX >= 1.5f ? String.format(Locale.US, "%.0f× slow motion", slowX) : "");
            g.text(Units.rpm(rpm) + (sp.isEmpty() ? "" : " · " + sp), x + s * 0.8f, y + s * 2.6f, s * 0.68f, Theme.DIM, Gfx.LEFT, 0);
        }
        // cycle indicator for cylinder 1 (or selected cylinder)
        int cyl = selCyl >= 0 ? selCyl : 0;
        if (!model.wankel && model.n > 0) {
            float a = model.cycleAngle(cyl);
            float cr = s * 1.5f, cx = x + w - cr - s * 0.8f, cy = y + cr + s * 0.8f;
            g.circle(cx, cy, cr, 0x66000000);
            boolean two = model.twoStroke;
            if (two) {
                g.arc(cx, cy, cr * 0.82f, -90, 100, s * 0.3f, 0xFFFF8A3D);
                g.arc(cx, cy, cr * 0.82f, 10, 160, s * 0.3f, 0xFF7FD4FF);
                g.arc(cx, cy, cr * 0.82f, 170, 100, s * 0.3f, 0xFFB48CFF);
            } else {
                int[] cols = {0xFFFFB347, 0xFF9A8F88, 0xFF5FA4FF, 0xFFB48CFF};
                for (int k = 0; k < 4; k++) g.arc(cx, cy, cr * 0.82f, -90 + k * 90, 88, s * 0.3f, cols[k]);
            }
            float ang = (float) Math.toRadians(-90 + a * (two ? 1f : 0.5f));
            g.line(cx, cy, cx + (float) Math.cos(ang) * cr * 0.95f, cy + (float) Math.sin(ang) * cr * 0.95f, s * 0.12f, Theme.TEXT);
            g.text("Cyl " + (cyl + 1), cx, cy + cr + s * 0.9f, s * 0.6f, Theme.DIM, Gfx.CENTER, 0);
            g.text(EngineModel.strokeName(a, two), cx, cy + cr + s * 1.7f, s * 0.7f, Theme.TEXT, Gfx.CENTER, Gfx.BOLD);
        }
        if (mode == Raster.THERMAL) {
            float lx = x + w - s * 1.6f, ly0 = y + h * 0.35f, lh = h * 0.4f;
            for (int i = 0; i < 40; i++) {
                float t = 1f - i / 39f;
                g.fillRect(lx, ly0 + lh * i / 40f, s * 0.5f, lh / 40f + 1, Raster.heatColor(t * 1.05f));
            }
            g.text("900°C", lx - s * 0.3f, ly0 + s * 0.4f, s * 0.55f, Theme.DIM, Gfx.RIGHT, 0);
            g.text("20°C", lx - s * 0.3f, ly0 + lh, s * 0.55f, Theme.DIM, Gfx.RIGHT, 0);
        }
        if (mode == Raster.FLOW) {
            int mask = model.flowTypesPresent();
            float fx = x + s * 0.8f, fy = y + h - s * 1.2f;
            float chipH = s * 1.25f;
            for (int t = 0; t < 8; t++) {
                flowRects[t] = null;
                if ((mask & (1 << t)) == 0) continue;
                String nm = EngineModel.FLOW_NAME[t];
                float cw = g.textWidth(nm, s * 0.62f, 0) + s * 1.6f;
                if (fx + cw > x + w - s) { fx = x + s * 0.8f; fy -= chipH * 1.15f; }
                boolean on = ras.flowMask[t];
                g.fillRound(fx, fy - chipH * 0.8f, cw, chipH, chipH / 2, on ? 0x66000000 : 0x22000000);
                g.circle(fx + s * 0.6f, fy - chipH * 0.3f, s * 0.28f, on ? EngineModel.FLOW_COLOR[t] : Theme.FAINT);
                g.text(nm, fx + s * 1.05f, fy - chipH * 0.3f + s * 0.22f, s * 0.62f, on ? Theme.TEXT : Theme.FAINT, Gfx.LEFT, 0);
                flowRects[t] = new float[]{fx, fy - chipH * 0.8f, cw, chipH};
                fx += cw + s * 0.4f;
            }
        }
        if (mode == Raster.SCALE && model.dims != null) {
            float[] d = model.dims;
            String txt = "≈ " + Units.len(d[0]) + " long · " + Units.len(d[2]) + " wide · " + Units.len(d[1]) + " tall";
            g.text(txt, x + w / 2, y + h - s * 1.1f, s * 0.72f, Theme.TEXT, Gfx.CENTER, Gfx.BOLD);
            g.text("Figure: 1.75 m person", x + w / 2, y + h - s * 0.2f, s * 0.58f, Theme.DIM, Gfx.CENTER, 0);
        }
        if (!compact && info == null && mode != Raster.FLOW && mode != Raster.SCALE)
            g.text("Drag to rotate · pinch to zoom · tap a part", x + w / 2, y + h - s * 0.6f, s * 0.6f, Theme.alpha(Theme.DIM, 0.8f), Gfx.CENTER, 0);
    }

    private void drawLabels(Gfx g, float x, float y, float w, float h, float s) {
        String[] keys = {"head", "camcover", "block", "piston", "crank", "turbine", "compressor", "intercooler", "plenum", "airbox", "supercharger", "blower", "header", "expansion", "sump", "flywheel", "rotor", "rotor_housing", "carb", "carb4", "weber", "trumpet", "fins", "exrec", "scav", "valve_ex", "prop"};
        ArrayList<float[]> left = new ArrayList<>(), right = new ArrayList<>();
        ArrayList<String> ln = new ArrayList<>(), rn = new ArrayList<>();
        float sx = (float) w / ras.w, sy = (float) h / ras.h;
        int count = 0;
        for (String k : keys) {
            if (count >= 9) break;
            Part p = null;
            for (Part q : model.parts) if (q.key.equals(k) && ras.visible(q, model)) { p = q; break; }
            if (p == null) continue;
            float[] c = new float[3];
            float ex = mode == Raster.EXPLODED ? ras.explodeT : 0;
            M3.apply(p.mat, p.center[0], p.center[1], p.center[2], c, 0);
            float[] pr = ras.project(c[0] + p.explode[0] * ex, c[1] + p.explode[1] * ex, c[2] + p.explode[2] * ex);
            if (pr == null) continue;
            float px = x + pr[0] * sx, py = y + pr[1] * sy;
            if (px < x || px > x + w || py < y || py > y + h) continue;
            count++;
            if (px < x + w / 2) { left.add(new float[]{px, py}); ln.add(PartInfo.title(k)); }
            else { right.add(new float[]{px, py}); rn.add(PartInfo.title(k)); }
        }
        drawLabelColumn(g, left, ln, x + s * 0.6f, true, y, h, s);
        drawLabelColumn(g, right, rn, x + w - s * 0.6f, false, y, h, s);
    }

    private void drawLabelColumn(Gfx g, ArrayList<float[]> pts, ArrayList<String> names, float colX, boolean leftSide, float y, float h, float s) {
        int n = pts.size();
        if (n == 0) return;
        Integer[] order = new Integer[n];
        for (int i = 0; i < n; i++) order[i] = i;
        java.util.Arrays.sort(order, (a, b) -> Float.compare(pts.get(a)[1], pts.get(b)[1]));
        float top = y + h * (leftSide ? 0.2f : 0.3f), span = h * (leftSide ? 0.6f : 0.5f);
        for (int k = 0; k < n; k++) {
            int i = order[k];
            float ly = top + span * (n == 1 ? 0.5f : (float) k / (n - 1));
            float[] p = pts.get(i);
            String nm = names.get(i);
            float tw = g.textWidth(nm, s * 0.8f, Gfx.BOLD);
            float bx = leftSide ? colX : colX - tw - s * 0.8f;
            float anchorX = leftSide ? bx + tw + s * 0.8f : bx;
            g.line(anchorX, ly, p[0], p[1], Math.max(1f, s * 0.07f), 0xAA3BD5FF);
            g.circle(p[0], p[1], s * 0.18f, Theme.CYAN);
            g.fillRound(bx, ly - s * 0.65f, tw + s * 0.8f, s * 1.3f, s * 0.3f, 0xCC0A0D12);
            g.text(nm, bx + s * 0.4f, ly + s * 0.28f, s * 0.8f, Theme.TEXT, Gfx.LEFT, Gfx.BOLD);
        }
    }

    private void drawInfo(Gfx g, float x, float y, float w, float h, float s) {
        float pad = s * 0.8f;
        float cw = Math.min(w - pad * 2, s * 26f);
        float ts = s * 0.95f, bs = s * 0.72f;
        float bodyH = Theme.wrapHeight(g, info[1], cw - pad * 2, bs, 0);
        float ch = Math.min(h * 0.55f, ts * 1.8f + bodyH + pad * 1.6f);
        float cx = x + (w - cw) / 2, cy = y + h - ch - pad;
        g.fillRound(cx, cy, cw, ch, s * 0.6f, 0xE6121720);
        g.strokeRound(cx, cy, cw, ch, s * 0.6f, 1.5f, Theme.alpha(Theme.CYAN, 0.6f));
        g.text(info[0], cx + pad, cy + pad + ts * 0.9f, ts, Theme.CYAN, Gfx.LEFT, Gfx.BOLD);
        g.save();
        g.clip(cx, cy, cw, ch);
        Theme.wrap(g, info[1], cx + pad, cy + pad + ts * 1.5f, cw - pad * 2, bs, Theme.TEXT, 0);
        g.restore();
        float r = s * 0.7f;
        closeRect = new float[]{cx + cw - r * 2.4f, cy + r * 0.4f, r * 2f, r * 2f};
        g.circle(closeRect[0] + r, closeRect[1] + r, r, 0x33FFFFFF);
        g.line(closeRect[0] + r * 0.6f, closeRect[1] + r * 0.6f, closeRect[0] + r * 1.4f, closeRect[1] + r * 1.4f, 2f, Theme.TEXT);
        g.line(closeRect[0] + r * 1.4f, closeRect[1] + r * 0.6f, closeRect[0] + r * 0.6f, closeRect[1] + r * 1.4f, 2f, Theme.TEXT);
    }

    /** Hash of everything that changes the rendered image; identical frames are not re-rendered. */
    private long signature() {
        long h = 1469598103934665603L;
        float[] v = {ras.yaw, ras.pitch, ras.dist, ras.explodeT, ras.heatScale, ras.w, ras.h, mode, selCyl, theta};
        for (float f : v) { h ^= Float.floatToIntBits(f); h *= 1099511628211L; }
        h ^= selKey == null ? 0 : selKey.hashCode(); h *= 1099511628211L;
        for (boolean b : ras.flowMask) { h ^= b ? 1 : 2; h *= 1099511628211L; }
        return h;
    }

    // ------------------------------------------------------------ touch

    public boolean contains(float x, float y) { return x >= vx && y >= vy && x <= vx + vw && y <= vy + vh; }

    @Override
    public void touch(int action, int id, float x, float y) {
        if (action == DOWN) {
            if (!contains(x, y)) return;
            ptr.put(id, new float[]{x, y});
            idleSpin = 0;
            if (ptr.size() == 1) { downX = x; downY = y; downT = System.currentTimeMillis(); moved = false; }
            if (ptr.size() == 2) {
                float[][] p = ptr.values().toArray(new float[0][]);
                pinchD = dist(p[0], p[1]);
                moved = true;
            }
            return;
        }
        float[] prev = ptr.get(id);
        if (prev == null) return;
        if (action == MOVE) {
            if (ptr.size() == 1) {
                float dx = x - prev[0], dy = y - prev[1];
                if (Math.abs(x - downX) + Math.abs(y - downY) > 12) moved = true;
                if (moved) {
                    ras.yaw += dx * 0.35f;
                    ras.pitch = Math.max(-80, Math.min(85, ras.pitch + dy * 0.3f));
                    if (photo) restartPhoto();
                }
            } else if (ptr.size() >= 2) {
                prev[0] = x; prev[1] = y;
                float[][] p = ptr.values().toArray(new float[0][]);
                float d = dist(p[0], p[1]);
                if (pinchD > 1 && d > 1) {
                    ras.dist *= pinchD / d;
                    float r = model.radius;
                    ras.dist = Math.max(r * 0.6f, Math.min(r * 12f, ras.dist));
                    pinchD = d;
                    if (photo) restartPhoto();
                }
            }
            prev[0] = x; prev[1] = y;
        } else if (action == UP || action == CANCEL) {
            ptr.remove(id);
            if (action == UP && ptr.isEmpty() && !moved && System.currentTimeMillis() - downT < 400) tap(x, y);
        }
    }

    private static float dist(float[] a, float[] b) {
        float dx = a[0] - b[0], dy = a[1] - b[1];
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    private void tap(float x, float y) {
        if (closeRect != null && info != null && Theme.in(x, y, closeRect)) { clearSelection(); return; }
        if (mode == Raster.FLOW) {
            for (int t = 0; t < 8; t++) if (flowRects[t] != null && Theme.in(x, y, flowRects[t])) { ras.flowMask[t] = !ras.flowMask[t]; return; }
        }
        int px = (int) ((x - vx) / vw * ras.w), py = (int) ((y - vy) / vh * ras.h);
        int id = ras.pick(px, py);
        Part p = model.partById(id);
        if (p == null) { clearSelection(); return; }
        selKey = p.key;
        selCyl = p.cyl;
        info = PartInfo.describe(model, p);
        restartPhoto();
        if (onSelect != null) onSelect.run();
    }

    public void clearSelection() {
        selKey = null; selCyl = -1; info = null;
        restartPhoto();
        if (onSelect != null) onSelect.run();
    }
}

package com.redline.core;

import java.util.ArrayList;
import java.util.Locale;

/** Human-readable info for tapped parts, with figures specific to the engine. */
public final class PartInfo {
    private PartInfo() { }

    public static String title(String key) {
        switch (key) {
            case "block": return "Cylinder block";
            case "head": return "Cylinder head";
            case "camcover": return "Cam cover";
            case "timing": return "Timing cover";
            case "crankcase": return "Crankcase";
            case "sump": return "Oil sump";
            case "piston": return "Piston";
            case "rod": return "Connecting rod";
            case "charge": return "Combustion chamber gas";
            case "liner": return "Cylinder bore";
            case "crank": return "Crankshaft";
            case "flywheel": return "Flywheel";
            case "pulley": return "Crank pulley";
            case "prop": return "Propeller hub";
            case "reduction": return "Reduction gearbox";
            case "supercharger": return "Supercharger";
            case "barrel": return "Cylinder barrel";
            case "fins": return "Cooling fins";
            case "valve_in": return "Intake valve";
            case "valve_ex": return "Exhaust valve";
            case "pushrod": return "Pushrod";
            case "rocker": return "Rocker arm";
            case "cam": return "Camshaft";
            case "actuator": return "Pneumatic valve actuator";
            case "plug": return "Spark plug";
            case "glowplug": return "Glow plug";
            case "injector": return "Fuel injector";
            case "coil": return "Ignition coil";
            case "runner": return "Intake runner";
            case "plenum": return "Intake plenum";
            case "trumpet": return "Velocity stack";
            case "carb": return "Carburettor";
            case "throttle": return "Throttle body";
            case "header": return "Exhaust header";
            case "expansion": return "Expansion chamber";
            case "downpipe": return "Downpipe";
            case "turbine": return "Turbine housing";
            case "compressor": return "Compressor housing";
            case "turbine_wheel": return "Turbine wheel";
            case "compressor_wheel": return "Compressor wheel";
            case "boostpipe": return "Charge pipe";
            case "intercooler": return "Intercooler";
            case "waterpump": return "Water pump";
            case "oilfilter": return "Oil filter";
            case "rotor_housing": return "Rotor housing";
            case "side_housing": return "Side housing";
            case "rotor": return "Rotor";
            case "eshaft": return "Eccentric shaft";
            case "figure": return "1.75 m person";
            case "manifold": return "Intake manifold";
            case "airbox": return "Induction box";
            case "weber": return "Downdraft Weber carburettors";
            case "carb4": return "Four-barrel carburettor";
            case "aircleaner": return "Air cleaner";
            case "blower": return "Roots blower";
            case "sc_rotor": return "Supercharger rotor";
            case "impeller": return "Supercharger impeller";
            case "belt": return "Drive belt";
            case "stub": return "Exhaust stub";
            case "exrec": return "Exhaust receiver";
            case "scav": return "Scavenge-air receiver";
            case "shroud": return "Fan shroud";
            case "fan": return "Cooling fan";
            case "gearbox": return "Gearbox in the sump";
        }
        return key;
    }

    static String mm(float m) {
        float v = m * 1000f;
        return v >= 100 ? String.format(Locale.US, "%.0f mm", v) : String.format(Locale.US, "%.1f mm", v);
    }

    public static String[] describe(EngineModel m, Part p) {
        Engine e = m.e;
        String key = p.key;
        String body;
        ArrayList<String> facts = new ArrayList<>();
        int cylNo = p.cyl + 1;
        boolean two = e.twoStroke();
        switch (key) {
            case "block":
                body = "The structural core: it holds the cylinders, carries the crankshaft bearings and surrounds the bores with coolant passages.";
                facts.add(e.layoutName() + ", " + Engine.fmt(e.cc >= 100000 ? e.cc / 1000f : e.cc, 0) + (e.cc >= 100000 ? " litres" : " cc"));
                if (e.bank > 0 && !e.layout.equals("I") && !e.layout.equals("F")) facts.add("Bank angle " + Math.round(e.bank) + "°");
                if (e.layout.equals("VR")) facts.add("Narrow-angle: both rows share one head");
                if (e.engineKg > 0) facts.add("Complete engine mass " + fmtMass(e.engineKg));
                break;
            case "head":
                body = two ? "On a two-stroke the head is just a lid with the combustion chamber and plug - there are no valves." :
                        "Holds the valves, camshafts (or rockers) and the combustion chamber roof; gas flows in and out through its ports.";
                if (!two) facts.add(e.valves + " valves per cylinder · " + (e.valves * e.cyl) + " in total");
                facts.add(e.vtName());
                break;
            case "camcover":
                body = "Seals the top of the head and keeps oil around the camshafts. Often painted in a maker's signature colour.";
                break;
            case "timing":
                body = "Covers the chain, belt or gears that drive the camshafts at exactly half crankshaft speed.";
                break;
            case "crankcase":
                body = two ? "On a two-stroke the sealed crankcase is a pump: the rising piston draws fresh mixture in, the falling piston pushes it up the transfer ports."
                        : "Houses the spinning crankshaft and its main bearings.";
                if (e.radial()) body = "The central drum of a radial engine; every cylinder bolts around it and all rods meet on one crankpin.";
                break;
            case "sump":
                body = e.drySump ? "Dry-sump: a shallow pan; scavenge pumps send oil to a separate tank, so the engine can sit lower and survive high g-forces."
                        : "The oil reservoir under the crank. The pump picks oil up here and sends it through the galleries.";
                break;
            case "piston":
                body = "Receives the combustion pressure and pushes the connecting rod. Rings seal it against the bore.";
                facts.add("Cylinder " + cylNo + " of " + e.cyl);
                facts.add("Bore " + mm(m.B) + (e.boreKnown ? "" : " (estimated)"));
                facts.add("Stroke " + mm(m.S));
                facts.add(String.format(Locale.US, "Mean piston speed at redline: %.1f m/s", e.meanPistonSpeed()));
                float pk = (float) (2 * Math.PI * m.R * e.redline / 60f * 1.6f);
                facts.add(String.format(Locale.US, "Peak piston speed ≈ %.0f m/s", pk));
                break;
            case "rod":
                body = "Links piston to crankshaft, turning straight-line motion into rotation.";
                facts.add("Length ≈ " + mm(m.L) + String.format(Locale.US, " (rod/stroke %.2f)", m.L / Math.max(1e-6f, m.S)));
                if (e.radial()) facts.add("Radial: one master rod plus articulated rods share a single crankpin");
                if (e.redline > 8500 && !two) facts.add("High-revving designs often use titanium rods");
                break;
            case "charge":
                float a = m.cycleAngle(p.cyl);
                body = "The gas in cylinder " + cylNo + " right now: " + EngineModel.strokeName(a, two).toLowerCase(Locale.US) + " stroke.";
                facts.add("Blue = fresh charge · violet = compressed · white/orange = burning · grey = exhaust");
                if (e.diesel()) facts.add("Diesel: air only is compressed until it is hot enough to ignite injected fuel");
                break;
            case "liner":
                body = "The bore the piston slides in - honed to hold a thin oil film.";
                facts.add("Swept volume per cylinder " + Engine.fmt(e.cc / e.cyl, e.cc / e.cyl < 10 ? 2 : 0) + " cc");
                break;
            case "crank":
                body = "Converts the pistons' up-and-down motion into rotation. Throws are phased so the cylinders fire evenly.";
                facts.add("Stroke " + mm(m.S) + " (throw radius " + mm(m.R) + ")");
                if (e.layout.equals("V") && e.cyl == 8) facts.add(e.flatPlane ? "Flat-plane crank: lighter, revs faster, screams" : "Cross-plane crank: smoother, the classic V8 burble");
                facts.add("Redline " + e.redline + " rpm");
                break;
            case "flywheel":
                body = "Stores rotational energy to smooth out the power pulses; also carries the clutch and starter ring gear.";
                break;
            case "pulley":
                body = "Drives the accessory belt (alternator, water pump, A/C) and often damps crankshaft vibration.";
                break;
            case "prop":
                body = "The propeller shaft runs at about half crank speed through reduction gears.";
                break;
            case "reduction":
                body = "Gears the crankshaft down so the propeller tips stay below the speed of sound.";
                break;
            case "supercharger":
                body = e.radial() ? "A gear-driven centrifugal blower packs air into the intake ring that feeds every cylinder."
                        : "A belt- or gear-driven compressor: instant boost with no lag, at the cost of some crank power.";
                break;
            case "barrel":
            case "fins":
                body = "Air-cooled: thin fins spread the heat so the passing airflow can carry it away - no radiator or coolant.";
                break;
            case "valve_in":
                body = "Opens to let air (or air-fuel mixture) into the cylinder on the intake stroke.";
                facts.add("Cylinder " + cylNo);
                break;
            case "valve_ex":
                body = e.vt.equals("UNI") ? "Uniflow scavenging: air enters through ports low in the liner and leaves through this exhaust valve in the head."
                        : "Opens near the bottom of the power stroke to release the hot exhaust gas. It runs much hotter than the intake valve.";
                facts.add("Cylinder " + cylNo);
                break;
            case "pushrod":
                body = "Transfers the cam lift from a camshaft in the block up to the rocker arms in the head.";
                break;
            case "rocker":
                body = "A lever that turns the pushrod's upward push into a downward push that opens the valve.";
                break;
            case "cam":
                body = "Egg-shaped lobes open the valves at exactly the right moment. It turns at half crankshaft speed.";
                facts.add(e.vtName());
                if (e.vt.equals("DESMO")) facts.add("Desmodromic: a second lobe closes the valves - no valve springs to float");
                break;
            case "actuator":
                body = "Koenigsegg Freevalve: each valve is opened by compressed air under computer control, so timing and lift can change every cycle.";
                break;
            case "plug":
                body = "Fires a spark across its electrode to ignite the compressed mixture just before top dead centre.";
                break;
            case "glowplug":
                body = "A heated platinum coil in model engines; the catalytic glow keeps igniting the nitro-methanol fuel.";
                break;
            case "injector":
                body = e.diesel() ? "Sprays diesel at very high pressure into the hot compressed air, where it ignites on its own." : "Meters fuel precisely into the intake port or directly into the cylinder.";
                break;
            case "coil":
                body = "Coil-on-plug: transforms 12 V into tens of thousands of volts for the spark.";
                break;
            case "runner":
                body = "Each cylinder's intake pipe. Length and diameter are tuned so pressure waves help ram air in.";
                break;
            case "plenum":
                body = "A shared air chamber that feeds all the runners evenly.";
                break;
            case "trumpet":
                body = "Velocity stacks / individual throttle bodies: one throttle per cylinder for razor-sharp response.";
                break;
            case "carb":
                body = "Mixes fuel into the air using the venturi effect - no electronics needed.";
                break;
            case "throttle":
                body = "The butterfly valve your right foot controls; it decides how much air the engine can breathe.";
                break;
            case "header":
                body = "Carries exhaust gas away from each port. Equal-length headers make the pulses help each other scavenge.";
                break;
            case "expansion":
                body = "The two-stroke tuned pipe: the diverging cone sucks exhaust out, the converging cone bounces a pressure wave back to stuff fresh charge into the cylinder before the port closes.";
                break;
            case "downpipe":
                body = "Takes exhaust from the manifold or turbine to the catalytic converters and silencers.";
                break;
            case "turbine":
            case "turbine_wheel":
                body = "Exhaust gas spins the turbine wheel - often over 150,000 rpm - which drives the compressor on the same shaft.";
                facts.add(e.aspName());
                break;
            case "compressor":
            case "compressor_wheel":
                body = "Squeezes intake air so more fits in each cylinder: more air, more fuel, more power.";
                facts.add(e.aspName());
                break;
            case "boostpipe":
                body = "Carries compressed air from the turbo towards the intercooler and intake.";
                break;
            case "intercooler":
                body = "Compressing air heats it. The intercooler cools it again, making it denser and less prone to knock.";
                break;
            case "waterpump":
                body = "Circulates coolant through the block, head and radiator.";
                break;
            case "oilfilter":
                body = "Catches metal particles and soot before oil reaches the bearings.";
                break;
            case "rotor_housing":
                body = "The epitrochoid (peanut-shaped) chamber. The rotor's three tips sweep along it, forming three working chambers.";
                break;
            case "side_housing":
                body = "Flat plates between rotors; on many rotaries they carry the intake ports.";
                break;
            case "rotor":
                body = "A triangular rotor replaces pistons. Each face completes a full four-stroke cycle per rotor turn - three power pulses per revolution of the rotor.";
                break;
            case "eshaft":
                body = "The eccentric shaft turns three times for every rotor revolution.";
                break;
            case "figure":
                body = "A 1.75 m person for scale.";
                break;
            case "manifold":
                body = "Distributes the mixture from the carburettor(s) to every intake port.";
                break;
            case "airbox":
                body = "A large sealed box feeding all the runners; its throttle valves sit on top or at the front.";
                if (e.nthr > 0) facts.add(e.nthr + " throttle bodies");
                break;
            case "weber":
                body = "Twin-choke downdraft carburettors sitting in the vee, each choke feeding one cylinder through its own trumpet - classic Italian induction.";
                break;
            case "carb4":
                body = "A four-barrel carburettor on top of the intake manifold: two primaries for cruising, two secondaries that open at full throttle.";
                break;
            case "aircleaner":
                body = "The big round air cleaner filters the air before the carburettor.";
                break;
            case "blower":
                body = "A huge Roots-type blower, crank-driven by a belt, topped by the fuel-injector \"hat\" scoop. It alone can take hundreds of horsepower to drive.";
                break;
            case "sc_rotor":
                body = e.scx.equals("screw") ? "Twin-screw rotors mesh like gears, compressing air inside the housing - efficient boost from idle."
                        : e.scx.equals("tvs") ? "Four-lobe twisted rotors (Eaton TVS) move air from inlet to outlet with very little heat."
                        : "Roots-type lobed rotors carry air around the outside of the housing into the intake.";
                break;
            case "impeller":
                body = "A centrifugal impeller spinning many times faster than the crankshaft flings air outwards into the volute, building pressure.";
                break;
            case "belt":
                body = "Drives the supercharger from the crankshaft.";
                break;
            case "stub":
                body = "Aero engines often used short individual exhaust stubs - the exhaust thrust even added a little forward push.";
                break;
            case "exrec":
                body = "All cylinders blow down into this huge pipe, which steadies the flow before it reaches the turbochargers.";
                break;
            case "scav":
                body = "Pressurised air from the turbochargers waits here before rushing into the liners through the scavenge ports.";
                break;
            case "shroud":
                body = "Guides the fan's airflow over every cylinder fin - the air-cooled version of a radiator.";
                break;
            case "fan":
                body = "A belt- or shaft-driven cooling fan pushes air through the shroud and over the cylinder fins.";
                break;
            case "gearbox":
                body = "Alec Issigonis put the gearbox inside the sump, sharing the engine oil - that's how the Mini got so short.";
                break;
            default:
                body = "";
        }
        StringBuilder sb = new StringBuilder(body);
        for (String f : facts) sb.append("\n• ").append(f);
        return new String[]{title(key), sb.toString()};
    }

    static String fmtMass(float kg) {
        if (kg >= 10000) return String.format(Locale.US, "%,.0f tonnes", kg / 1000f);
        return String.format(Locale.US, "%.0f kg", kg);
    }
}

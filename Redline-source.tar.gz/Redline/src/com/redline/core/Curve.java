package com.redline.core;

/** Torque curve built from documented peak figures (monotone cubic through control points). */
public final class Curve {
    public static final int N = 128;
    public final float[] rpm = new float[N];
    public final float[] nm = new float[N];
    public float rpmMax, redline;
    public float peakKw, peakNm, rpmPeakKw, rpmPeakNm;
    public float baseBoost; // bar, for display

    public float torque(float r) {
        if (r <= 0) return nm[0];
        float f = r / rpmMax * (N - 1);
        if (f >= N - 1) return nm[N - 1];
        int i = (int) f;
        float t = f - i;
        return nm[i] + (nm[i + 1] - nm[i]) * t;
    }

    public float kw(float r) { return torque(r) * r / 9549.3f; }

    private void stats() {
        peakKw = 0; peakNm = 0;
        for (int i = 0; i < N; i++) {
            if (rpm[i] > redline * 1.001f) break;
            float k = nm[i] * rpm[i] / 9549.3f;
            if (k > peakKw) { peakKw = k; rpmPeakKw = rpm[i]; }
            if (nm[i] > peakNm) { peakNm = nm[i]; rpmPeakNm = rpm[i]; }
        }
    }

    public static Curve stock(Engine e) { return build(e, null); }

    public static Curve build(Engine e, Tune t) {
        Curve c = new Curve();
        int red = t == null ? e.redline : t.redline(e);
        c.redline = red;
        c.rpmMax = red * 1.06f;
        for (int i = 0; i < N; i++) c.rpm[i] = c.rpmMax * i / (N - 1);

        float rP = e.rpmP, Tmax = e.nm, Tp = e.kw * 9549.3f / rP;
        if (Tp > Tmax * 0.995f) Tmax = Tp * 1.03f;
        boolean boosted = e.turbos > 0 || e.sc;
        float idle = Math.max(e.idle * 0.6f, 1f);
        float rT = e.rpmT;
        if (rT <= 0 || rT >= rP) {
            if (e.twoStroke()) rT = rP * 0.86f;
            else if (e.turbos > 0) rT = rP * (e.diesel() ? 0.42f : 0.40f);
            else if (e.sc) rT = rP * 0.62f;
            else if (e.wankel()) rT = rP * 0.7f;
            else rT = rP * 0.72f;
        }
        // Plateau end so that power still peaks at rP
        float rTend = rT;
        if (boosted) rTend = Math.max(rT, Math.min(rP * 0.82f, rP * Tp / Tmax * 0.97f));

        float[] xs, ys;
        float redT;
        if (e.twoStroke()) redT = Tp * 0.62f;
        else if (e.turbos > 0) redT = Tp * 0.84f;
        else redT = Tp * 0.9f;
        float idleT;
        if (e.twoStroke()) idleT = Tmax * 0.32f;
        else if (e.turbos > 0) idleT = Tmax * (e.diesel() ? 0.48f : 0.42f);
        else if (e.sc) idleT = Tmax * 0.72f;
        else if (e.wankel()) idleT = Tmax * 0.68f;
        else idleT = Tmax * 0.62f;

        java.util.ArrayList<float[]> pts = new java.util.ArrayList<>();
        pts.add(new float[]{0, idleT * 0.6f});
        pts.add(new float[]{idle, idleT});
        if (e.twoStroke()) pts.add(new float[]{rP * 0.62f, Tmax * 0.5f});
        if (rT > idle * 1.1f) pts.add(new float[]{rT, Tmax});
        if (rTend > rT * 1.02f) pts.add(new float[]{rTend, Tmax * 0.995f});
        if (rP > rTend * 1.02f) pts.add(new float[]{rP, Tp});
        float redRpm = e.redline;
        if (redRpm > rP * 1.01f) pts.add(new float[]{redRpm, redT});
        pts.add(new float[]{Math.max(redRpm, rP) * 1.25f, (redRpm > rP * 1.01f ? redT : Tp) * 0.72f});
        xs = new float[pts.size()];
        ys = new float[pts.size()];
        for (int i = 0; i < xs.length; i++) { xs[i] = pts.get(i)[0]; ys[i] = pts.get(i)[1]; }
        float[] q = new float[N];
        float scaleRpm = 1f;
        for (int i = 0; i < N; i++) q[i] = c.rpm[i] / scaleRpm;
        pchip(xs, ys, q, c.nm);
        // Normalise so peak power (up to the stock redline) matches the documented figure exactly
        c.redline = e.redline;
        c.stats();
        float k = e.kw / Math.max(0.0001f, c.peakKw);
        for (int i = 0; i < N; i++) c.nm[i] *= k;
        c.redline = red;
        c.baseBoost = e.turbos > 0 ? (e.diesel() ? 1.8f : 1.0f) : (e.sc ? 0.8f : 0f);

        if (t != null) applyTune(c, e, t, rT, rP);
        c.stats();
        return c;
    }

    private static float smooth(float a, float b, float x) {
        if (x <= a) return 0;
        if (x >= b) return 1;
        float t = (x - a) / (b - a);
        return t * t * (3 - 2 * t);
    }

    private static void applyTune(Curve c, Engine e, Tune t, float rT, float rP) {
        boolean turbo = e.turbos > 0, sc = e.sc, boosted = turbo || sc;
        boolean two = e.twoStroke();
        float stockRed = e.redline;
        float stockPeak = e.kw;
        float[] base = c.nm.clone();
        for (int i = 0; i < N; i++) {
            float r = c.rpm[i];
            float x = r / stockRed; // 0..1.2
            float m = 1f;
            // ECU / jetting
            float[] ecuGain = two ? new float[]{0, .03f, .06f, .08f}
                    : e.diesel() && turbo ? new float[]{0, .20f, .32f, .42f}
                    : boosted ? new float[]{0, .12f, .20f, .28f} : new float[]{0, .04f, .07f, .10f};
            float ecu = ecuGain[t.ecu];
            if (turbo) ecu *= 0.55f + 0.45f * smooth(0.2f, 0.5f, x); // mostly mid-range
            m += ecu;
            // Intake / exhaust
            m += new float[]{0, .02f, .04f}[t.intake] * (0.6f + 0.6f * x);
            if (two) m += new float[]{0, .08f, .15f}[t.exhaust] * (smooth(0.5f, 0.9f, x) * 1.4f - 0.25f);
            else m += new float[]{0, .03f, .06f}[t.exhaust] * (0.5f + 0.7f * x);
            // Cams / porting: trade bottom end for top end
            float camG = (two || e.wankel()) ? new float[]{0, .07f, .14f}[t.cams] : new float[]{0, .05f, .09f}[t.cams];
            m += camG * (smooth(0.45f, 0.95f, x) * 1.6f - 0.45f);
            // Big bore
            m *= 1f + Tune.BORE[t.bigBore] / 100f;
            // Fuel
            float[] fuelG = boosted || t.kit > 0 ? new float[]{0, .04f, .08f, .12f} : new float[]{0, .02f, .05f, .08f};
            if (!e.diesel()) m *= 1f + fuelG[t.fuel];
            // Forced induction
            if (boosted) {
                float extra = t.boost * 0.1f;
                float spoolShift = 1f + 0.12f * extra;
                float spool = turbo ? smooth(rT * 0.55f * spoolShift / stockRed, rT * 1.05f * spoolShift / stockRed, x) : (0.4f + 0.6f * x);
                m *= 1f + extra * 0.6f / (1f + c.baseBoost) * spool;
                if (t.intercooler == 1) m *= 1.05f;
            } else if (t.kit > 0) {
                float kb = Math.max(0.3f, t.boost * 0.1f);
                if (t.kit == 1) {
                    float spool = smooth(0.25f, 0.5f, x);
                    m *= 1f + kb * 0.85f * spool;
                } else {
                    m *= 1f + kb * 0.8f * (0.55f + 0.45f * Math.min(1f, x));
                }
                if (t.intercooler == 1) m *= 1.05f;
            }
            // Past the stock redline torque keeps falling unless cams/ports help
            if (x > 1f) m *= Math.max(0.4f, 1f - (x - 1f) * (1.6f - t.cams * 0.35f));
            c.nm[i] = base[i] * m;
            // Nitrous: constant extra power above 45% of the stock redline
            if (t.nitrous > 0 && r > 1f) {
                float shotKw = stockPeak * Tune.NOS[t.nitrous] / 100f;
                c.nm[i] += shotKw * 9549.3f / Math.max(r, stockRed * 0.45f) * smooth(0.40f, 0.5f, x);
            }
        }
    }

    /** Fritsch-Carlson monotone cubic interpolation. */
    static void pchip(float[] x, float[] y, float[] q, float[] out) {
        int n = x.length;
        float[] d = new float[n - 1], m = new float[n];
        for (int i = 0; i < n - 1; i++) d[i] = (y[i + 1] - y[i]) / (x[i + 1] - x[i]);
        m[0] = d[0];
        m[n - 1] = d[n - 2];
        for (int i = 1; i < n - 1; i++) {
            if (d[i - 1] * d[i] <= 0) m[i] = 0;
            else {
                float w1 = 2 * (x[i + 1] - x[i]) + (x[i] - x[i - 1]);
                float w2 = (x[i + 1] - x[i]) + 2 * (x[i] - x[i - 1]);
                m[i] = (w1 + w2) / (w1 / d[i - 1] + w2 / d[i]);
            }
        }
        for (int k = 0; k < q.length; k++) {
            float v = q[k];
            if (v <= x[0]) { out[k] = y[0]; continue; }
            if (v >= x[n - 1]) { out[k] = y[n - 1]; continue; }
            int i = 0;
            while (i < n - 2 && v > x[i + 1]) i++;
            float h = x[i + 1] - x[i], s = (v - x[i]) / h;
            float s2 = s * s, s3 = s2 * s;
            float h00 = 2 * s3 - 3 * s2 + 1, h10 = s3 - 2 * s2 + s, h01 = -2 * s3 + 3 * s2, h11 = s3 - s2;
            out[k] = h00 * y[i] + h10 * h * m[i] + h01 * y[i + 1] + h11 * h * m[i + 1];
        }
    }
}

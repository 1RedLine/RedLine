package com.redline.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;

/**
 * Parses assets/engines.txt.
 *
 * Engine:  E|Make|Name|Code|Years|Layout|cc|Asp|Power|Torque|rpmPower|redline|opts|note
 * Vehicle: >Name|Years|Type[*count]|Drive|kg|top[L|C|T|R]|power
 */
public final class EngineDB {
    public final ArrayList<Engine> all = new ArrayList<>();
    public final ArrayList<String> makes = new ArrayList<>();
    public final ArrayList<String> errors = new ArrayList<>();
    private final HashMap<String, Engine> byId = new HashMap<>();

    public static EngineDB parse(String text) {
        EngineDB db = new EngineDB();
        Engine cur = null;
        int lineNo = 0;
        for (String raw : text.split("\n")) {
            lineNo++;
            String line = raw.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            try {
                if (line.startsWith("E|")) {
                    cur = parseEngine(line);
                    if (cur != null) {
                        cur.idx = db.all.size();
                        String base = slug(cur.make + "-" + cur.name);
                        String id = base;
                        int k = 2;
                        while (db.byId.containsKey(id)) id = base + "-" + (k++);
                        cur.id = id;
                        db.byId.put(id, cur);
                        db.all.add(cur);
                    }
                } else if (line.startsWith(">") && cur != null) {
                    Vehicle v = parseVehicle(line.substring(1), cur);
                    cur.vehicles.add(v);
                }
            } catch (Exception ex) {
                db.errors.add("line " + lineNo + ": " + ex);
            }
        }
        HashSet<String> mk = new HashSet<>();
        for (Engine e : db.all) {
            finish(e);
            mk.add(e.make);
        }
        db.makes.addAll(mk);
        Collections.sort(db.makes);
        return db;
    }

    public Engine get(String id) { return byId.get(id); }

    static String slug(String s) {
        return s.toLowerCase(Locale.US).replaceAll("[^a-z0-9]+", "-").replaceAll("(^-|-$)", "");
    }

    static float num(String s) {
        return Float.parseFloat(s.trim());
    }

    /** Returns kW. */
    static float power(String s) {
        s = s.trim().toLowerCase(Locale.US);
        if (s.endsWith("ps")) return num(s.substring(0, s.length() - 2)) * 0.73549875f;
        if (s.endsWith("kw")) return num(s.substring(0, s.length() - 2));
        if (s.endsWith("hp")) return num(s.substring(0, s.length() - 2)) * 0.745699872f;
        return num(s) * 0.745699872f;
    }

    /** Returns Nm. */
    static float torque(String s) {
        s = s.trim().toLowerCase(Locale.US);
        if (s.isEmpty() || s.equals("-")) return 0;
        if (s.endsWith("lbft")) return num(s.substring(0, s.length() - 4)) * 1.35581795f;
        if (s.endsWith("nm")) return num(s.substring(0, s.length() - 2));
        return num(s);
    }

    static Engine parseEngine(String line) {
        String[] f = line.split("\\|", -1);
        Engine e = new Engine();
        e.make = f[1].trim();
        e.name = f[2].trim();
        e.code = f[3].trim();
        e.years = f[4].trim();
        String ys = e.years.replaceAll("[^0-9].*$", "");
        e.year = ys.length() >= 4 ? Integer.parseInt(ys.substring(0, 4)) : 2000;
        parseLayout(e, f[5].trim());
        e.cc = num(f[6]);
        String asp = f[7].trim().toUpperCase(Locale.US);
        if (asp.contains("SC")) e.sc = true;
        int t = asp.indexOf('T');
        if (t >= 0) {
            int n = 1;
            if (t + 1 < asp.length() && Character.isDigit(asp.charAt(t + 1))) n = asp.charAt(t + 1) - '0';
            e.turbos = n;
        }
        e.kw = power(f[8]);
        e.nm = torque(f[9]);
        e.rpmP = (int) num(f[10]);
        e.redline = (int) num(f[11]);
        if (f.length > 12) {
            for (String kv : f[12].trim().split("\\s+")) {
                if (kv.isEmpty()) continue;
                String k = kv, v = "1";
                int eq = kv.indexOf('=');
                if (eq > 0) { k = kv.substring(0, eq); v = kv.substring(eq + 1); }
                switch (k) {
                    case "b": e.bore = num(v); e.boreKnown = true; break;
                    case "s": e.stroke = num(v); break;
                    case "v": e.valves = (int) num(v); break;
                    case "vt": e.vt = v.toUpperCase(Locale.US); break;
                    case "st": e.strokes = (int) num(v); break;
                    case "cool": e.air = v.equals("air"); e.oilCooled = v.equals("oil"); break;
                    case "f": e.fuel = v.charAt(0); break;
                    case "hv": e.hotV = true; break;
                    case "ds": e.drySump = true; break;
                    case "fp": e.flatPlane = true; break;
                    case "tq": e.rpmT = (int) num(v); break;
                    case "kg": e.engineKg = num(v); break;
                    case "est": e.est = true; break;
                    case "cl": e.claimed = true; break;
                    case "h": e.hybrid = true; break;
                    case "idle": e.idle = (int) num(v); break;
                    case "cat": e.cats += " " + v.replace(',', ' '); break;
                    case "it": e.intake = v; break;
                    case "nthr": e.nthr = (int) num(v); break;
                    case "ncarb": e.ncarb = (int) num(v); break;
                    case "tp": e.tp = v; if (v.equals("hv")) e.hotV = true; break;
                    case "ic": e.ic = v; break;
                    case "scx": e.scx = v; break;
                    case "tc": e.timingRear = v.equals("rear"); break;
                    case "gbx": e.gbxSump = true; break;
                    case "seq": e.seqTurbo = true; break;
                    case "ex": e.ex = v; break;
                    case "fan": e.fan = v; break;
                    case "cov": e.cov = (int) Long.parseLong(v, 16); break;
                    case "blk": e.blk = (int) Long.parseLong(v, 16); break;
                    case "tilt": e.tilt = num(v); break;
                }
            }
        }
        if (f.length > 13) e.note = f[13].trim();
        return e;
    }

    static void parseLayout(Engine e, String s) {
        String L = s.toUpperCase(Locale.US);
        String angle = null;
        int slash = L.indexOf('/');
        if (slash > 0) { angle = L.substring(slash + 1); L = L.substring(0, slash); }
        int i = 0;
        while (i < L.length() && !Character.isDigit(L.charAt(i))) i++;
        e.layout = L.substring(0, i);
        e.cyl = Integer.parseInt(L.substring(i));
        if (e.layout.equals("RAD")) {
            e.rows = angle != null ? Integer.parseInt(angle) : 1;
        } else if (angle != null) {
            e.bank = num(angle);
        }
        switch (e.layout) {
            case "V": case "IV": if (e.bank == 0) e.bank = 60; break;
            case "VR": if (e.bank == 0) e.bank = 15; break;
            case "W": if (e.bank == 0) e.bank = 72; break;
            case "B": e.bank = 60; break;
            case "F": e.bank = 180; break;
        }
    }

    static Vehicle parseVehicle(String line, Engine e) {
        String[] f = line.split("\\|", -1);
        Vehicle v = new Vehicle();
        v.engine = e;
        v.name = f[0].trim();
        v.years = f.length > 1 ? f[1].trim() : "";
        String type = f.length > 2 ? f[2].trim() : "car";
        int star = type.indexOf('*');
        if (star > 0) { v.count = Integer.parseInt(type.substring(star + 1)); type = type.substring(0, star); }
        v.type = type;
        v.drive = f.length > 3 ? f[3].trim() : "FR";
        v.kg = f.length > 4 && !f[4].trim().isEmpty() && !f[4].trim().equals("-") ? num(f[4]) : 0;
        if (f.length > 5) {
            String t = f[5].trim();
            if (!t.isEmpty() && !t.equals("-")) {
                char last = t.charAt(t.length() - 1);
                if (Character.isLetter(last)) { v.topFlag = Character.toUpperCase(last); t = t.substring(0, t.length() - 1); }
                v.top = num(t);
            }
        }
        if (f.length > 6 && !f[6].trim().isEmpty()) v.kwOverride = power(f[6]);
        return v;
    }

    static void finish(Engine e) {
        // geometry
        float perCyl = e.cc / Math.max(1, e.cyl);
        if (e.layout.equals("R")) {
            if (e.bore <= 0) e.bore = 0; // n/a
        } else if (e.bore <= 0 || e.stroke <= 0) {
            float ratio = e.diesel() ? 1.12f : (e.twoStroke() ? 0.98f : 0.96f); // stroke/bore
            if (e.redline > 11000) ratio = 0.7f;
            if (e.redline < 1000) ratio = 2.4f;
            // perCyl = pi/4 * b^2 * s (mm^3 /1000 = cc)
            float b = (float) Math.cbrt(perCyl * 1000f * 4f / (Math.PI * ratio));
            if (e.bore <= 0) e.bore = b;
            if (e.stroke <= 0) e.stroke = (float) (perCyl * 1000f * 4f / (Math.PI * e.bore * e.bore));
        }
        if (e.twoStroke() && e.vt.equals("DOHC")) e.vt = "PORT";
        if (e.twoStroke() && e.vt.equals("PORT")) e.valves = 0;
        if (e.layout.equals("R")) { e.vt = "PORT"; e.valves = 0; }
        if (e.idle <= 0) {
            if (e.redline < 400) e.idle = Math.round(e.redline * 0.25f);
            else if (e.redline < 3000) e.idle = Math.round(e.redline * 0.3f);
            else if (e.redline > 12000) e.idle = 1800;
            else if (e.cc < 200) e.idle = 1500;
            else e.idle = e.diesel() ? 700 : 850;
        }
        if (e.rpmP <= 0) e.rpmP = Math.round(e.redline * 0.9f);
        if (e.nm <= 0) {
            float k = (e.turbos > 0 || e.sc) ? 1.3f : (e.twoStroke() ? 1.08f : 1.15f);
            e.nm = e.kw * 9549f / e.rpmP * k;
            e.nmEst = true;
        }
        if (e.redline < e.rpmP) e.redline = e.rpmP;
        // auto categories
        StringBuilder c = new StringBuilder(e.cats);
        if (e.twoStroke()) c.append(" 2t");
        if (e.diesel()) c.append(" diesel");
        if (e.turbos > 0) c.append(" turbo");
        if (e.sc) c.append(" sc");
        if (e.turbos == 0 && !e.sc) c.append(" na");
        if (e.wankel()) c.append(" rotary");
        if (e.cc <= 130) c.append(" tiny");
        if (e.cc >= 12000 || e.hp() >= 2500) c.append(" giant");
        HashSet<String> types = new HashSet<>();
        for (Vehicle v : e.vehicles) types.add(v.type);
        if (types.contains("car") || types.contains("lsr") || types.contains("rally")) c.append(" car");
        if (types.contains("race") || types.contains("drag") || types.contains("kart")) c.append(" race");
        if (types.contains("bike") || types.contains("scooter") || types.contains("moped")) c.append(" bike");
        if (types.contains("plane") || types.contains("model")) c.append(" air");
        if (types.contains("ship") || types.contains("boat")) c.append(" marine");
        if (types.contains("truck") || types.contains("haul") || types.contains("train") || types.contains("bus")) c.append(" heavy");
        if (types.contains("tool")) c.append(" tool");
        e.cats = c.toString().trim();
    }
}

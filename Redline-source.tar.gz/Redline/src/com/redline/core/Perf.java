package com.redline.core;

/** Longitudinal vehicle simulation: top speed, acceleration times, run samples for animation. */
public final class Perf {
    public static final float RHO = 1.225f, G = 9.81f;

    public float top;          // km/h
    public String limit = "";  // what caps top speed
    public float t100 = -1, t200 = -1, t300 = -1, t400 = -1, quarter = -1, trap = -1, km = -1;
    public float kmh100to200 = -1;
    public float timeToTop = -1;
    public float massKg, cdA, powerKw, kgPerKw;
    public boolean estimateOnly;   // non-road vehicles: scaled from documented speed
    public int gears;
    public float[] ratios;
    // samples for animation: t, v(km/h), rpm, gear, x(m)
    public float[] st, sv, sr, sx;
    public int[] sg;
    public int ns;

    static float defaultCdA(Vehicle v) {
        switch (v.type) {
            case "bike": return 0.42f;
            case "scooter": case "moped": return 0.50f;
            case "truck": return v.kg > 6000 ? 6.0f : 1.25f;
            case "bus": return 6.5f;
            case "haul": return 28f;
            case "train": return 12f;
            case "kart": return 0.55f;
            case "lsr": return 0.38f;
            case "race": return 0.95f;
            case "drag": return 1.1f;
            case "rally": return 0.85f;
        }
        return 0.68f;
    }

    static float crr(Vehicle v) {
        switch (v.type) {
            case "train": return 0.0015f;
            case "haul": return 0.025f;
            case "truck": case "bus": return 0.007f;
            case "bike": case "scooter": case "moped": return 0.015f;
            case "drag": return 0.02f;
        }
        return 0.012f;
    }

    static float wheelR(Vehicle v) {
        switch (v.type) {
            case "bike": return 0.31f;
            case "scooter": return 0.22f;
            case "moped": return 0.28f;
            case "truck": return v.kg > 6000 ? 0.53f : 0.40f;
            case "bus": return 0.52f;
            case "haul": return 2.0f;
            case "train": return 0.53f;
            case "kart": return 0.14f;
            case "lsr": return 0.48f;
            case "drag": return 0.46f;
        }
        return 0.33f;
    }

    static float driveEff(Vehicle v) {
        if (v.bikeLike()) return 0.90f;
        if (v.type.equals("train")) return 0.82f;
        if ("AWD".equals(v.drive)) return 0.82f;
        return 0.86f;
    }

    static float tractionFrac(Vehicle v) {
        if (v.type.equals("train")) return 1f;
        switch (v.drive) {
            case "FF": return 0.56f;
            case "FR": return 0.66f;
            case "MR": return 0.78f;
            case "RR": return v.type.equals("drag") ? 1.6f : 0.84f;
            case "AWD": return 1.0f;
        }
        return v.bikeLike() ? 1.0f : 0.62f;
    }

    static float baseMu(Vehicle v) {
        switch (v.type) {
            case "train": return 0.33f;
            case "haul": return 0.6f;
            case "truck": case "bus": return 0.75f;
            case "drag": return 3.5f;
            case "race": return 1.45f;
            case "bike": case "scooter": case "moped": return 1.0f;
        }
        int y = 2000;
        try { y = Integer.parseInt(v.years.substring(0, 4)); } catch (Exception ignored) { }
        return y < 1960 ? 0.8f : (y < 1990 ? 0.95f : (y < 2010 ? 1.08f : 1.15f));
    }

    static boolean cvt(Vehicle v) {
        return v.type.equals("scooter") || v.type.equals("train") || v.type.equals("drag") || v.type.equals("moped") && v.engine.twoStroke() && v.engine.cc < 60 && v.drive.equals("BE");
    }

    static int gearCount(Vehicle v) {
        int y = 2000;
        try { y = Integer.parseInt(v.years.replaceAll("[^0-9].*$", "").substring(0, 4)); } catch (Exception ignored) { }
        switch (v.type) {
            case "truck": return v.kg > 6000 ? 12 : 10;
            case "bus": return 4;
            case "haul": return 7;
            case "kart": return 1;
            case "lsr": return y < 1950 ? 3 : 4;
            case "moped": return v.engine.cc < 60 ? (v.drive.equals("CH") ? 6 : 1) : 4;
            case "bike": return y < 1940 ? 3 : (y < 1975 ? 5 : 6);
            case "race": return y < 1960 ? 5 : (y < 1990 ? 6 : 7);
        }
        if (y < 1920) return 2;
        if (y < 1950) return 3;
        if (y < 1975) return 4;
        if (y < 2000) return 5;
        if (y < 2012) return 6;
        return v.kw() > 350 ? 8 : 7;
    }

    float drive(Curve c, float rpm, float ratio, float eff, float r) {
        return c.torque(rpm) * ratio * eff / r;
    }

    /** Main entry. stockCurve is used to calibrate drag and gearing from documented figures. */
    public static Perf run(Vehicle v, Tune t, Curve stock, Curve tuned, boolean samples) {
        Perf p = new Perf();
        Engine e = v.engine;
        float vehicleScale = v.kw() / e.kw * v.count;
        float stockKw = stock.peakKw * vehicleScale;
        float tunedKw = tuned.peakKw * vehicleScale;
        p.powerKw = tunedKw;
        if (!v.road()) {
            p.estimateOnly = true;
            if (v.top > 0) p.top = v.top * (float) Math.cbrt(tunedKw / stockKw);
            p.limit = "Estimated from the documented speed (drag rises with the cube of speed)";
            p.massKg = v.kg;
            p.kgPerKw = v.kg / Math.max(0.001f, tunedKw);
            return p;
        }
        boolean withDriver = !(v.type.equals("train") || v.type.equals("haul"));
        float kg = v.kg > 0 ? v.kg : 1400;
        float mass = kg * (1f - t.weight * 0.05f) + (withDriver ? 75f : 0f);
        p.massKg = mass;
        p.kgPerKw = mass / Math.max(0.001f, tunedKw);
        float crr = crr(v);
        float r = wheelR(v);
        float eff = driveEff(v);
        float stockMass = kg + (withDriver ? 75f : 0f);

        // Calibrate CdA from the documented top speed when it is a genuine (unlimited) figure.
        float cda = defaultCdA(v);
        if (v.top > 0 && (v.topFlag == ' ' || v.topFlag == 'R') && !v.type.equals("drag")) {
            float vt = v.top / 3.6f;
            float pw = stockKw * 1000f * eff;
            float c = (pw - crr * stockMass * G * vt) / (0.5f * RHO * vt * vt * vt);
            float lo = defaultCdA(v) * 0.35f, hi = defaultCdA(v) * 4.5f;
            if (c > lo && c < hi) cda = c;
        }
        float stockCda = cda;
        if (t.aero == 1) cda *= 0.88f;
        if (t.aero == 2) cda *= 1.15f;
        p.cdA = cda;
        float downK = t.aero == 2 ? 1.2f : 0.25f; // downforce coefficient relative to CdA

        // Stock drag-limited speed -> gearing
        float vref = dragLimited(stockKw * 1000f * eff, stockCda, crr, stockMass);
        float rpmAtVref = Math.min(e.redline * 0.98f, e.rpmP * 1.04f);
        float topRatio = (rpmAtVref / 60f) / (vref / (2f * (float) Math.PI * r));
        float fd = 1f + t.gearing * 0.06f;
        topRatio *= fd;
        boolean isCvt = cvt(v);
        int n = isCvt ? 1 : gearCount(v);
        p.gears = isCvt ? 0 : n;
        float[] ratios = new float[n];
        if (n == 1) ratios[0] = topRatio;
        else {
            float spread = Math.max(2.4f, 0.55f + n * 0.62f);
            if (v.type.equals("truck") || v.type.equals("haul")) spread = n * 1.2f;
            for (int i = 0; i < n; i++) {
                float k = (float) i / (n - 1);
                ratios[i] = topRatio * (float) Math.pow(spread, Math.pow(1 - k, 1.12));
            }
        }
        p.ratios = ratios;
        float mu = baseMu(v) * new float[]{0.85f, 1f, 1.12f, 1.25f, 1.45f}[t.tires];
        float trac = tractionFrac(v);
        int red = t.redline(e);
        float vLimit = (v.topFlag == 'L' && t.limiterOff == 0 && v.top > 0) ? v.top / 3.6f : 1e9f;

        // Analytic top speed scan
        float best = 0;
        String why = "Drag-limited";
        for (float vs = 1f; vs < 250f; vs += 0.25f) {
            float resist = 0.5f * RHO * cda * vs * vs + crr * mass * G;
            float fmax = 0;
            boolean revCap = true;
            if (isCvt) {
                float rpmG = vs / (2f * (float) Math.PI * r) * 60f * ratios[0];
                if (rpmG <= red) { revCap = false; float hold = Math.max(rpmG, tuned.rpmPeakKw); fmax = tuned.kw(Math.min(hold, red)) * vehicleScale * 1000f * eff / vs; }
            } else for (float ratio : ratios) {
                float rpm = vs / (2f * (float) Math.PI * r) * 60f * ratio;
                if (rpm > red) continue;
                revCap = false;
                float f = tuned.torque(Math.max(rpm, e.idle)) * vehicleScale * ratio * eff / r;
                if (f > fmax) fmax = f;
            }
            if (revCap) { why = "Rev-limited in top gear"; break; }
            if (fmax < resist) { why = "Drag-limited"; break; }
            best = vs;
            if (vs >= vLimit) { best = vLimit; why = v.type.equals("truck") || v.type.equals("haul") || v.type.equals("train") ? "Governed" : "Speed limiter"; break; }
        }
        p.top = best * 3.6f;
        p.limit = why;

        // Time-stepped run
        float dt = mass > 20000 ? 0.02f : 0.005f;
        int cap = samples ? 4000 : 0;
        if (samples) {
            p.st = new float[cap]; p.sv = new float[cap]; p.sr = new float[cap]; p.sx = new float[cap]; p.sg = new int[cap];
        }
        float vel = 0, x = 0, time = 0, shiftT = 0, nextSample = 0;
        int gear = 0;
        float launch = Math.min(red * 0.92f, Math.max(e.idle * 1.6f, tuned.rpmPeakNm * 0.85f));
        int vy = 2000;
        try { vy = Integer.parseInt(v.years.substring(0, 4)); } catch (Exception ignored) { }
        float shiftTime = v.bikeLike() ? 0.08f : (n > 8 ? 0.6f : (vy >= 2005 ? 0.09f : (vy >= 1980 ? 0.25f : 0.45f)));
        float rpm = e.idle;
        float topV = best;
        float maxTime = mass > 20000 ? 400f : 180f;
        while (time < maxTime) {
            float force;
            float wheelRpm = vel / (2f * (float) Math.PI * r) * 60f;
            if (isCvt) {
                float rpmG = wheelRpm * ratios[0];
                rpm = Math.max(rpmG, Math.min(tuned.rpmPeakKw, red));
                if (rpmG < tuned.rpmPeakKw) force = tuned.kw(rpm) * vehicleScale * 1000f * eff / Math.max(vel, 2f);
                else force = rpmG > red ? 0 : tuned.torque(rpmG) * vehicleScale * ratios[0] * eff / r;
            } else {
                float rpmG = wheelRpm * ratios[gear];
                if (rpmG >= red * 0.985f && gear < n - 1) { gear++; shiftT = shiftTime; rpmG = wheelRpm * ratios[gear]; }
                rpm = Math.max(rpmG, gear == 0 ? launch : e.idle);
                if (shiftT > 0) { shiftT -= dt; force = 0; }
                else if (rpmG > red) force = 0;
                else force = tuned.torque(rpm) * vehicleScale * ratios[gear] * eff / r;
            }
            float down = 0.5f * RHO * cda * downK * vel * vel;
            float grip = mu * (mass * G * trac + down * Math.min(1f, trac));
            if (force > grip) force = grip;
            float resist = 0.5f * RHO * cda * vel * vel + crr * mass * G;
            if (vel >= vLimit) force = Math.min(force, resist);
            float acc = (force - resist) / (mass * 1.04f);
            vel = Math.max(0f, vel + acc * dt);
            x += vel * dt;
            time += dt;
            float kmh = vel * 3.6f;
            if (p.t100 < 0 && kmh >= 100) p.t100 = time;
            if (p.t200 < 0 && kmh >= 200) p.t200 = time;
            if (p.t300 < 0 && kmh >= 300) p.t300 = time;
            if (p.t400 < 0 && kmh >= 400) p.t400 = time;
            if (p.quarter < 0 && x >= 402.336f) { p.quarter = time; p.trap = kmh; }
            if (p.km < 0 && x >= 1000f) p.km = time;
            if (p.timeToTop < 0 && vel >= topV * 0.995f) p.timeToTop = time;
            if (samples && time >= nextSample && p.ns < cap) {
                p.st[p.ns] = time; p.sv[p.ns] = kmh; p.sr[p.ns] = rpm; p.sg[p.ns] = gear + 1; p.sx[p.ns] = x;
                p.ns++;
                nextSample += mass > 20000 ? 0.25f : 0.05f;
            }
            if (p.timeToTop > 0 && time > p.timeToTop + 2f && (p.quarter > 0 || time > 60)) break;
        }
        if (p.t100 > 0 && p.t200 > 0) p.kmh100to200 = p.t200 - p.t100;
        if (v.type.equals("drag") && samples) {
            for (int i = 0; i < p.ns; i++) if (p.sx[i] >= 304.8f) { p.top = p.sv[i]; p.limit = "Speed at the 1,000 ft finish line"; break; }
        }
        return p;
    }

    static float dragLimited(float pw, float cda, float crr, float mass) {
        float lo = 0, hi = 250;
        for (int i = 0; i < 60; i++) {
            float m = (lo + hi) / 2;
            float need = (0.5f * RHO * cda * m * m + crr * mass * G) * m;
            if (need > pw) hi = m; else lo = m;
        }
        return lo;
    }
}

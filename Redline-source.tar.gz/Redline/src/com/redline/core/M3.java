package com.redline.core;

/** 3x4 affine matrices stored row-major in float[12]: [r00 r01 r02 tx | r10 r11 r12 ty | r20 r21 r22 tz]. */
public final class M3 {
    private M3() { }

    public static float[] id() { return new float[]{1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0}; }

    public static float[] set(float[] m, float r00, float r01, float r02, float tx, float r10, float r11, float r12, float ty, float r20, float r21, float r22, float tz) {
        m[0] = r00; m[1] = r01; m[2] = r02; m[3] = tx;
        m[4] = r10; m[5] = r11; m[6] = r12; m[7] = ty;
        m[8] = r20; m[9] = r21; m[10] = r22; m[11] = tz;
        return m;
    }

    public static float[] identity(float[] m) { return set(m, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0); }

    /** Rotation about X by degrees: maps +Y toward +Z. */
    public static float[] rotX(float deg) {
        double a = Math.toRadians(deg);
        float c = (float) Math.cos(a), s = (float) Math.sin(a);
        return new float[]{1, 0, 0, 0, 0, c, -s, 0, 0, s, c, 0};
    }

    public static float[] rotY(float deg) {
        double a = Math.toRadians(deg);
        float c = (float) Math.cos(a), s = (float) Math.sin(a);
        return new float[]{c, 0, s, 0, 0, 1, 0, 0, -s, 0, c, 0};
    }

    public static float[] rotZ(float deg) {
        double a = Math.toRadians(deg);
        float c = (float) Math.cos(a), s = (float) Math.sin(a);
        return new float[]{c, -s, 0, 0, s, c, 0, 0, 0, 0, 1, 0};
    }

    public static float[] trans(float x, float y, float z) { return new float[]{1, 0, 0, x, 0, 1, 0, y, 0, 0, 1, z}; }

    public static float[] scale(float x, float y, float z) { return new float[]{x, 0, 0, 0, 0, y, 0, 0, 0, 0, z, 0}; }

    /** out = a * b (apply b first, then a). out may alias neither input. */
    public static float[] mul(float[] a, float[] b, float[] out) {
        for (int r = 0; r < 3; r++) {
            int o = r * 4;
            float a0 = a[o], a1 = a[o + 1], a2 = a[o + 2], a3 = a[o + 3];
            out[o] = a0 * b[0] + a1 * b[4] + a2 * b[8];
            out[o + 1] = a0 * b[1] + a1 * b[5] + a2 * b[9];
            out[o + 2] = a0 * b[2] + a1 * b[6] + a2 * b[10];
            out[o + 3] = a0 * b[3] + a1 * b[7] + a2 * b[11] + a3;
        }
        return out;
    }

    public static float[] mul(float[] a, float[] b) { return mul(a, b, new float[12]); }

    public static float[] mul(float[]... ms) {
        float[] r = ms[0].clone();
        for (int i = 1; i < ms.length; i++) r = mul(r, ms[i]);
        return r;
    }

    /** Writes a rotation about X (degrees) with translation (tx,ty,tz) into out. */
    public static float[] rotXT(float deg, float tx, float ty, float tz, float[] out) {
        double a = Math.toRadians(deg);
        float c = (float) Math.cos(a), s = (float) Math.sin(a);
        return set(out, 1, 0, 0, tx, 0, c, -s, ty, 0, s, c, tz);
    }

    public static float[] transInto(float x, float y, float z, float[] out) { return set(out, 1, 0, 0, x, 0, 1, 0, y, 0, 0, 1, z); }

    public static void apply(float[] m, float x, float y, float z, float[] out, int o) {
        out[o] = m[0] * x + m[1] * y + m[2] * z + m[3];
        out[o + 1] = m[4] * x + m[5] * y + m[6] * z + m[7];
        out[o + 2] = m[8] * x + m[9] * y + m[10] * z + m[11];
    }

    public static void applyDir(float[] m, float x, float y, float z, float[] out, int o) {
        out[o] = m[0] * x + m[1] * y + m[2] * z;
        out[o + 1] = m[4] * x + m[5] * y + m[6] * z;
        out[o + 2] = m[8] * x + m[9] * y + m[10] * z;
    }
}

package com.redline.core;

import java.util.Locale;
import java.util.Random;

/** The Rev Lab: live engine, tach, shift lights, boost, temps, trace, dyno sweep, limiters, flames, pedal. */
public final class RevLab implements Painter {
    public final RevSim sim;
    public final EngineViewer viewer;
    public final Curve curve;
    public float haptic;
    public boolean hapticPulse, hapticBang;
    private float[] rStart, rBlip, rMode, rLim, rSlow, rView, rPedal, rDyno;
    private int pedalId = -1;
    private float blipT;
    private float needle, ghost;
    private float[] tracePts;
    private float time;
    private final Random rnd = new Random(7);
    private static final float[] SLOWS = {1f / 20f, 1f / 60f, 1f / 200f, 1f / 1000f};
    private int slowIdx = 1;
    private static final int[] VIEW_MODES = {Raster.XRAY, Raster.CUTAWAY, Raster.FLOW, Raster.THERMAL, Raster.SOLID};
    private int viewIdx;
    private static final String[] LIMS = {"Hard cut", "Soft cut", "Launch", "Anti-lag"};

    public RevLab(Engine e, Tune t) {
        curve = t == null ? Curve.stock(e) : Curve.build(e, t);
        sim = new RevSim(e, curve, t == null ? e.redline : t.redline(e));
        viewer = new EngineViewer(e);
        viewer.compact = true;
        viewer.setMode(Raster.XRAY);
        viewer.slow = SLOWS[slowIdx];
        viewer.autoRotate = true;
        sim.start();
    }

    @Override public boolean animating() { return true; }

    public void dispose() { viewer.dispose(); }

    @Override
    public void paint(Gfx g, float w, float h, float dt) {
        time += dt;
        if (blipT > 0) { blipT -= dt; sim.throttleIn = blipT > 0 ? 1f : (pedalId >= 0 ? sim.throttleIn : 0f); }
        sim.step(dt);
        viewer.rpm = sim.rpm;
        viewer.load = sim.throttle;
        viewer.paused = !sim.running && !sim.cranking && sim.rpm < 1;
        haptic = sim.vibe;
        hapticPulse = sim.limiterEvent;
        hapticBang = sim.popEvent;
        boolean land = w > h * 1.1f;
        float s = land ? Math.min(w / 46f, h / 26f) : Math.min(w / 25f, h / 44f);
        g.fillRect(0, 0, w, h, Theme.BG);
        float sh = sim.shake * s * 0.35f;
        g.save();
        if (sh > 0.2f) g.translate((rnd.nextFloat() - 0.5f) * sh, (rnd.nextFloat() - 0.5f) * sh);
        float vx, vy, vw, vh, px, py, pw, ph;
        if (land) { vx = 0; vy = 0; vw = w * 0.46f; vh = h; px = vw; py = 0; pw = w - vw; ph = h; }
        else { vx = 0; vy = 0; vw = w; vh = h * 0.33f; px = 0; py = vh; pw = w; ph = h - vh; }
        viewer.paintIn(g, vx, vy, vw, vh, dt);
        drawFlames(g, vx, vy, vw, vh, s);
        // header text over the viewer
        g.text(sim.e.make + " " + sim.e.name, vx + vw / 2, vy + vh - s * 0.6f, s * 0.72f, Theme.TEXT, Gfx.CENTER, Gfx.BOLD);
        drawPanel(g, px, py, pw, ph, s);
        g.restore();
    }

    private void drawFlames(Gfx g, float x, float y, float w, float h, float s) {
        float f = sim.flame;
        if (f <= 0.02f) return;
        for (int side = 0; side < 2; side++) {
            float tx = side == 0 ? x + s * 1.2f : x + w - s * 1.2f;
            float ty = y + h - s * 2.2f;
            int dir = side == 0 ? 1 : -1;
            g.circle(tx, ty, s * 0.55f, 0xFF2A2D33);
            g.ring(tx, ty, s * 0.55f, s * 0.12f, 0xFF8D939B);
            float len = s * (2.5f + 5f * f) * (0.8f + 0.4f * rnd.nextFloat());
            for (int k = 0; k < 3; k++) {
                float lk = len * (1f - k * 0.28f);
                float wk = s * (0.55f - k * 0.13f);
                int col = k == 0 ? 0xFFFF5A1F : (k == 1 ? 0xFFFFB020 : 0xFFFFF3C4);
                float[] poly = {tx, ty - wk, tx + dir * lk, ty + (rnd.nextFloat() - 0.5f) * s * 0.6f, tx, ty + wk};
                g.poly(poly, 3, Theme.alpha(col, Math.min(1f, f * 1.4f)));
            }
            if (f > 0.5f) g.circle(tx + dir * s * 0.4f, ty, s * 0.5f, Theme.alpha(0xFF5AA0FF, f * 0.6f));
        }
    }

    private void drawPanel(Gfx g, float x, float y, float w, float h, float s) {
        Engine e = sim.e;
        int red = sim.red;
        float pad = s;
        // shift lights
        int leds = 12;
        float frac = sim.rpm / red;
        float lw = (w - pad * 2) / leds;
        float ly = y + pad * 0.6f;
        boolean flash = frac > 0.97f && ((int) (time * 14) % 2 == 0);
        for (int i = 0; i < leds; i++) {
            float th = 0.6f + 0.37f * i / (leds - 1);
            boolean on = frac >= th;
            int col = i < 5 ? Theme.GREEN : (i < 9 ? Theme.AMBER : Theme.RED);
            if (frac > 0.97f) col = Theme.BLUE;
            if (flash) on = false;
            g.fillRound(x + pad + i * lw + lw * 0.12f, ly, lw * 0.76f, s * 0.55f, s * 0.2f, on ? col : 0x22FFFFFF);
        }
        // tach
        float r = Math.min(w * 0.29f, h * 0.2f);
        float tcx = x + pad + r + s * 0.5f, tcy = ly + s * 1.3f + r;
        float maxR = (float) (Math.ceil(red * 1.1f / 1000f) * 1000f);
        if (red < 2500) maxR = (float) (Math.ceil(red * 1.1f / 100f) * 100f);
        float start = 135, sweep = 270;
        g.circle(tcx, tcy, r, 0xFF0E1218);
        g.ring(tcx, tcy, r, s * 0.12f, Theme.LINE);
        float redStart = start + sweep * red / maxR;
        g.arc(tcx, tcy, r * 0.9f, redStart, start + sweep - redStart, s * 0.45f, Theme.alpha(Theme.RED, 0.8f));
        int major = (int) (maxR >= 10000 ? 2000 : (maxR >= 2500 ? 1000 : (maxR >= 1000 ? 200 : 20)));
        for (float v = 0; v <= maxR + 1; v += major / 2f) {
            boolean big = Math.abs(v % major) < 1e-3f;
            double a = Math.toRadians(start + sweep * v / maxR);
            float c = (float) Math.cos(a), sn = (float) Math.sin(a);
            float r0 = r * (big ? 0.8f : 0.86f);
            g.line(tcx + c * r0, tcy + sn * r0, tcx + c * r * 0.94f, tcy + sn * r * 0.94f, big ? s * 0.14f : s * 0.07f, v >= red ? Theme.RED : Theme.TEXT);
            if (big) {
                String lab = maxR >= 2500 ? String.valueOf((int) (v / 1000)) : String.valueOf((int) v);
                g.text(lab, tcx + c * r * 0.66f, tcy + sn * r * 0.66f + s * 0.3f, s * 0.75f, v >= red ? Theme.RED : Theme.DIM, Gfx.CENTER, Gfx.BOLD);
            }
        }
        float target = Math.min(sim.rpm, maxR * 1.02f) / maxR;
        needle += (target - needle) * 0.6f;
        ghost += (needle - ghost) * 0.25f;
        for (int k = 3; k >= 0; k--) {
            float v = ghost + (needle - ghost) * (1f - k / 4f);
            double a = Math.toRadians(start + sweep * v);
            g.line(tcx, tcy, tcx + (float) Math.cos(a) * r * 0.88f, tcy + (float) Math.sin(a) * r * 0.88f, s * (0.22f - k * 0.03f), Theme.alpha(Theme.RED, k == 0 ? 1f : 0.18f));
        }
        g.circle(tcx, tcy, s * 0.55f, 0xFF2A313C);
        g.text(String.format(Locale.US, "%,d", Math.round(sim.rpm)), tcx, tcy + r * 0.45f, s * 1.5f, sim.cut ? Theme.RED : Theme.TEXT, Gfx.CENTER, Gfx.BOLD | Gfx.MONO);
        g.text(maxR >= 2500 ? "rpm ×1000" : "rpm", tcx, tcy + r * 0.62f, s * 0.6f, Theme.DIM, Gfx.CENTER, 0);
        String status = !sim.running ? (sim.cranking ? "CRANKING" : "ENGINE OFF") : (sim.dynoRunning ? "DYNO PULL" : (sim.cut ? "LIMITER" : ""));
        if (!status.isEmpty()) g.text(status, tcx, tcy - r * 0.3f, s * 0.75f, sim.cut || sim.dynoRunning ? Theme.RED : Theme.AMBER, Gfx.CENTER, Gfx.BOLD);
        // right column: boost + temps
        float cx = tcx + r + s * 1.2f, cw = x + w - pad - cx;
        float cy = ly + s * 1.6f;
        if (sim.maxBoost > 0) {
            float bmax = sim.maxBoost * 1.3f;
            g.text("BOOST", cx, cy, s * 0.6f, Theme.DIM, Gfx.LEFT, Gfx.BOLD);
            g.text(String.format(Locale.US, "%.2f bar", sim.boost), cx + cw, cy, s * 0.7f, Theme.CYAN, Gfx.RIGHT, Gfx.BOLD | Gfx.MONO);
            bar(g, cx, cy + s * 0.4f, cw, s * 0.45f, sim.boost / bmax, Theme.CYAN);
            cy += s * 2.2f;
        }
        String[] lbl = {"WATER", "OIL", "EGT"};
        float[] val = {sim.water, sim.oil, sim.egt};
        float[] lo = {40, 40, 100}, hi = {125, 150, 1050};
        for (int i = 0; i < 3; i++) {
            float fr = (val[i] - lo[i]) / (hi[i] - lo[i]);
            int col = fr > 0.85f ? Theme.RED : (fr > 0.7f ? Theme.AMBER : Theme.GREEN);
            if (i == 2) col = fr > 0.8f ? Theme.RED : Theme.AMBER;
            g.text(lbl[i], cx, cy, s * 0.6f, Theme.DIM, Gfx.LEFT, Gfx.BOLD);
            g.text(Math.round(val[i]) + "°C", cx + cw, cy, s * 0.7f, Theme.TEXT, Gfx.RIGHT, Gfx.MONO);
            bar(g, cx, cy + s * 0.4f, cw, s * 0.45f, fr, col);
            cy += s * 2.0f;
        }
        g.text("THROTTLE", cx, cy, s * 0.6f, Theme.DIM, Gfx.LEFT, Gfx.BOLD);
        g.text(Math.round(sim.throttle * 100) + "%", cx + cw, cy, s * 0.7f, Theme.TEXT, Gfx.RIGHT, Gfx.MONO);
        bar(g, cx, cy + s * 0.4f, cw, s * 0.45f, sim.throttle, Theme.RED);
        cy += s * 2.0f;
        if (sim.health < 99.5f) {
            g.text("ENGINE HEALTH " + Math.round(sim.health) + "%", cx, cy, s * 0.62f, sim.health < 60 ? Theme.RED : Theme.AMBER, Gfx.LEFT, Gfx.BOLD);
        }
        // live readouts
        float ry = tcy + r + s * 1.7f;
        float cellW = (w - pad * 2) / 3f;
        String[] heads = {"POWER NOW", "TORQUE NOW", "BANGS"};
        String[] vals = {Units.pow(sim.kwNow), Units.tq(sim.torqueNow), String.valueOf(sim.pops)};
        for (int i = 0; i < 3; i++) {
            float bx = x + pad + cellW * i;
            g.fillRound(bx + s * 0.15f, ry - s * 1.2f, cellW - s * 0.3f, s * 2.4f, s * 0.4f, Theme.PANEL);
            g.text(heads[i], bx + cellW / 2, ry - s * 0.35f, s * 0.55f, Theme.DIM, Gfx.CENTER, Gfx.BOLD);
            g.text(vals[i], bx + cellW / 2, ry + s * 0.8f, s * 0.9f, Theme.TEXT, Gfx.CENTER, Gfx.BOLD | Gfx.MONO);
        }
        // trace or dyno chart
        float ty = ry + s * 1.6f;
        float th = Math.max(s * 4f, h * 0.13f);
        if (sim.dynoN > 1 && (sim.dynoRunning || sim.dynoDone)) drawDyno(g, x + pad, ty, w - pad * 2, th, s);
        else drawTrace(g, x + pad, ty, w - pad * 2, th, s);
        // controls
        float cy0 = ty + th + s * 0.8f;
        float ch = y + h - pad - cy0;
        float pedW = Math.min(w * 0.26f, s * 7f);
        rPedal = new float[]{x + w - pad - pedW, cy0, pedW, ch};
        g.fillRound(rPedal[0], rPedal[1], rPedal[2], rPedal[3], s * 0.6f, Theme.PANEL2);
        float fill = sim.throttleIn;
        g.fillRound(rPedal[0], rPedal[1] + ch * (1 - fill), pedW, ch * fill, s * 0.6f, Theme.alpha(Theme.RED, 0.75f));
        for (int i = 1; i < 6; i++) g.line(rPedal[0] + s * 0.6f, rPedal[1] + ch * i / 6f, rPedal[0] + pedW - s * 0.6f, rPedal[1] + ch * i / 6f, 1f, 0x22FFFFFF);
        g.text("THROTTLE", rPedal[0] + pedW / 2, rPedal[1] + s * 1.2f, s * 0.6f, Theme.TEXT, Gfx.CENTER, Gfx.BOLD);
        g.text("hold & slide", rPedal[0] + pedW / 2, rPedal[1] + ch - s * 0.6f, s * 0.5f, Theme.DIM, Gfx.CENTER, 0);
        float bx = x + pad, bw = rPedal[0] - s * 0.6f - bx;
        float rowH = Math.min(s * 2.6f, (ch - s * 1.2f) / 4f);
        float gap = (ch - rowH * 4) / 3f;
        float half = (bw - s * 0.5f) / 2;
        float by = cy0;
        rStart = Theme.button(g, sim.running || sim.cranking ? "STOP" : "START", bx, by, half, rowH, s * 0.75f, sim.running ? 0xFF3A1414 : 0xFF143A22, sim.running ? Theme.RED : Theme.GREEN);
        rBlip = Theme.button(g, "BLIP", bx + half + s * 0.5f, by, half, rowH, s * 0.75f, Theme.PANEL2, Theme.TEXT);
        by += rowH + gap;
        rDyno = Theme.button(g, sim.dynoRunning ? "PULLING…" : "DYNO PULL", bx, by, half, rowH, s * 0.68f, sim.dynoRunning ? 0xFF3A2A10 : Theme.PANEL2, Theme.AMBER);
        rLim = Theme.button(g, LIMS[sim.limiter], bx + half + s * 0.5f, by, half, rowH, s * 0.68f, Theme.PANEL2, Theme.CYAN);
        by += rowH + gap;
        rSlow = Theme.button(g, String.format(Locale.US, "Slow-mo %.0f×", 1f / SLOWS[slowIdx]), bx, by, half, rowH, s * 0.62f, Theme.PANEL2, Theme.TEXT);
        rView = Theme.button(g, Raster.MODES[VIEW_MODES[viewIdx]], bx + half + s * 0.5f, by, half, rowH, s * 0.68f, Theme.PANEL2, Theme.TEXT);
        by += rowH + gap;
        String hint = sim.limiter == 2 ? "Launch: holds " + Math.round(sim.launchRpm) + " rpm at full throttle" :
                sim.limiter == 3 ? (sim.maxBoost > 0 && e.turbos > 0 ? "Anti-lag keeps the turbo spinning off-throttle" : "Anti-lag needs a turbo") :
                        "Peak " + Units.pow(curve.peakKw) + " @ " + Units.rpm(curve.rpmPeakKw);
        g.text(hint, bx, by + rowH * 0.45f, s * 0.6f, Theme.DIM, Gfx.LEFT, 0);
        g.text("Redline " + Units.rpm(red) + " · " + e.aspName(), bx, by + rowH * 0.95f, s * 0.6f, Theme.FAINT, Gfx.LEFT, 0);
    }

    private static void bar(Gfx g, float x, float y, float w, float h, float frac, int col) {
        g.fillRound(x, y, w, h, h / 2, 0x22FFFFFF);
        g.fillRound(x, y, w * Math.max(0.02f, Math.min(1f, frac)), h, h / 2, col);
    }

    private void drawTrace(Gfx g, float x, float y, float w, float h, float s) {
        g.fillRound(x, y, w, h, s * 0.5f, Theme.PANEL);
        g.text("RPM TRACE", x + s * 0.6f, y + s * 1.0f, s * 0.55f, Theme.DIM, Gfx.LEFT, Gfx.BOLD);
        float red = sim.red;
        float ry = y + h - s * 0.5f - (h - s * 1.5f) * 1f;
        g.line(x + s * 0.4f, ry, x + w - s * 0.4f, ry, 1f, Theme.alpha(Theme.RED, 0.5f));
        int n = sim.hist.length;
        if (tracePts == null) tracePts = new float[n * 2];
        float[] pts = tracePts;
        for (int i = 0; i < n; i++) {
            float v = sim.hist[(sim.histPos + i) % n];
            pts[i * 2] = x + s * 0.4f + (w - s * 0.8f) * i / (n - 1);
            pts[i * 2 + 1] = y + h - s * 0.5f - (h - s * 1.5f) * Math.min(1.08f, v / red);
        }
        g.polyline(pts, n, s * 0.16f, Theme.CYAN);
    }

    private void drawDyno(Gfx g, float x, float y, float w, float h, float s) {
        g.fillRound(x, y, w, h, s * 0.5f, Theme.PANEL);
        int n = sim.dynoN;
        float red = sim.red;
        float maxKw = Math.max(1e-3f, Math.max(sim.dynoPeakKw, curve.peakKw)) * 1.1f;
        float maxNm = Math.max(1e-3f, Math.max(sim.dynoPeakNm, curve.peakNm)) * 1.1f;
        float[] pk = new float[n * 2], pt = new float[n * 2];
        float ix = x + s * 0.5f, iw = w - s, iy = y + s * 1.4f, ih = h - s * 1.9f;
        for (int i = 0; i < n; i++) {
            float px = ix + iw * sim.dynoR[i] / red;
            pk[i * 2] = px; pk[i * 2 + 1] = iy + ih * (1 - sim.dynoKw[i] / maxKw);
            pt[i * 2] = px; pt[i * 2 + 1] = iy + ih * (1 - sim.dynoNm[i] / maxNm);
        }
        g.polyline(pk, n, s * 0.2f, Theme.RED);
        g.polyline(pt, n, s * 0.14f, Theme.CYAN);
        String txt = (sim.dynoDone ? "RESULT  " : "") + Units.pow(sim.dynoPeakKw) + " @ " + Math.round(sim.dynoPeakRpm) + "  ·  " + Units.tq(sim.dynoPeakNm) + " @ " + Math.round(sim.dynoPeakNmRpm);
        g.text(txt, x + s * 0.6f, y + s * 1.0f, s * 0.62f, Theme.TEXT, Gfx.LEFT, Gfx.BOLD);
    }

    @Override
    public void touch(int action, int id, float x, float y) {
        if (action == DOWN && Theme.in(x, y, rPedal)) {
            pedalId = id;
            sim.throttleIn = pedal(y);
            return;
        }
        if (id == pedalId) {
            if (action == MOVE) sim.throttleIn = pedal(y);
            else if (action == UP || action == CANCEL) { pedalId = -1; sim.throttleIn = 0; }
            return;
        }
        if (action == DOWN) {
            if (Theme.in(x, y, rStart)) { if (sim.running || sim.cranking) sim.stop(); else sim.start(); return; }
            if (Theme.in(x, y, rBlip)) { if (!sim.running) sim.start(); else blipT = 0.16f; return; }
            if (Theme.in(x, y, rDyno)) { if (!sim.running) sim.start(); else { sim.startDyno(); } return; }
            if (Theme.in(x, y, rLim)) { sim.limiter = (sim.limiter + 1) % 4; return; }
            if (Theme.in(x, y, rSlow)) { slowIdx = (slowIdx + 1) % SLOWS.length; viewer.slow = SLOWS[slowIdx]; return; }
            if (Theme.in(x, y, rView)) { viewIdx = (viewIdx + 1) % VIEW_MODES.length; viewer.setMode(VIEW_MODES[viewIdx]); return; }
        }
        viewer.touch(action, id, x, y);
    }

    private float pedal(float y) {
        return Math.max(0f, Math.min(1f, 1f - (y - rPedal[1] - rPedal[3] * 0.05f) / (rPedal[3] * 0.9f)));
    }
}

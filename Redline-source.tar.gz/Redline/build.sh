#!/bin/bash
# Builds a signed release Redline.apk without Gradle:
#   aapt2 -> javac -> d8 -> zipalign -> apksigner
#
# Settings come from environment variables, or from an optional local file
# "signing.env" next to this script (it is git-ignored, never commit it):
#   ANDROID_HOME  Android SDK root           (default: $HOME/Android/Sdk)
#   BUILD_TOOLS   build-tools directory      (default: newest in $ANDROID_HOME/build-tools)
#   ANDROID_JAR   platform android.jar       (default: $ANDROID_HOME/platforms/android-35/android.jar)
#   KEYSTORE      release keystore           (default: ./release.jks)
#   KS_ALIAS      key alias                  (default: redline)
#   KS_PASS       keystore password          (required)
#   KEY_PASS      key password               (default: same as KS_PASS)
set -e

VERSION_CODE=5
VERSION_NAME=3.2

P="$(cd "$(dirname "$0")" && pwd)"
[ -f "$P/signing.env" ] && . "$P/signing.env"

SDK="${ANDROID_HOME:-$HOME/Android/Sdk}"
BT="${BUILD_TOOLS:-$(ls -d "$SDK"/build-tools/* 2>/dev/null | sort -V | tail -1)}"
PLAT="${ANDROID_JAR:-$SDK/platforms/android-35/android.jar}"
KEYSTORE="${KEYSTORE:-$P/release.jks}"
KS_ALIAS="${KS_ALIAS:-redline}"
KEY_PASS="${KEY_PASS:-$KS_PASS}"
export KS_PASS KEY_PASS

die() { echo "error: $*" >&2; exit 1; }
[ -x "$BT/aapt2" ] || die "build-tools not found (set ANDROID_HOME or BUILD_TOOLS)"
[ -f "$PLAT" ] || die "android.jar not found at $PLAT (install platform android-35 or set ANDROID_JAR)"
[ -f "$KEYSTORE" ] || die "no keystore at $KEYSTORE. Create one with:
  keytool -genkeypair -keystore release.jks -alias redline -keyalg RSA -keysize 2048 -validity 10000 -dname CN=Redline"
[ -n "$KS_PASS" ] || die "set KS_PASS to your keystore password (environment or signing.env)"

quiet() { grep -v "^Picked up\|bootstrap class path\|^warning\|^1 warning\|options were" || true; }

B="$P/build"
mkdir -p "$B"
find "$B" -mindepth 1 -delete
mkdir -p "$B/classes" "$B/res" "$B/dex" "$B/gen"
cd "$P"

"$BT/aapt2" compile --dir res -o "$B/res/res.zip"
"$BT/aapt2" link -o "$B/base.apk" -I "$PLAT" --manifest AndroidManifest.xml -A assets "$B/res/res.zip" \
  --java "$B/gen" --min-sdk-version 26 --target-sdk-version 34 \
  --version-code "$VERSION_CODE" --version-name "$VERSION_NAME"

javac -nowarn -source 11 -target 11 -encoding UTF-8 -cp "$PLAT" -d "$B/classes" \
  $(find src "$B/gen" -name '*.java') 2>&1 | quiet
[ -f "$B/classes/com/redline/app/MainActivity.class" ] || die "javac failed"

"$BT/d8" --min-api 26 --release --lib "$PLAT" --output "$B/dex" $(find "$B/classes" -name '*.class') 2>&1 | quiet

cp "$B/base.apk" "$B/unsigned.apk"
(cd "$B/dex" && zip -q -j "$B/unsigned.apk" classes.dex)
"$BT/zipalign" -f -p 4 "$B/unsigned.apk" "$B/aligned.apk"

"$BT/apksigner" sign --ks "$KEYSTORE" --ks-key-alias "$KS_ALIAS" \
  --ks-pass env:KS_PASS --key-pass env:KEY_PASS \
  --out "$P/Redline.apk" "$B/aligned.apk" 2>&1 | quiet
"$BT/apksigner" verify "$P/Redline.apk" 2>&1 | quiet
rm -f "$P/Redline.apk.idsig"
ls -la "$P/Redline.apk"
